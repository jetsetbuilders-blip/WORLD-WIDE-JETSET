#!/usr/bin/env bash
# MY CONSOLE — DEPLOY-2 launcher for Linux
# Starts the Royal AI Gateway (console + secure AI backend) on http://127.0.0.1:8765
cd "$(dirname "$(readlink -f "$0")")" || exit 1
DIR="$(pwd)"
echo ""
echo "  MY CONSOLE · BUILD DEPLOY-2"
echo "  ==============================="

if [ -f "$DIR/MY-CONSOLE/index.html" ]; then ROOT="$DIR/MY-CONSOLE"
elif [ -f "$DIR/index.html" ]; then ROOT="$DIR"
else echo "  Could not find MY-CONSOLE/index.html — unzip the whole folder and run ./open.sh inside it."; exit 1; fi
GW=""
[ -f "$DIR/royal-ai-cloud/server.py" ] && GW="$DIR/royal-ai-cloud"

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)' 2>/dev/null; then PY="$(command -v "$c")"; break; fi
done
if [ -z "$PY" ]; then
  echo "  Python 3.8+ was not found. Install it (e.g. sudo apt install python3 · sudo dnf install python3)"
  echo "  or from https://www.python.org/downloads/ — then run ./open.sh again."
  command -v xdg-open >/dev/null && xdg-open "$DIR/OPEN-MY-CONSOLE.html" >/dev/null 2>&1 &
  exit 1
fi

if [ -z "$GW" ]; then
  echo "  royal-ai-cloud/ not found — starting a plain local server (Offline Session Guardian only)."
  (sleep 1; command -v xdg-open >/dev/null && xdg-open "http://127.0.0.1:8765/index.html" >/dev/null 2>&1) &
  cd "$ROOT" && exec "$PY" -m http.server 8765 --bind 127.0.0.1
fi

echo "  Python:   $PY"
echo "  Gateway:  $GW"
echo "  Console:  $ROOT"
echo "  Data:     ${ROYAL_DATA_DIR:-${XDG_DATA_HOME:-$HOME/.local/share}/RoyalAICloud} (provider key, licence, credits)"
echo "  Banner should read: BUILD DEPLOY-2"
echo "  Keep this terminal open while you work. Ctrl+C stops the console."
exec "$PY" "$GW/server.py" serve --web-root "$ROOT" --open-browser "$@"
