#!/bin/bash
# MY CONSOLE — DEPLOY-2 launcher (local run on this Mac)
# Starts the Royal AI Gateway (console + secure AI backend) on http://127.0.0.1:8765
cd "$(dirname "$0")"
DIR="$(pwd)"
echo ""
echo "  MY CONSOLE · BUILD DEPLOY-2"
echo "  ==============================="

# --- find the gateway folder (royal-ai-cloud/server.py) ---------------------------
if [ -f "$DIR/royal-ai-cloud/server.py" ]; then
  GW="$DIR/royal-ai-cloud"
else
  GW="$(find "$DIR" -maxdepth 3 -path '*royal-ai-cloud/server.py' -print -quit 2>/dev/null | xargs dirname 2>/dev/null)"
fi
# --- find the console web root (index.html) ---------------------------------------
if [ -f "$DIR/MY-CONSOLE/index.html" ]; then
  ROOT="$DIR/MY-CONSOLE"
elif [ -f "$DIR/index.html" ]; then
  ROOT="$DIR"
else
  ROOT="$(find "$DIR" -maxdepth 3 -name index.html -not -path '*royal-ai-cloud*' -print -quit | xargs dirname 2>/dev/null)"
fi
if [ -z "$ROOT" ] || [ ! -f "$ROOT/index.html" ]; then
  osascript -e 'display alert "MY CONSOLE" message "Could not find index.html. Unzip again and double-click OPEN.command."' 2>/dev/null || echo "Could not find index.html"
  exit 1
fi

# --- python3 ----------------------------------------------------------------------
PY="$(command -v python3)"
if [ -z "$PY" ] || ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)' 2>/dev/null; then
  echo "  python3 (3.8+) was not found. macOS will offer to install the Command Line Tools —"
  echo "  accept, then double-click OPEN.command again. Opening the offline single-file build instead."
  open "$DIR/OPEN-MY-CONSOLE.html" 2>/dev/null || open "$ROOT/OPEN-MY-CONSOLE.html" 2>/dev/null
  exit 1
fi

# --- stop anything old on 8765 (previous launches) ---------------------------------
(lsof -ti:8765 | xargs kill -9) 2>/dev/null || true
sleep 0.3

if [ -z "$GW" ] || [ ! -f "$GW/server.py" ]; then
  echo "  royal-ai-cloud/ not found — starting a plain local server (Offline Session Guardian only)."
  cd "$ROOT"
  open "http://127.0.0.1:8765/index.html"
  exec "$PY" -m http.server 8765 --bind 127.0.0.1
fi

echo "  Gateway:  $GW"
echo "  Console:  $ROOT"
echo "  Banner should read: BUILD DEPLOY-2"
echo "  Keep this window open while you work. Close it (or Ctrl+C) to stop."
# First run: server.py asks for your OpenAI API key here (hidden input, Enter = skip),
# saves it to ~/Library/Application Support/RoyalAICloud/secrets.json (chmod 600),
# then opens http://127.0.0.1:8765 in your browser.
exec "$PY" "$GW/server.py" serve --web-root "$ROOT" --open-browser
