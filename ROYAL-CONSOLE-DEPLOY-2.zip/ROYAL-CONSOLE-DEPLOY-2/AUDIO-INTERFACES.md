# Audio interfaces in MY CONSOLE (web DAW) — DEPLOY-2

MY CONSOLE runs in the browser, so it talks to your audio interface through the browser's audio stack:
**CoreAudio on macOS** and **WASAPI (shared mode) on Windows**. Browsers do **not** support ASIO.
Class-compliant and driver-installed interfaces (Apollo, Focusrite, RME, MOTU, Audient, …) show up as long as the
operating system shows them.

## Where the settings are (like Pro Tools)
- **Setup › Playback Engine…**
  - Output device: Chrome/Edge only, using `AudioContext.setSinkId`. Safari and Firefox always play to the system
    output. Pick the interface in macOS System Settings › Sound › Output, or in Windows Settings › System › Sound.
    The dialog tells you when this applies.
  - Sample rate: 44.1 / 48 / 88.2 / 96 kHz. The audio engine is recreated safely. If the browser/device refuses a
    rate, the dialog says so and keeps the default.
  - Buffer / latency hint: Interactive, Balanced, Playback, or a custom value in seconds. The dialog shows the
    real `baseLatency` and `outputLatency` the browser reports.
- **Setup › I/O…**
  - **Enable input.** The microphone permission is only requested at this point.
  - Input device picker. Echo cancellation, noise suppression and auto-gain are all **off**.
  - The **detected max input channels** for the device.
  - Per-track input: mono channel 1…N or stereo pairs 1-2, 3-4, …, routed through a ChannelSplitter into the
    record path.
  - Latency compensation: automatic, plus a manual offset in ms, plus **Measure round-trip latency**.
- All choices are saved in the browser (localStorage), keyed by the **device label**. Latency offsets are saved per
  input → output device pair.

## Recording and latency compensation
Each recorded clip is shifted earlier by the compensation amount:
- **Measured round-trip** (when you have measured it), otherwise the browser-reported input + output latency.
- Plus your manual offset.

The status bar shows the compensation that was applied to each take.

**Loopback measurement.** Connect an output of the interface to an input with a cable, select that input channel,
then press *Measure round-trip latency*. MY CONSOLE:
1. plays three short clicks,
2. finds them in the input,
3. only accepts the result if the three measurements agree.

Keep monitor speakers low, because the clicks are audible.

## Input monitoring (DEPLOY-2)
- **TrackInput "I" button** (green when on) on each track in the Mix and Edit windows: the live input plays through
  that channel's inserts, fader, pan, mute/solo and on to the master. It works with the transport stopped.
- **Options › Auto Input Monitoring** (default): an armed track plays its input when stopped or recording, and its
  recorded audio during playback. **Options › Input Only Monitoring**: an armed track always plays its input.
- Armed tracks show their input level on the track meter.
- **Feedback safety:** if the input is a built-in microphone and the output is built-in speakers (detected from the
  device names), auto monitoring stays **off**. You get a warning in Setup › I/O and from the Session Guardian. Use
  headphones, or tick "Allow monitoring through speakers" in Setup › I/O at your own risk.
- The monitored signal is never recorded again: the recorder takes the raw input, before the mixer.
- **Latency:** Setup › Playback Engine shows the monitoring latency the browser reports (input + base + output).
  Typically that's 20–60 ms, which you can hear. **Options › Low Latency Monitoring** switches the engine to the
  lowest-latency hint. For zero-latency tracking, use your interface's direct monitoring (Apollo Console, Focusrite
  Control, TotalMix, …) and switch the track's I off.

## Where recordings are stored (DEPLOY-2)
- Every recorded or imported take is saved in the browser's **IndexedDB**. The raw 32-bit float audio, sample rate,
  channel count and waveform peaks are stored per session. The session autosaves every few seconds, and after a
  reload or a browser restart the clips play again and draw their real waveforms.
- **File › Save Session As…** (or File › Export › Session Package) writes a portable **.mycsession** package. It is a
  zip containing `session.json` and `Audio Files/*.wav` (32-bit float, lossless). Open it on any computer with
  **File › Open Session…**, and the audio goes into that browser's storage. Old `.mycsession.json` files still open.
- **File › Save Session (⌘S)** writes only the small `.mycsession.json`. The audio stays in this browser.
- **Deleting a clip never deletes its audio** (Edit › Undo brings it back). Audio that no clip uses anymore is removed
  only by **File › Clean Up Unused Audio…**.
- MY CONSOLE asks the browser for persistent storage. If the browser says no, or storage is low or full, you get a
  clear warning and a Session Guardian notice. A take that could not be saved is marked unsaved, and closing the tab
  asks for confirmation. Export a package regularly, especially in Safari, which may clear site data you haven't used
  for a while.

## Hot-plug
When you unplug the selected device, MY CONSOLE falls back to the system default. You get a notice in the dialog/status
bar, and the AI **Session Guardian** logs it. When the device comes back it is selected again.

## Requirements and permissions
- Input needs a **secure context**: the launcher (`http://127.0.0.1:8765`, via OPEN.command / OPEN-WINDOWS.bat /
  open.sh) or an HTTPS deployment. `OPEN-MY-CONSOLE.html` opened as a file (file://) **cannot** use the microphone or
  interface inputs, and the dialog explains why.
- If you deny the permission, the dialog tells you how to allow it again (the lock/site-settings icon in the address bar).

## Honest limits
- **No ASIO** in any browser. On Windows, WASAPI shared mode adds some latency.
- **Multichannel input depends on the browser.** Chrome/Edge usually expose all channels of an interface. Safari and
  Firefox often give only 1–2 channels. The dialog shows what the browser actually delivered.
- Input monitoring runs through the browser, so it has the browser's latency. It is not zero-latency hardware
  monitoring. The latency figure is what the browser reports; it was not measured acoustically.
- Feedback detection is based on device names. An unusual built-in device name may not be recognised.
- Recorded audio lives in browser storage until you export a package. Clearing site data deletes it.
- Elastic Audio stretch is not applied to recorded/imported audio. Changing the tempo after recording moves where the
  audio starts and ends in bars.
- Automated QA used the browsers' fake audio devices and a simulated loopback and hot-plug. It has **not** been run
  against a physical interface. Check your own interface with the loopback test.

## Pro multichannel / ASIO / plugins → native Apex Host
For ASIO, low-latency multichannel I/O and real VST3/AU plugins, use the native **Apex Host**. It is a JUCE desktop
app in the MY CONSOLE source tree at `engine/native-host/`, and is built on a Mac with `BUILD-ON-MAC.command`.
It is not part of this web package.
