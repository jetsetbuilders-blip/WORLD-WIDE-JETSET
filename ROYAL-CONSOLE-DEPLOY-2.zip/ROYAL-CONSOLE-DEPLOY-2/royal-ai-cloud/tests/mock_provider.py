#!/usr/bin/env python3
"""Fake OpenAI-compatible provider for tests (POST /v1/chat/completions).
Run standalone:  python3 tests/mock_provider.py --port 9911
"""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

STATE = {"mode": "ok", "requests": [], "auth": []}


def _content(req):
    ctx_txt = req["messages"][0]["content"]
    # pull the first track id out of the context so the mock can propose a valid action
    tid = None
    try:
        ctx = json.loads(ctx_txt.split("CONTEXT (validated session data, JSON):\n", 1)[1])
        tracks = ctx.get("tracks") or []
        tid = tracks[0]["id"] if tracks else None
    except (IndexError, ValueError, KeyError):
        ctx = {}
    user = req["messages"][-1]["content"]
    mode = STATE["mode"]
    if mode == "text":
        return "Plain text answer without JSON."
    ideas = []
    if tid:
        ideas.append({"title": "Tuck it 2 dB", "idea": "Lower the first track by 2 dB", "reason": "Mock evidence",
                      "effect": "More room", "risk": "Low", "method": "Fader", "action":
                      {"type": "set_fader", "track_id": tid, "delta_db": -2}})
    if mode == "bad_actions":
        ideas += [
            {"title": "Unknown track", "action": {"type": "set_fader", "track_id": "nope", "delta_db": -1}},
            {"title": "Raw prompt", "action": {"type": "run_shell", "cmd": "rm -rf /"}},
            {"title": "Too loud", "action": {"type": "set_fader", "track_id": tid, "delta_db": 40}},
            {"title": "Bad bus", "action": {"type": "set_send", "track_id": tid, "bus_id": "ghost", "level_db": -10}},
            {"title": "Protected", "action": {"type": "set_pan", "track_id": "vox", "pan": 0.5}},
            {"title": "Seventh idea (over the cap)", "action": None},
        ]
    return json.dumps({
        "reply": "MOCK CLOUD REPLY to: %s" % user[:80],
        "spoken": "Mock cloud answer. Try tucking the first track two dB.",
        "ideas": ideas,
    })


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        req = json.loads(self.rfile.read(n))
        STATE["requests"].append(req)
        STATE["auth"].append(self.headers.get("Authorization"))
        if STATE["mode"] == "error":
            self.send_response(500)
            self.send_header("Content-Length", "2")
            self.end_headers()
            self.wfile.write(b"{}")
            return
        body = json.dumps({"id": "mock", "model": req.get("model", "mock-model") + "-mock",
                           "choices": [{"message": {"role": "assistant", "content": _content(req)}}],
                           "usage": {"prompt_tokens": 1234, "completion_tokens": 321}}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def start(port=0):
    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


if __name__ == "__main__":
    port = int(sys.argv[sys.argv.index("--port") + 1]) if "--port" in sys.argv else 9911
    s = start(port)
    print("mock provider on http://127.0.0.1:%d/v1" % s.server_address[1], flush=True)
    threading.Event().wait()
