# Royal AI Cloud — Royal AI Gateway (ROYALCLOUD-1)

    MY CONSOLE (browser)  ──HTTPS/HTTP same-origin──▶  Royal AI Gateway (this folder)  ──▶  OpenAI (or compatible)
          no provider key                    auth · license · credits · rate limits ·          provider key lives
          opaque session token               validation · orchestrator · memory                ONLY here

Python 3.8+ standard library only. No installs.

## Run
    python3 server.py                 # console + API on http://127.0.0.1:8765 (asks for the key once)
    python3 server.py --open-browser  # what OPEN.command does
    python3 server.py set-key         # set / replace provider key (hidden prompt)
    python3 server.py clear-key
    python3 server.py status
    python3 server.py license create --credits 2000 --user "Client Name" --plan PRO --max-devices 3 --days 365
    python3 server.py license list
    python3 server.py license revoke RYL-XXXX-XXXX-XXXX-XXXX
    python3 server.py credits add RYL-XXXX-XXXX-XXXX-XXXX 500

Env: `OPENAI_API_KEY` (overrides secrets.json), `OPENAI_BASE_URL` (compatible endpoint),
`ROYAL_MODEL`, `ROYAL_DATA_DIR`, `ROYAL_PORT`, `ROYAL_HOST`, `ROYAL_WEB_ROOT`.

## Data (never inside the app folder)
macOS: `~/Library/Application Support/RoyalAICloud/` (dir 700, files 600)
- `secrets.json` — provider key (or `skipped` flag)
- `hmac_secret`  — token signing secret
- `royal.db`     — users, licenses, devices, usage_log, abuse_events, producer memory
- `config.json`  — optional overrides (models, per-op model map, costs, caps, rate limits), e.g.
  `{"provider": {"default_model": "gpt-4o-mini", "model_for_op": {"mastering_analysis": "gpt-4o"}}}`

## API
    GET  /v1/health                 status, version, provider_configured
    POST /v1/auth/device            {device_id, license_key?} -> signed token (12 h)
    GET  /v1/account                plan, credits, license, cost table
    POST /v1/ai/{operation}         quick_question | track_analysis | session_analysis | creative_analysis |
                                    mix_analysis | mastering_analysis | audition_generation | session_diagnostic
    GET  /v1/memory/profile  PUT /v1/memory/profile  POST /v1/memory/decision
    GET  /v1/usage

## Tests
    python3 -m unittest discover -s tests -v     # uses a local mock provider; no network, no real key

## Production mode (public HTTPS deployment)
    ROYAL_PRODUCTION=1 ROYAL_PUBLIC_ORIGINS=https://console.example.com ROYAL_TRUST_PROXY=1 \
    ROYAL_DATA_DIR=/data ROYAL_WEB_ROOT=/app/web OPENAI_API_KEY=... python3 server.py --host 0.0.0.0 --no-prompt

- DEV auto-license is OFF: customers enter their license key in the panel (⚙ Settings).
- Host/Origin allow-lists come from `ROYAL_PUBLIC_ORIGINS` (startup fails without it).
- HSTS on every response; rate limits use the proxy's X-Forwarded-For when `ROYAL_TRUST_PROXY=1`.
- `/v1/health` answers any Host (for platform health checks); everything else requires an allowed Host.
- `python3 server.py backup` makes an online-safe copy of royal.db.
- Run exactly one instance (SQLite + in-memory rate limits).

Full guide with Dockerfile / docker-compose / Caddy / Fly / Render / Railway: `DEPLOY-CLOUD.md` in the deploy package.
