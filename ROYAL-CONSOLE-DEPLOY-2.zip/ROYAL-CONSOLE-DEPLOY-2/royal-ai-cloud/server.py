#!/usr/bin/env python3
"""Royal AI Cloud — local gateway for MY CONSOLE (ROYALCLOUD-1).

    python3 server.py                  serve console + API on http://127.0.0.1:8765
    python3 server.py set-key          (re)set the provider API key (hidden prompt)
    python3 server.py clear-key        remove the saved provider key
    python3 server.py status           show data dir, provider, licenses
    python3 server.py backup [--out F] online-safe copy of royal.db (no secrets)
    ROYAL_PRODUCTION=1 ROYAL_PUBLIC_ORIGINS=https://console.example.com python3 server.py --host 0.0.0.0
    python3 server.py license create --credits 2000 --user "Name" [--plan PRO] [--max-devices 3] [--days 365] [--ops quick_question,mix_analysis]
    python3 server.py license list | license revoke KEY | license reset-devices KEY
    python3 server.py credits add KEY 500

Python 3.8+ standard library only. The provider key is read from $OPENAI_API_KEY or
<data dir>/secrets.json (chmod 600) and never leaves this process except as the
Authorization header sent to the provider.
"""
from __future__ import annotations

import argparse
import getpass
import os
import sys
import threading
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from royal_gateway import SERVICE, VERSION  # noqa: E402
from royal_gateway.config import default_data_dir, load_config  # noqa: E402
from royal_gateway.secrets_store import Secrets  # noqa: E402

if sys.version_info < (3, 8):
    sys.exit("Royal AI Cloud needs Python 3.8 or newer (found %s)" % sys.version.split()[0])


def find_web_root(explicit=None):
    cands = [explicit, os.environ.get("ROYAL_WEB_ROOT"),
             os.path.join(HERE, "..", "MY-CONSOLE"), os.path.join(HERE, ".."),
             os.path.join(HERE, "..", "..", "dist")]
    for c in cands:
        if c and os.path.isfile(os.path.join(c, "index.html")):
            return os.path.realpath(c)
    return None


def prompt_key(secrets: Secrets, force=False) -> bool:
    if not force and (secrets.provider_key() or secrets.skipped()):
        return bool(secrets.provider_key())
    if not sys.stdin.isatty():
        return False
    print("")
    print("  Royal AI Cloud — provider key setup")
    print("  Your OpenAI API key is stored ONLY on this computer:")
    print("    %s (chmod 600)" % secrets.path)
    print("  It is never sent to the browser and never put in the app files.")
    print("  Press Enter to skip (the console then runs as OFFLINE SESSION GUARDIAN).")
    try:
        key = getpass.getpass("  OpenAI API key (hidden): ").strip()
    except (EOFError, KeyboardInterrupt):
        print("")
        key = ""
    if not key:
        if not force:
            secrets.mark_skipped()
        print("  Skipped. Set it later with:  python3 royal-ai-cloud/server.py set-key")
        return False
    if len(key) < 20 or any(ch.isspace() for ch in key):
        print("  That doesn't look like an API key — not saved.")
        return False
    secrets.set_provider_key(key)
    print("  Saved. (key ending …%s)" % key[-4:])
    return True


def cmd_serve(args):
    from royal_gateway.http_app import App
    from royal_gateway.config import ConfigError
    if args.production:
        os.environ["ROYAL_PRODUCTION"] = "1"
    data_dir = args.data_dir or default_data_dir()
    secrets = Secrets(data_dir)
    production = os.environ.get("ROYAL_PRODUCTION", "").lower() in ("1", "true", "yes", "on")
    if not args.no_prompt and not production:
        prompt_key(secrets)
    root = find_web_root(args.web_root)
    try:
        app = App(data_dir, root)
    except ConfigError as e:
        sys.exit("[royal] Configuration error: %s" % e)
    host = args.host or app.cfg["host"]
    port = args.port if args.port is not None else app.cfg["port"]
    try:
        srv = app.make_server(host, port)
    except OSError as e:
        sys.exit("[royal] Could not listen on %s:%s (%s). Is another copy running?" % (host, port, e.strerror))
    url = "http://127.0.0.1:%d/" % srv.server_address[1]
    print("")
    print("  %s %s" % (SERVICE, VERSION))
    print("  Console + API:  %s" % url)
    print("  Web root:       %s" % (root or "(none found — API only)"))
    print("  Data dir:       %s" % data_dir)
    print("  Mode:           %s" % ("PRODUCTION (license keys required; origins: %s)" % ", ".join(app.cfg["public_origins"])
                                        if app.production else "local (DEV license auto-created)"))
    print("  Provider:       %s (%s)" % ("configured" if app.provider_configured() else "NOT configured — offline mode",
                                        app.cfg["provider"]["base_url"].split("//")[-1].split("/")[0]))
    print("  Stop with Ctrl+C (or close this window).")
    print("")
    if args.open_browser:
        threading.Timer(0.4, lambda: webbrowser.open(url + "index.html")).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


def _store(args):
    from royal_gateway.store import Store
    from royal_gateway.config import ensure_private_dir
    d = args.data_dir or default_data_dir()
    ensure_private_dir(d)
    return Store(d), d


def cmd_license(args):
    import json
    import time
    st, _ = _store(args)
    if args.action == "create":
        uid = st.create_user(args.user, args.credits, args.email)
        ops = "*" if not args.ops else [o.strip() for o in args.ops.split(",") if o.strip()]
        key = st.create_license(uid, args.plan.upper(), args.max_devices, args.days, ops)
        print("License created: %s  user=%s plan=%s credits=%d max_devices=%d expires=%s"
              % (key, args.user, args.plan.upper(), args.credits, args.max_devices,
                 ("in %d days" % args.days) if args.days else "never"))
    elif args.action == "list":
        for r in st.q("SELECT l.*, u.name, u.credits FROM licenses l JOIN users u ON u.id=l.user_id ORDER BY l.created_at"):
            exp = time.strftime("%Y-%m-%d", time.localtime(r["expires_at"])) if r["expires_at"] else "never"
            print("%-24s %-6s %-8s %-18s credits=%-6d devices=%d/%d expires=%s ops=%s" % (
                r["key"], r["plan"], r["status"], r["name"], r["credits"], st.device_count(r["key"]),
                r["max_devices"], exp, r["allowed_ops"] if r["allowed_ops"] == "*" else ",".join(json.loads(r["allowed_ops"]))))
    elif args.action == "reset-devices":
        n, _ = st.x("DELETE FROM devices WHERE license_key=?", (args.key,))
        print("Removed %d device registration(s). Browsers sign in again automatically." % n)
    elif args.action == "revoke":
        n, _ = st.x("UPDATE licenses SET status='revoked' WHERE key=?", (args.key,))
        print("Revoked." if n else "No such license.")


def cmd_credits(args):
    st, _ = _store(args)
    lic = st.license(args.key)
    if not lic:
        sys.exit("No such license.")
    print("Credits now: %d" % st.add_credits(lic["user_id"], args.amount))


def cmd_backup(args):
    """Online-safe SQLite backup (licenses, credits, usage, memory). Secrets are NOT included."""
    import sqlite3
    import time
    d = args.data_dir or default_data_dir()
    src = os.path.join(d, "royal.db")
    if not os.path.isfile(src):
        sys.exit("No database at %s" % src)
    out = args.out or os.path.join(d, "backups", "royal-%s.db" % time.strftime("%Y%m%d-%H%M%S"))
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    a, b = sqlite3.connect(src), sqlite3.connect(out)
    with b:
        a.backup(b)
    a.close()
    b.close()
    try:
        os.chmod(out, 0o600)
    except OSError:
        pass
    print("Backup written: %s" % out)


def cmd_status(args):
    d = args.data_dir or default_data_dir()
    s = Secrets(d)
    cfg = load_config(d)
    print("%s %s" % (SERVICE, VERSION))
    print("Data dir:  %s" % d)
    print("Provider:  %s  key source=%s  base=%s  model=%s" % (
        "configured" if s.provider_key() else "not configured", s.key_source(),
        cfg["provider"]["base_url"], cfg["provider"]["default_model"]))
    print("Web root:  %s" % (find_web_root() or "(none)"))
    args.action = "list"
    cmd_license(args)


def drop_privileges():
    """Container support: when started as root with ROYAL_RUN_AS=<user>, make the data dir owned by that
    user (mounted volumes are often root-owned) and switch to it before doing anything else."""
    user = os.environ.get("ROYAL_RUN_AS")
    if not user or not hasattr(os, "geteuid") or os.geteuid() != 0:
        return
    import pwd
    pw = pwd.getpwnam(user)
    data = default_data_dir()
    os.makedirs(data, exist_ok=True)
    for root, dirs, files in os.walk(data):
        for n in [root] + [os.path.join(root, x) for x in dirs + files]:
            os.chown(n, pw.pw_uid, pw.pw_gid)
    os.chmod(data, 0o700)
    os.setgroups([])
    os.setgid(pw.pw_gid)
    os.setuid(pw.pw_uid)
    os.environ["HOME"] = pw.pw_dir


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):  # Windows consoles (cp1252) must never crash on symbols
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    os.umask(0o077)
    drop_privileges()  # everything the gateway writes (db, WAL, secrets) is owner-only
    ap = argparse.ArgumentParser(prog="server.py", description="Royal AI Cloud gateway for MY CONSOLE")
    ap.add_argument("--data-dir", help="override data dir (default: %s)" % default_data_dir())
    sub = ap.add_subparsers(dest="cmd")
    sv = sub.add_parser("serve")
    for p in (ap, sv):
        p.add_argument("--host", default=None, help=argparse.SUPPRESS if p is ap else "bind address (default 127.0.0.1)")
        p.add_argument("--port", type=int, default=None, help=argparse.SUPPRESS if p is ap else "port (default 8765)")
        p.add_argument("--web-root", default=None, help=argparse.SUPPRESS if p is ap else "folder with index.html")
        p.add_argument("--no-prompt", action="store_true", help=argparse.SUPPRESS if p is ap else "never prompt for key")
        p.add_argument("--open-browser", action="store_true", help=argparse.SUPPRESS if p is ap else "open the console")
        p.add_argument("--production", action="store_true", help=argparse.SUPPRESS if p is ap else "public deployment mode")
    sub.add_parser("set-key")
    sub.add_parser("clear-key")
    sub.add_parser("status")
    bp = sub.add_parser("backup")
    bp.add_argument("--out", default=None, help="backup file path (default: <data dir>/backups/royal-<time>.db)")
    lp = sub.add_parser("license")
    lsub = lp.add_subparsers(dest="action")
    lc = lsub.add_parser("create")
    lc.add_argument("--credits", type=int, required=True)
    lc.add_argument("--user", default="Customer")
    lc.add_argument("--email", default=None)
    lc.add_argument("--plan", default="PRO")
    lc.add_argument("--max-devices", type=int, default=3)
    lc.add_argument("--days", type=int, default=None)
    lc.add_argument("--ops", default=None, help="comma list; default all operations")
    lsub.add_parser("list")
    lr = lsub.add_parser("revoke")
    lr.add_argument("key")
    lrd = lsub.add_parser("reset-devices")
    lrd.add_argument("key")
    cp = sub.add_parser("credits")
    csub = cp.add_subparsers(dest="action")
    ca = csub.add_parser("add")
    ca.add_argument("key")
    ca.add_argument("amount", type=int)
    args = ap.parse_args(argv)
    if args.cmd in (None, "serve"):
        return cmd_serve(args)
    if args.cmd == "set-key":
        prompt_key(Secrets(args.data_dir or default_data_dir()), force=True)
        print("  (A running server picks up the new key automatically.)")
    elif args.cmd == "clear-key":
        Secrets(args.data_dir or default_data_dir()).clear_provider_key()
        print("Provider key removed from secrets.json.")
    elif args.cmd == "backup":
        cmd_backup(args)
    elif args.cmd == "status":
        cmd_status(args)
    elif args.cmd == "license":
        if not args.action:
            lp.print_help()
        else:
            cmd_license(args)
    elif args.cmd == "credits":
        if not args.action:
            cp.print_help()
        else:
            cmd_credits(args)


if __name__ == "__main__":
    main()
