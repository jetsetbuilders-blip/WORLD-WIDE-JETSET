"""OpenAI-compatible chat completions over urllib. The key is only placed in the
Authorization header of the outbound request; it is never logged or returned."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.request


class ProviderError(Exception):
    def __init__(self, code: str, status: int = 502):
        super().__init__(code)
        self.code = code
        self.status = status


def chat(base_url: str, api_key: str, model: str, messages: list, temperature: float, max_tokens: int,
         timeout: float, json_mode: bool) -> dict:
    url = base_url.rstrip("/")
    if not url.endswith("/chat/completions"):
        url += "/chat/completions"
    body = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    data = json.dumps(body).encode()
    last = None
    for attempt in range(2):
        req = urllib.request.Request(url, data=data, method="POST", headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + api_key,
            "User-Agent": "RoyalAIGateway/1",
        })
        t0 = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8", "replace"))
            latency = int((time.monotonic() - t0) * 1000)
            choice = (payload.get("choices") or [{}])[0]
            content = ((choice.get("message") or {}).get("content") or "").strip()
            usage = payload.get("usage") or {}
            return {
                "content": content,
                "model": payload.get("model") or model,
                "input_tokens": usage.get("prompt_tokens"),
                "output_tokens": usage.get("completion_tokens"),
                "latency_ms": latency,
            }
        except urllib.error.HTTPError as e:
            # Do NOT echo the provider body (could contain request details).
            if e.code in (401, 403):
                raise ProviderError("provider_auth_failed", 502)
            if e.code == 429:
                last = ProviderError("provider_rate_limited", 503)
            elif e.code >= 500:
                last = ProviderError("provider_unavailable", 502)
            else:
                raise ProviderError("provider_rejected_request", 502)
        except (urllib.error.URLError, TimeoutError, OSError):
            last = ProviderError("provider_unreachable", 502)
        except ValueError:
            raise ProviderError("provider_bad_response", 502)
        time.sleep(0.4)
    raise last
