"""SQLite persistence: users, licenses, devices, usage log, abuse events, producer memory."""
from __future__ import annotations

import json
import os
import secrets
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT,
  credits INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS licenses (
  key TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  plan TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  expires_at INTEGER,
  max_devices INTEGER NOT NULL DEFAULT 3,
  allowed_ops TEXT NOT NULL DEFAULT '*',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS devices (
  license_key TEXT NOT NULL,
  device_id TEXT NOT NULL,
  device_name TEXT,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (license_key, device_id)
);
CREATE TABLE IF NOT EXISTS usage_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  device_id TEXT NOT NULL,
  op TEXT NOT NULL,
  specialist TEXT,
  status TEXT NOT NULL,
  cost INTEGER NOT NULL DEFAULT 0,
  model TEXT,
  input_tokens INTEGER,
  output_tokens INTEGER,
  latency_ms INTEGER,
  request_id TEXT
);
CREATE INDEX IF NOT EXISTS usage_user_at ON usage_log(user_id, at);
CREATE TABLE IF NOT EXISTS abuse_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at INTEGER NOT NULL,
  subject TEXT NOT NULL,
  kind TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS abuse_subject_at ON abuse_events(subject, at);
CREATE TABLE IF NOT EXISTS memory_profile (
  user_id TEXT PRIMARY KEY,
  profile_json TEXT NOT NULL,
  workflow_json TEXT NOT NULL DEFAULT '{}',
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS memory_decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  at INTEGER NOT NULL,
  session TEXT,
  text TEXT NOT NULL,
  verdict TEXT,
  idea_key TEXT,
  category TEXT,
  tags TEXT,
  client_at INTEGER,
  UNIQUE(user_id, client_at, text)
);
CREATE TABLE IF NOT EXISTS memory_notes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  session TEXT,
  note TEXT NOT NULL,
  at INTEGER NOT NULL,
  client_at INTEGER,
  UNIQUE(user_id, client_at, note)
);
"""


def now() -> int:
    return int(time.time())


def new_license_key(prefix: str = "RYL") -> str:
    raw = secrets.token_hex(8).upper()
    return "%s-%s-%s-%s-%s" % (prefix, raw[0:4], raw[4:8], raw[8:12], raw[12:16])


class Store:
    def __init__(self, data_dir: str):
        self.path = os.path.join(data_dir, "royal.db")
        existed = os.path.isfile(self.path)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript(SCHEMA)
        if not existed:
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass

    def q(self, sql, args=()):
        with self.lock:
            return self.db.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        with self.lock:
            return self.db.execute(sql, args).fetchone()

    def x(self, sql, args=()):
        with self.lock:
            cur = self.db.execute(sql, args)
            return cur.rowcount, cur.lastrowid

    # --- users & licenses ----------------------------------------------------
    def create_user(self, name: str, credits: int, email: str = None) -> str:
        uid = "usr_" + secrets.token_hex(6)
        self.x("INSERT INTO users(id,name,email,credits,created_at) VALUES(?,?,?,?,?)", (uid, name, email, int(credits), now()))
        return uid

    def create_license(self, user_id: str, plan: str, max_devices: int = 3, days: int = None,
                       allowed_ops="*", key: str = None, prefix: str = "RYL") -> str:
        key = key or new_license_key(prefix)
        exp = now() + int(days) * 86400 if days else None
        ops = allowed_ops if isinstance(allowed_ops, str) else json.dumps(list(allowed_ops))
        self.x("INSERT INTO licenses(key,user_id,plan,status,expires_at,max_devices,allowed_ops,created_at) VALUES(?,?,?,?,?,?,?,?)",
               (key, user_id, plan, "active", exp, int(max_devices), ops, now()))
        return key

    def dev_license(self):
        return self.one("SELECT * FROM licenses WHERE plan='DEV' AND status='active' ORDER BY created_at LIMIT 1")

    def ensure_dev_license(self, name: str, credits: int):
        row = self.one("SELECT * FROM licenses WHERE plan='DEV' ORDER BY created_at LIMIT 1")
        if row:
            return row["key"], False
        uid = self.create_user(name, credits)
        key = self.create_license(uid, "DEV", max_devices=100, days=None, prefix="DEV")
        return key, True

    def license(self, key: str):
        return self.one("SELECT * FROM licenses WHERE key=?", (key,))

    def user(self, uid: str):
        return self.one("SELECT * FROM users WHERE id=?", (uid,))

    @staticmethod
    def license_ops(row) -> object:
        ops = row["allowed_ops"]
        if ops == "*":
            return "*"
        try:
            return set(json.loads(ops))
        except ValueError:
            return set()

    # --- devices ---------------------------------------------------------------
    def device(self, key: str, device_id: str):
        return self.one("SELECT * FROM devices WHERE license_key=? AND device_id=?", (key, device_id))

    def device_count(self, key: str) -> int:
        return self.one("SELECT COUNT(*) c FROM devices WHERE license_key=? AND revoked=0", (key,))["c"]

    def register_device(self, key: str, device_id: str, name: str):
        t = now()
        self.x("INSERT INTO devices(license_key,device_id,device_name,first_seen,last_seen) VALUES(?,?,?,?,?) "
               "ON CONFLICT(license_key,device_id) DO UPDATE SET last_seen=excluded.last_seen", (key, device_id, name, t, t))

    # --- credits ---------------------------------------------------------------
    def credits(self, uid: str) -> int:
        r = self.user(uid)
        return int(r["credits"]) if r else 0

    def deduct(self, uid: str, amount: int) -> bool:
        n, _ = self.x("UPDATE users SET credits = credits - ? WHERE id=? AND credits >= ?", (int(amount), uid, int(amount)))
        return n == 1

    def add_credits(self, uid: str, amount: int) -> int:
        self.x("UPDATE users SET credits = credits + ? WHERE id=?", (int(amount), uid))
        return self.credits(uid)

    # --- usage -----------------------------------------------------------------
    def log_usage(self, **kw):
        cols = ["at", "user_id", "device_id", "op", "specialist", "status", "cost", "model",
                "input_tokens", "output_tokens", "latency_ms", "request_id"]
        kw.setdefault("at", now())
        self.x("INSERT INTO usage_log(%s) VALUES(%s)" % (",".join(cols), ",".join("?" * len(cols))),
               tuple(kw.get(c) for c in cols))

    def ops_today(self, uid: str, op: str) -> int:
        start = now() - (now() % 86400)
        return self.one("SELECT COUNT(*) c FROM usage_log WHERE user_id=? AND op=? AND at>=? AND status='ok'",
                        (uid, op, start))["c"]

    def recent_usage(self, uid: str, limit: int = 25):
        return [dict(r) for r in self.q(
            "SELECT at,op,specialist,status,cost,model,input_tokens,output_tokens,latency_ms FROM usage_log "
            "WHERE user_id=? ORDER BY id DESC LIMIT ?", (uid, int(limit)))]

    def usage_totals(self, uid: str, since: int):
        r = self.one("SELECT COUNT(*) n, COALESCE(SUM(cost),0) credits, COALESCE(SUM(input_tokens),0) tin, "
                     "COALESCE(SUM(output_tokens),0) tout FROM usage_log WHERE user_id=? AND at>=? AND status='ok'",
                     (uid, since))
        return {"requests": r["n"], "credits": r["credits"], "input_tokens": r["tin"], "output_tokens": r["tout"]}

    # --- abuse -----------------------------------------------------------------
    def abuse(self, subject: str, kind: str):
        self.x("INSERT INTO abuse_events(at,subject,kind) VALUES(?,?,?)", (now(), subject, kind))

    def abuse_count(self, subject: str, window: int) -> int:
        return self.one("SELECT COUNT(*) c FROM abuse_events WHERE subject=? AND at>=?", (subject, now() - window))["c"]

    # --- memory ----------------------------------------------------------------
    def get_profile(self, uid: str):
        r = self.one("SELECT * FROM memory_profile WHERE user_id=?", (uid,))
        if not r:
            return {}, {}, None
        return json.loads(r["profile_json"]), json.loads(r["workflow_json"]), r["updated_at"]

    def put_profile(self, uid: str, profile: dict, workflow: dict):
        self.x("INSERT INTO memory_profile(user_id,profile_json,workflow_json,updated_at) VALUES(?,?,?,?) "
               "ON CONFLICT(user_id) DO UPDATE SET profile_json=excluded.profile_json, workflow_json=excluded.workflow_json, "
               "updated_at=excluded.updated_at", (uid, json.dumps(profile), json.dumps(workflow), now()))

    def add_decision(self, uid: str, d: dict) -> bool:
        if d.get("verdict") == "note":
            n, _ = self.x("INSERT OR IGNORE INTO memory_notes(user_id,session,note,at,client_at) VALUES(?,?,?,?,?)",
                          (uid, d.get("session"), d["text"], now(), d.get("at")))
            return n == 1
        n, _ = self.x("INSERT OR IGNORE INTO memory_decisions(user_id,at,session,text,verdict,idea_key,category,tags,client_at) "
                      "VALUES(?,?,?,?,?,?,?,?,?)",
                      (uid, now(), d.get("session"), d["text"], d.get("verdict"), d.get("idea_key"), d.get("category"),
                       json.dumps(d.get("tags") or []), d.get("at")))
        return n == 1

    def recent_decisions(self, uid: str, limit: int = 20):
        return [dict(r) for r in self.q("SELECT session,text,verdict,idea_key,category,tags,client_at FROM memory_decisions "
                                        "WHERE user_id=? ORDER BY id DESC LIMIT ?", (uid, int(limit)))]

    def session_notes(self, uid: str, session: str = None, limit: int = 15):
        if session:
            rows = self.q("SELECT session,note FROM memory_notes WHERE user_id=? AND (session=? OR session IS NULL) "
                          "ORDER BY id DESC LIMIT ?", (uid, session, int(limit)))
        else:
            rows = self.q("SELECT session,note FROM memory_notes WHERE user_id=? ORDER BY id DESC LIMIT ?", (uid, int(limit)))
        return [dict(r) for r in rows]
