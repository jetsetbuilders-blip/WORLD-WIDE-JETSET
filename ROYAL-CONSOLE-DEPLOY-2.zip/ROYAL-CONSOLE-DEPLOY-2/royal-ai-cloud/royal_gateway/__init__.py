"""Royal AI Gateway — secure backend for MY CONSOLE (ROYALCLOUD-1 / DEPLOY-1 / DEPLOY-2).

Standard library only. DAW -> Royal AI Gateway -> OpenAI (or compatible).
The provider API key lives only on the server.
"""
VERSION = "3.21.0-deploy-2"
SERVICE = "Royal AI Gateway"
