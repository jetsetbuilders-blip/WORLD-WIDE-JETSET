"""AI Orchestrator: allowed operations only, specialist routing, server-side prompts,
memory injection, and validation of the model's structured output."""
from __future__ import annotations

import json
import re

from . import prompts
from .config import SPECIALIST_FOR, version_tuple
from .validation import ANALYSIS_NUMERIC

ALLOWED_OPS = tuple(SPECIALIST_FOR.keys())
ACTION_TYPES = ("set_fader", "set_pan", "set_send", "toggle_insert", "set_mute")
RISKS = ("Low", "Medium", "High")


class ContextRejected(Exception):
    def __init__(self, code: str, msg: str):
        super().__init__(msg)
        self.code = code
        self.msg = msg


def enforce_context_rules(ctx: dict, cfg: dict) -> dict:
    """Semantic rules on top of the schema. Mutates/returns ctx."""
    if version_tuple(ctx["system"]["client_version"]) < version_tuple(cfg["min_client_version"]):
        raise ContextRejected("client_version_unsupported", "Client build is older than %s" % cfg["min_client_version"])
    minp = version_tuple(cfg["min_plugin_version"])
    for p in ctx.get("plugins") or []:
        v = p.get("version")
        if v is not None and version_tuple(v) < minp:
            raise ContextRejected("plugin_version_unsupported",
                                  "Plugin %s version %s is below minimum %s" % (p.get("name"), v, cfg["min_plugin_version"]))
    a = ctx.get("analysis")
    if a is not None and not a.get("measured"):
        # Unmeasured means null. Never let placeholder numbers reach the model.
        for k in ANALYSIS_NUMERIC:
            if k in a:
                a[k] = None
        a["bands"] = None
        a["tracks"] = None
    return ctx


def build_messages(op: str, req: dict, memory: dict) -> list:
    spec = SPECIALIST_FOR[op]
    ctx = req["context"]
    system = "\n\n".join([
        prompts.PRINCIPLES,
        prompts.SPECIALISTS[spec],
        prompts.OP_TASK[op],
        prompts.ACTION_VOCAB,
        prompts.OUTPUT_FORMAT,
        "PRODUCER MEMORY (server-side, JSON):\n" + json.dumps(memory, separators=(",", ":"))[:6000],
        "CONTEXT (validated session data, JSON):\n" + json.dumps(
            {k: v for k, v in ctx.items() if k != "history"}, separators=(",", ":"))[:60000],
    ])
    msgs = [{"role": "system", "content": system}]
    for h in (ctx.get("history") or [])[-6:]:
        msgs.append({"role": h["role"], "content": h["content"]})
    user = req.get("utterance") or {
        "track_analysis": "Analyse track %s." % (req.get("focus_track_id") or "(none given)"),
        "mastering_analysis": "Mastering check%s." % ((" for target " + req["target"]) if req.get("target") else ""),
    }.get(op, prompts.OP_TASK[op].replace("TASK: ", ""))
    msgs.append({"role": "user", "content": user})
    return msgs


_FENCE = re.compile(r"^```(?:json)?\s*|\s*```$", re.I)


def _parse_json(content: str):
    s = _FENCE.sub("", (content or "").strip())
    try:
        v = json.loads(s)
        return v if isinstance(v, dict) else None
    except ValueError:
        i, j = s.find("{"), s.rfind("}")
        if 0 <= i < j:
            try:
                v = json.loads(s[i:j + 1])
                return v if isinstance(v, dict) else None
            except ValueError:
                return None
    return None


def _num(v, lo, hi):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
        return None
    return v if lo <= v <= hi else None


def _txt(v, n):
    return v.strip()[:n] if isinstance(v, str) else ""


def validate_action(a, ctx: dict):
    """Returns (clean_action | None, rejection_reason | None)."""
    if a is None:
        return None, None
    if not isinstance(a, dict) or a.get("type") not in ACTION_TYPES:
        return None, "action type not allowed"
    tracks = {t["id"]: t for t in ctx.get("tracks") or []}
    protected = set(x.lower() for x in ((ctx.get("profile") or {}).get("protected_tracks") or []))
    tid = a.get("track_id")
    if tid not in tracks:
        return None, "unknown track"
    if tracks[tid]["name"].lower() in protected:
        return None, "track is protected by the producer"
    t = a["type"]
    if t == "set_fader":
        d = _num(a.get("delta_db"), -12, 6)
        return ({"type": t, "track_id": tid, "delta_db": round(d, 2)}, None) if d is not None else (None, "delta_db out of range")
    if t == "set_pan":
        p = _num(a.get("pan"), -1, 1)
        return ({"type": t, "track_id": tid, "pan": round(p, 3)}, None) if p is not None else (None, "pan out of range")
    if t == "set_mute":
        return ({"type": t, "track_id": tid, "mute": a["mute"]}, None) if isinstance(a.get("mute"), bool) else (None, "mute must be boolean")
    if t == "set_send":
        routing = ctx.get("routing") or {}
        buses = set(routing.get("buses") or []) | set(r["bus_id"] for r in routing.get("returns") or [])
        if a.get("bus_id") not in buses:
            return None, "unknown bus"
        lv = _num(a.get("level_db"), -60, 6)
        if lv is None:
            return None, "level_db out of range"
        out = {"type": t, "track_id": tid, "bus_id": a["bus_id"], "level_db": round(lv, 1)}
        if isinstance(a.get("pre_fader"), bool):
            out["pre_fader"] = a["pre_fader"]
        return out, None
    if t == "toggle_insert":
        slots = set(p["slot"] for p in ctx.get("plugins") or [] if p.get("track_id") == tid)
        if a.get("slot") not in slots:
            return None, "unknown insert slot"
        if not isinstance(a.get("bypassed"), bool):
            return None, "bypassed must be boolean"
        return {"type": t, "track_id": tid, "slot": a["slot"], "bypassed": a["bypassed"]}, None
    return None, "action type not allowed"


def validate_output(content: str, ctx: dict) -> dict:
    data = _parse_json(content)
    if data is None:
        text = _txt(content, 4000) or "(The model returned an empty answer.)"
        return {"reply": text, "spoken": _txt(text, 300), "ideas": [], "structured": False, "rejected_actions": 0}
    ideas, rejected = [], 0
    for raw in (data.get("ideas") or [])[:6] if isinstance(data.get("ideas"), list) else []:
        if not isinstance(raw, dict):
            continue
        action, why = validate_action(raw.get("action"), ctx)
        if why:
            rejected += 1
        risk = raw.get("risk") if raw.get("risk") in RISKS else "Medium"
        ideas.append({
            "title": _txt(raw.get("title"), 120) or _txt(raw.get("idea"), 80) or "Idea",
            "idea": _txt(raw.get("idea"), 600), "reason": _txt(raw.get("reason"), 600),
            "effect": _txt(raw.get("effect"), 400), "risk": risk, "method": _txt(raw.get("method"), 600),
            "action": action, "action_rejected": why,
        })
    reply = _txt(data.get("reply"), 6000) or "(no reply)"
    spoken = _txt(data.get("spoken"), 500) or _txt(reply, 300)
    return {"reply": reply, "spoken": spoken, "ideas": ideas, "structured": True, "rejected_actions": rejected}
