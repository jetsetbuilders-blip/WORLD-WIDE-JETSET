"""In-memory token buckets (per user, per device, per IP for auth)."""
from __future__ import annotations

import threading
import time


class Buckets:
    def __init__(self):
        self._b = {}
        self._lock = threading.Lock()

    def take(self, key: str, capacity: float, per_sec: float, cost: float = 1.0) -> (bool, float):
        """Returns (allowed, retry_after_seconds)."""
        now = time.monotonic()
        with self._lock:
            tokens, last = self._b.get(key, (float(capacity), now))
            tokens = min(float(capacity), tokens + (now - last) * per_sec)
            if tokens >= cost:
                self._b[key] = (tokens - cost, now)
                return True, 0.0
            self._b[key] = (tokens, now)
            need = (cost - tokens) / per_sec if per_sec > 0 else 60.0
            return False, max(1.0, need)
