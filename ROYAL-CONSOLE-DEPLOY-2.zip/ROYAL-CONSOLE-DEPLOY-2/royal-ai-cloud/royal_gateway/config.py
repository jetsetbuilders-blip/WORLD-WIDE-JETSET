"""Central configuration. Defaults here, overridable by <data_dir>/config.json and env."""
from __future__ import annotations

import json
import os
import sys
import copy
import re

# Royal AI Credits per operation (server-side only; the client just displays them).
DEFAULT_COSTS = {
    "quick_question": 1,
    "track_analysis": 3,
    "creative_analysis": 3,
    "session_analysis": 5,
    "session_diagnostic": 5,
    "audition_generation": 5,
    "mix_analysis": 6,
    "mastering_analysis": 6,
}

DEFAULT_DAILY_CAPS = {
    "quick_question": 400,
    "track_analysis": 120,
    "creative_analysis": 120,
    "session_analysis": 80,
    "session_diagnostic": 80,
    "audition_generation": 80,
    "mix_analysis": 60,
    "mastering_analysis": 60,
}

# Operation -> specialist
SPECIALIST_FOR = {
    "quick_question": "GENERAL",
    "track_analysis": "MIX",
    "mix_analysis": "MIX",
    "mastering_analysis": "MASTER",
    "creative_analysis": "CREATIVE",
    "audition_generation": "CREATIVE",
    "session_analysis": "DIAGNOSTIC",
    "session_diagnostic": "DIAGNOSTIC",
}

DEFAULTS = {
    "host": "127.0.0.1",
    "port": 8765,
    "provider": {
        "base_url": "https://api.openai.com/v1",
        "default_model": "gpt-4o-mini",
        # per-operation model override, e.g. {"mastering_analysis": "gpt-4o"}
        "model_for_op": {},
        "temperature": 0.4,
        "max_tokens": 900,
        "timeout_sec": 60,
        "json_mode": True,
    },
    "costs": DEFAULT_COSTS,
    "daily_caps": DEFAULT_DAILY_CAPS,
    "rate_limit": {
        # token buckets: capacity = burst, refill = per_sec
        "user_burst": 20,
        "user_per_sec": 0.5,
        "device_burst": 12,
        "device_per_sec": 0.34,
        "auth_burst": 10,
        "auth_per_sec": 0.2,
    },
    "abuse": {"window_sec": 3600, "flag_threshold": 12},
    "max_body_bytes": 256 * 1024,
    "max_utterance_chars": 1200,
    "token_ttl_sec": 12 * 3600,
    "min_client_version": "3.19.0",
    "min_plugin_version": "1.0.0",
    # Auto-create a DEV license on first local run so it "just works" on the Mac.
    "dev_autolicense": True,
    "dev_user_name": "Dav Black",
    "dev_credits": 5000,
    # Extra allowed browser origins (same-origin is always allowed).
    "allowed_origins": [],
    # Extra allowed Host headers (DNS-rebinding guard). Localhost forms always allowed.
    "allowed_hosts": [],
    # --- production (public HTTPS deployment) ---------------------------------------
    # production=True: DEV auto-license OFF, customers sign in with license keys,
    # public_origins required (e.g. ["https://console.example.com"]), HSTS on.
    "production": False,
    "public_origins": [],
    # Behind Caddy/nginx/Fly/Render: use the proxy's X-Forwarded-For for rate limits.
    "trust_proxy": False,
}


def default_data_dir() -> str:
    env = os.environ.get("ROYAL_DATA_DIR")
    if env:
        return os.path.abspath(os.path.expanduser(env))
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", "RoyalAICloud")
    if os.name == "nt":
        return os.path.join(os.environ.get("APPDATA", home), "RoyalAICloud")
    return os.path.join(os.environ.get("XDG_DATA_HOME", os.path.join(home, ".local", "share")), "RoyalAICloud")


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def ensure_private_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass


def load_config(data_dir: str) -> dict:
    cfg = copy.deepcopy(DEFAULTS)
    p = os.path.join(data_dir, "config.json")
    if os.path.isfile(p):
        try:
            with open(p, "r", encoding="utf-8") as fh:
                cfg = _merge(cfg, json.load(fh))
        except (OSError, ValueError) as e:
            print("[royal] config.json ignored (%s)" % e.__class__.__name__, file=sys.stderr)
    if os.environ.get("OPENAI_BASE_URL"):
        cfg["provider"]["base_url"] = os.environ["OPENAI_BASE_URL"].strip()
    if os.environ.get("ROYAL_MODEL"):
        cfg["provider"]["default_model"] = os.environ["ROYAL_MODEL"].strip()
    if os.environ.get("ROYAL_PORT"):
        cfg["port"] = int(os.environ["ROYAL_PORT"])
    if os.environ.get("ROYAL_HOST"):
        cfg["host"] = os.environ["ROYAL_HOST"]
    if os.environ.get("ROYAL_PRODUCTION"):
        cfg["production"] = _truthy(os.environ["ROYAL_PRODUCTION"])
    if os.environ.get("ROYAL_PUBLIC_ORIGINS"):
        cfg["public_origins"] = [o.strip() for o in os.environ["ROYAL_PUBLIC_ORIGINS"].split(",") if o.strip()]
    if os.environ.get("ROYAL_TRUST_PROXY"):
        cfg["trust_proxy"] = _truthy(os.environ["ROYAL_TRUST_PROXY"])
    if os.environ.get("ROYAL_DEV_CREDITS"):
        cfg["dev_credits"] = int(os.environ["ROYAL_DEV_CREDITS"])
    apply_production(cfg)
    return cfg


def _truthy(v) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes", "on")


class ConfigError(Exception):
    pass


_ORIGIN_RE = re.compile(r"^https?://[A-Za-z0-9.\-]+(:\d{1,5})?$")


def apply_production(cfg: dict) -> dict:
    """Derive Host/Origin allow-lists from public_origins; production forces DEV licensing off."""
    origins = []
    for o in cfg.get("public_origins") or []:
        o = o.rstrip("/")
        if not _ORIGIN_RE.match(o):
            raise ConfigError("public_origins entry %r must look like https://console.example.com" % o)
        origins.append(o)
    cfg["public_origins"] = origins
    hosts = set(cfg.get("allowed_hosts") or [])
    allowed = set(cfg.get("allowed_origins") or [])
    for o in origins:
        scheme, netloc = o.split("://", 1)
        hosts.add(netloc.lower())
        if ":" not in netloc:
            hosts.add("%s:%d" % (netloc.lower(), 443 if scheme == "https" else 80))
        allowed.add(o)
    cfg["allowed_hosts"] = sorted(hosts)
    cfg["allowed_origins"] = sorted(allowed)
    if cfg.get("production"):
        cfg["dev_autolicense"] = False
        if not origins:
            raise ConfigError("production mode needs ROYAL_PUBLIC_ORIGINS (e.g. https://console.example.com)")
        if any(o.startswith("http://") for o in origins) and not cfg.get("_warned_http"):
            cfg["_warned_http"] = True
            print("[royal] WARNING: production origin without HTTPS — put the server behind TLS", file=sys.stderr)
    return cfg


def version_tuple(v) -> tuple:
    parts = []
    for p in str(v).split("-")[0].split("."):
        n = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(n) if n else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])
