"""Signed session tokens: base64url(payload).base64url(HMAC-SHA256(server_secret, payload)).
The server secret never leaves the data dir; the client only sees the opaque token."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time


def _b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


class TokenError(Exception):
    pass


def issue(secret: bytes, user_id: str, device_id: str, license_key: str, ttl: int) -> (str, int):
    now = int(time.time())
    payload = {"u": user_id, "d": device_id, "l": license_key, "iat": now, "exp": now + int(ttl),
               "j": secrets.token_hex(8)}
    p = _b64e(json.dumps(payload, separators=(",", ":")).encode())
    sig = _b64e(hmac.new(secret, p.encode(), hashlib.sha256).digest())
    return p + "." + sig, payload["exp"]


def verify(secret: bytes, token: str) -> dict:
    if not token or len(token) > 1024 or token.count(".") != 1:
        raise TokenError("malformed")
    p, sig = token.split(".")
    want = _b64e(hmac.new(secret, p.encode(), hashlib.sha256).digest())
    if not hmac.compare_digest(want, sig):
        raise TokenError("bad_signature")
    try:
        payload = json.loads(_b64d(p))
    except (ValueError, TypeError):
        raise TokenError("malformed")
    if not isinstance(payload, dict) or int(payload.get("exp", 0)) < int(time.time()):
        raise TokenError("expired")
    return payload
