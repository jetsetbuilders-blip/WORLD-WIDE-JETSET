"""Provider key + HMAC secret storage. Files live in the private data dir (chmod 600),
never inside the web root, never logged, never sent to a client."""
from __future__ import annotations

import json
import os
import secrets
import threading

from .config import ensure_private_dir

_lock = threading.Lock()


def _write_private(path: str, data: bytes) -> None:
    tmp = path + ".tmp"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, data)
    finally:
        os.close(fd)
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    restrict_windows_acl(path)


def restrict_windows_acl(path: str) -> None:
    """Windows has no chmod 600: best-effort ACL so only the current user can read the file."""
    if os.name != "nt":
        return
    user = os.environ.get("USERNAME")
    if not user:
        return
    try:
        import subprocess
        subprocess.run(["icacls", path, "/inheritance:r", "/grant:r", "%s:F" % user],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=False)
    except Exception:  # noqa: BLE001 — permissions are best-effort on Windows
        pass


class Secrets:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        ensure_private_dir(data_dir)
        self.path = os.path.join(data_dir, "secrets.json")
        self._cache = None
        self._mtime = None

    # --- HMAC signing secret -------------------------------------------------
    def hmac_secret(self) -> bytes:
        p = os.path.join(self.data_dir, "hmac_secret")
        with _lock:
            if not os.path.isfile(p):
                _write_private(p, secrets.token_hex(32).encode())
            with open(p, "rb") as fh:
                return fh.read().strip()

    # --- provider key ---------------------------------------------------------
    def _read(self) -> dict:
        try:
            m = os.path.getmtime(self.path)
        except OSError:
            self._cache, self._mtime = {}, None
            return {}
        if self._cache is None or m != self._mtime:
            try:
                with open(self.path, "r", encoding="utf-8") as fh:
                    self._cache = json.load(fh) or {}
            except (OSError, ValueError):
                self._cache = {}
            self._mtime = m
        return self._cache

    def provider_key(self) -> str:
        env = os.environ.get("OPENAI_API_KEY", "").strip()
        if env:
            return env
        return str(self._read().get("openai_api_key", "")).strip()

    def key_source(self) -> str:
        if os.environ.get("OPENAI_API_KEY", "").strip():
            return "env"
        return "secrets.json" if self._read().get("openai_api_key") else "none"

    def skipped(self) -> bool:
        return bool(self._read().get("skipped"))

    def set_provider_key(self, key: str) -> None:
        data = dict(self._read())
        data.pop("skipped", None)
        data["openai_api_key"] = key.strip()
        with _lock:
            _write_private(self.path, json.dumps(data).encode())
        self._cache = None

    def clear_provider_key(self) -> None:
        data = dict(self._read())
        data.pop("openai_api_key", None)
        with _lock:
            _write_private(self.path, json.dumps(data).encode())
        self._cache = None

    def mark_skipped(self) -> None:
        data = dict(self._read())
        data["skipped"] = True
        with _lock:
            _write_private(self.path, json.dumps(data).encode())
        self._cache = None
