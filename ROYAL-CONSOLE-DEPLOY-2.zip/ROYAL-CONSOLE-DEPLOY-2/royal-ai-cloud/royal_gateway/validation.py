"""Strict, allow-list schema validation. Unknown fields are stripped (and counted);
wrong types / out-of-range values are rejected with the offending path."""
from __future__ import annotations

import re

ID_RE = re.compile(r"^[A-Za-z0-9_.:\-]{1,64}$")
SESSION_ID_RE = re.compile(r"^[A-Za-z0-9_\-]{1,64}$")
DEVICE_ID_RE = re.compile(r"^[A-Za-z0-9_\-]{8,64}$")
VERSION_RE = re.compile(r"^\d{1,4}(\.\d{1,4}){0,2}([\-+][A-Za-z0-9.\-]{1,32})?$")
TIMESIG_RE = re.compile(r"^\d{1,2}/\d{1,2}$")


class ValidationError(Exception):
    def __init__(self, path: str, msg: str, code: str = "invalid_field"):
        super().__init__("%s: %s" % (path, msg))
        self.path = path
        self.msg = msg
        self.code = code


# --- schema primitives --------------------------------------------------------
def S(maxlen=200, pattern=None, null=False, enum=None):
    return {"t": "str", "max": maxlen, "re": pattern, "null": null, "enum": enum}


def N(lo=None, hi=None, null=False, integer=False):
    return {"t": "num", "lo": lo, "hi": hi, "null": null, "int": integer}


def B(null=False):
    return {"t": "bool", "null": null}


def L(item, maxitems=64, null=False):
    return {"t": "list", "item": item, "max": maxitems, "null": null}


def O(fields, null=False, required=()):
    return {"t": "obj", "f": fields, "null": null, "req": tuple(required)}


class Result:
    def __init__(self):
        self.stripped = []


def clean(value, schema, path="$", res: Result = None):
    res = res if res is not None else Result()
    t = schema["t"]
    if value is None:
        if schema.get("null"):
            return None
        raise ValidationError(path, "required / not nullable")
    if t == "str":
        if not isinstance(value, str):
            raise ValidationError(path, "expected string")
        if len(value) > schema["max"]:
            raise ValidationError(path, "too long (max %d)" % schema["max"], "field_too_long")
        if schema.get("re") is not None and not schema["re"].match(value):
            raise ValidationError(path, "bad format")
        if schema.get("enum") and value not in schema["enum"]:
            raise ValidationError(path, "not an allowed value")
        return value
    if t == "num":
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValidationError(path, "expected number")
        if value != value or value in (float("inf"), float("-inf")):
            raise ValidationError(path, "not finite")
        if schema.get("int") and int(value) != value:
            raise ValidationError(path, "expected integer")
        if schema["lo"] is not None and value < schema["lo"]:
            raise ValidationError(path, "below %s" % schema["lo"])
        if schema["hi"] is not None and value > schema["hi"]:
            raise ValidationError(path, "above %s" % schema["hi"])
        return int(value) if schema.get("int") else value
    if t == "bool":
        if not isinstance(value, bool):
            raise ValidationError(path, "expected boolean")
        return value
    if t == "list":
        if not isinstance(value, list):
            raise ValidationError(path, "expected list")
        if len(value) > schema["max"]:
            raise ValidationError(path, "too many items (max %d)" % schema["max"], "field_too_long")
        return [clean(v, schema["item"], "%s[%d]" % (path, i), res) for i, v in enumerate(value)]
    if t == "obj":
        if not isinstance(value, dict):
            raise ValidationError(path, "expected object")
        out = {}
        for k, v in value.items():
            if k not in schema["f"]:
                res.stripped.append("%s.%s" % (path, str(k)[:40]))
                continue
            out[k] = clean(v, schema["f"][k], "%s.%s" % (path, k), res)
        for k in schema["req"]:
            if k not in out:
                raise ValidationError("%s.%s" % (path, k), "required")
        return out
    raise ValidationError(path, "schema error")


# --- request schemas ------------------------------------------------------------
_TRACK = O({
    "id": S(64, ID_RE), "name": S(80), "role": S(24), "type": S(24, null=True),
    "volume_db": N(-200, 24, null=True), "pan": N(-1, 1, null=True),
    "mute": B(True), "solo": B(True), "armed": B(True),
    "input": S(80, null=True), "output": S(80, null=True), "output_ok": B(True),
    "clip_count": N(0, 100000, True, True), "automation_points": N(0, 1000000, True, True),
}, required=("id", "name"))

_SEND = O({
    "track_id": S(64, ID_RE), "slot": S(16), "bus_id": S(64, ID_RE), "level_db": N(-200, 24, null=True),
    "pre_fader": B(True), "mute": B(True), "return_exists": B(True),
}, required=("track_id", "bus_id"))

_PLUGIN = O({
    "track_id": S(64, ID_RE), "slot": S(16), "name": S(80), "catalog_id": S(64, ID_RE, null=True),
    "type": S(40, null=True), "version": S(40, VERSION_RE, null=True), "bypassed": B(True),
    "latency": N(0, 1e6, null=True),
}, required=("track_id", "slot", "name"))

_BAND = O({"label": S(24), "lo": N(0, 48000), "hi": N(0, 48000), "db": N(-200, 60, null=True)})
_TRACK_LEVEL = O({"track_id": S(64, ID_RE), "rms_db": N(-200, 60, null=True), "peak_db": N(-200, 60, null=True)})

ANALYSIS_NUMERIC = ("tap_peak_db", "tap_rms_db", "out_peak_db", "out_rms_db", "crest_db", "approx_loudness",
                    "correlation", "side_to_mid_db", "clip_samples", "makeup_db", "duration_sec")

CONTEXT_SCHEMA = O({
    "session": O({
        "id": S(64, SESSION_ID_RE), "artist": S(80, null=True), "producer": S(80, null=True), "name": S(120),
        "bpm": N(20, 400, null=True), "key": S(24, null=True), "time_sig": S(8, TIMESIG_RE, null=True),
        "sample_rate": N(8000, 768000, null=True, integer=True),
    }, required=("id", "name")),
    "tracks": L(_TRACK, 160),
    "routing": O({
        "buses": L(S(64, ID_RE), 64),
        "returns": L(O({"bus_id": S(64, ID_RE), "track_id": S(64, ID_RE), "name": S(80)}), 64),
        "sends": L(_SEND, 512),
    }, null=True),
    "plugins": L(_PLUGIN, 640),
    "analysis": O({
        "measured": B(),
        "at": N(0, 1e13, null=True),
        "tap_peak_db": N(-200, 60, null=True), "tap_rms_db": N(-200, 60, null=True),
        "out_peak_db": N(-200, 60, null=True), "out_rms_db": N(-200, 60, null=True),
        "crest_db": N(0, 200, null=True), "approx_loudness": N(-200, 60, null=True),
        "correlation": N(-1, 1, null=True), "side_to_mid_db": N(-200, 200, null=True),
        "clip_samples": N(0, 1e9, null=True, integer=True), "makeup_db": N(-60, 60, null=True),
        "duration_sec": N(0, 600, null=True),
        "bands": L(_BAND, 16, null=True),
        "tracks": L(_TRACK_LEVEL, 160, null=True),
    }, null=True, required=("measured",)),
    "system": O({
        "ctx_state": S(24, null=True), "is_playing": B(True), "is_recording": B(True),
        "headroom_mode": S(40, null=True), "max_latency": N(0, 1e6, null=True), "browser": S(80, null=True),
        "client_version": S(40, VERSION_RE),
    }, required=("client_version",)),
    "profile": O({
        "producer_name": S(80, null=True), "protected_tracks": L(S(80), 32), "accepted_tags": L(S(40), 40),
        "rejected_tags": L(S(40), 40), "never_use": L(S(80), 32), "remembered": L(S(300), 20),
        "favorite_plugins": L(S(80), 20), "challenge_mode": B(True),
    }, null=True),
    "findings": L(O({"severity": S(12), "title": S(200), "detail": S(400, null=True)}), 40, null=True),
    "history": L(O({"role": S(12, enum=("user", "assistant")), "content": S(1200)}), 8, null=True),
}, required=("session", "tracks", "system"))

AI_REQUEST_SCHEMA = O({
    "utterance": S(1200, null=True),
    "focus_track_id": S(64, ID_RE, null=True),
    "target": S(40, null=True),
    "context": CONTEXT_SCHEMA,
}, required=("context",))

AUTH_SCHEMA = O({
    "device_id": S(64, DEVICE_ID_RE),
    "device_name": S(80, null=True),
    "license_key": S(64, re.compile(r"^[A-Z]{3}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$"), null=True),
    "client_version": S(40, VERSION_RE, null=True),
}, required=("device_id",))

PROFILE_SCHEMA = O({
    "profile": O({
        "producer_name": S(80, null=True), "engineer_name": S(80, null=True),
        "protected_tracks": L(S(80), 32), "never_use": L(S(80), 32), "remembered": L(S(300), 40),
        "favorite_plugins": L(S(80), 40), "blocked_ideas": L(S(160), 200), "challenge_mode": B(True),
        "accepted_categories": L(S(24), 8), "rejected_categories": L(S(24), 8),
    }, null=True),
    "workflow": O({
        "genres": L(S(40), 12), "reference_artists": L(S(80), 12), "preferred_loudness": S(40, null=True),
        "mix_style": S(200, null=True), "notes": S(1000, null=True),
    }, null=True),
})

DECISION_SCHEMA = O({
    "decisions": L(O({
        "at": N(0, 1e13, null=True, integer=True), "session": S(120, null=True), "text": S(400),
        "verdict": S(16, enum=("kept", "rejected", "blocked", "repaired", "approved", "skipped", "restored", "note"), null=True),
        "idea_key": S(160, null=True), "category": S(24, null=True), "tags": L(S(40), 16, null=True),
    }, required=("text",)), 50),
}, required=("decisions",))


def clean_tag_map(m):
    """accepted_tags/rejected_tags arrive as {tag: count}; clean manually (dynamic keys)."""
    out = {}
    if isinstance(m, dict):
        for k, v in list(m.items())[:80]:
            if isinstance(k, str) and len(k) <= 40 and isinstance(v, (int, float)) and not isinstance(v, bool):
                out[k] = max(0, min(10000, int(v)))
    return out
