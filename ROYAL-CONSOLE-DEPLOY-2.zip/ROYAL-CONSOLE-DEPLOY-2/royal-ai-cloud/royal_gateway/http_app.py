"""Royal AI Gateway HTTP layer: same-origin static file server for the console + JSON API."""
from __future__ import annotations

import json
import os
import posixpath
import secrets
import sys
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import SERVICE, VERSION, auth, orchestrator, provider
from .config import apply_production, ensure_private_dir, load_config
from .ratelimit import Buckets
from .secrets_store import Secrets
from .store import Store, now
from .validation import (AI_REQUEST_SCHEMA, AUTH_SCHEMA, DECISION_SCHEMA, PROFILE_SCHEMA, Result, ValidationError,
                         clean, clean_tag_map)

MIME = {
    ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8", ".mjs": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8",
    ".map": "application/json; charset=utf-8", ".webmanifest": "application/manifest+json",
    ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".gif": "image/gif", ".webp": "image/webp", ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8",
    ".wasm": "application/wasm", ".wav": "audio/wav", ".mp3": "audio/mpeg", ".ogg": "audio/ogg",
    ".flac": "audio/flac", ".m4a": "audio/mp4", ".aif": "audio/aiff", ".aiff": "audio/aiff",
    ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf", ".otf": "font/otf",
}

BASE_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "SAMEORIGIN",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "microphone=(self), camera=(), geolocation=()",
}
API_HEADERS = {
    "Cache-Control": "no-store",
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
    "X-Frame-Options": "DENY",
}


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str = "", extra: dict = None, headers: dict = None):
        super().__init__(code)
        self.status, self.code, self.message = status, code, message or code.replace("_", " ")
        self.extra = extra or {}
        self.headers = headers or {}


class App:
    def __init__(self, data_dir: str, web_root: str = None, overrides: dict = None, quiet: bool = False):
        ensure_private_dir(data_dir)
        self.data_dir = data_dir
        self.cfg = load_config(data_dir)
        for k, v in (overrides or {}).items():
            self.cfg[k] = v
        apply_production(self.cfg)
        self.production = bool(self.cfg.get("production"))
        self.web_root = os.path.realpath(web_root) if web_root else None
        self.server_dir = os.path.realpath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        self.secrets = Secrets(data_dir)
        self.hmac = self.secrets.hmac_secret()
        self.store = Store(data_dir)
        self.buckets = Buckets()
        self.quiet = quiet
        self.dev_key = None
        if self.cfg.get("dev_autolicense"):
            self.dev_key, created = self.store.ensure_dev_license(self.cfg["dev_user_name"], self.cfg["dev_credits"])
            if created and not quiet:
                print("[royal] Created local DEV license for %s with %d Royal AI Credits"
                      % (self.cfg["dev_user_name"], self.cfg["dev_credits"]))

    def provider_configured(self) -> bool:
        return bool(self.secrets.provider_key())

    def allowed_hosts(self, port: int):
        hs = {"127.0.0.1:%d" % port, "localhost:%d" % port, "[::1]:%d" % port}
        if port == 80:
            hs |= {"127.0.0.1", "localhost"}
        return hs | set(self.cfg.get("allowed_hosts") or [])

    def make_server(self, host=None, port=None) -> ThreadingHTTPServer:
        host = host or self.cfg["host"]
        port = self.cfg["port"] if port is None else port
        app = self

        class H(Handler):
            pass
        H.app = app
        srv = ThreadingHTTPServer((host, port), H)
        srv.daemon_threads = True
        H.port = srv.server_address[1]
        return srv


class Handler(BaseHTTPRequestHandler):
    app: App = None
    port: int = 0
    server_version = "RoyalAIGateway/1"
    sys_version = ""
    timeout = 30
    protocol_version = "HTTP/1.1"

    # ---------------------------------------------------------------- plumbing
    def log_message(self, fmt, *args):  # never logs headers/bodies (no key, no token)
        if not self.app.quiet:
            sys.stderr.write("[royal] %s %s\n" % (self.address_string(), fmt % args))

    def _headers(self, extra: dict):
        if self.app.production and "Strict-Transport-Security" not in extra:
            self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        for k, v in BASE_HEADERS.items():
            if k not in extra:
                self.send_header(k, v)
        for k, v in extra.items():
            self.send_header(k, v)

    def send_json(self, status: int, obj: dict, headers: dict = None):
        body = json.dumps(obj, separators=(",", ":")).encode()
        self.send_response(status)
        h = dict(API_HEADERS)
        h.update(headers or {})
        h["Content-Type"] = "application/json; charset=utf-8"
        h["Content-Length"] = str(len(body))
        self._headers(h)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_err(self, e: ApiError):
        obj = {"ok": False, "error": e.code, "message": e.message}
        obj.update(e.extra)
        self.send_json(e.status, obj, e.headers)

    def ip(self) -> str:
        if self.app.cfg.get("trust_proxy"):
            xff = self.headers.get("X-Forwarded-For")
            if xff:
                return xff.split(",")[-1].strip()[:64] or "?"
        return self.client_address[0] if self.client_address else "?"

    # ---------------------------------------------------------------- dispatch
    def do_GET(self):
        self._dispatch("GET")

    def do_HEAD(self):
        self._dispatch("HEAD")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_DELETE(self):
        self._dispatch("DELETE")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_OPTIONS(self):
        self._dispatch("OPTIONS")

    def _dispatch(self, method: str):
        path = urllib.parse.urlsplit(self.path).path
        try:
            if path == "/v1" or path.startswith("/v1/"):
                self._api(method, path)
            elif method in ("GET", "HEAD"):
                self._static(path)
            else:
                raise ApiError(405, "method_not_allowed")
        except ApiError as e:
            if e.status in (400, 413, 415) and getattr(self, "_subject", None):
                self.app.store.abuse(self._subject, e.code)
            try:
                self.send_err(e)
            except OSError:
                pass
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:  # never leak internals
            traceback.print_exc(file=sys.stderr)
            try:
                self.send_err(ApiError(500, "internal_error"))
            except OSError:
                pass

    # ---------------------------------------------------------------- static
    def _static(self, path: str):
        root = self.app.web_root
        if not root:
            raise ApiError(404, "no_web_root")
        rel = urllib.parse.unquote(path)
        if "\x00" in rel:
            raise ApiError(400, "bad_path")
        rel = posixpath.normpath("/" + rel.lstrip("/"))
        parts = [p for p in rel.split("/") if p]
        if any(p.startswith(".") for p in parts) or "royal-ai-cloud" in parts:
            return self._plain(404, "Not found")
        full = os.path.realpath(os.path.join(root, *parts)) if parts else root
        if not (full == root or full.startswith(root + os.sep)):
            return self._plain(404, "Not found")
        if full == self.app.server_dir or full.startswith(self.app.server_dir + os.sep):
            return self._plain(404, "Not found")
        if os.path.isdir(full):
            full = os.path.join(full, "index.html")
        if not os.path.isfile(full):
            return self._plain(404, "Not found")
        ext = os.path.splitext(full)[1].lower()
        ctype = MIME.get(ext, "application/octet-stream")
        size = os.path.getsize(full)
        self.send_response(200)
        self._headers({"Content-Type": ctype, "Content-Length": str(size), "Cache-Control": "no-cache"})
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(full, "rb") as fh:
            while True:
                chunk = fh.read(256 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)

    def _plain(self, status: int, text: str):
        b = text.encode()
        self.send_response(status)
        self._headers({"Content-Type": "text/plain; charset=utf-8", "Content-Length": str(len(b))})
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(b)

    # ---------------------------------------------------------------- API gate
    def _gate(self, method: str, path: str = ""):
        host = (self.headers.get("Host") or "").strip().lower()
        # /v1/health is exempt from the Host check so platform health probes work (no data exposed).
        if path != "/v1/health" and host not in self.app.allowed_hosts(self.port):
            raise ApiError(421, "host_not_allowed")
        origin = self.headers.get("Origin")
        allowed = {"http://" + h for h in self.app.allowed_hosts(self.port)} | {"https://" + h for h in self.app.allowed_hosts(self.port)}
        allowed |= set(self.app.cfg.get("allowed_origins") or [])
        if origin is not None and origin not in allowed:
            raise ApiError(403, "origin_not_allowed", "Cross-origin requests are not accepted")
        sfs = self.headers.get("Sec-Fetch-Site")
        if sfs and sfs not in ("same-origin", "none"):
            raise ApiError(403, "origin_not_allowed", "Cross-site requests are not accepted")
        if method == "OPTIONS":
            # Same-origin only: no CORS grants are ever issued.
            raise ApiError(403, "cors_not_allowed")

    def _read_json(self):
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            raise ApiError(415, "json_required", "Content-Type must be application/json")
        if self.headers.get("Transfer-Encoding"):
            raise ApiError(411, "length_required")
        try:
            n = int(self.headers.get("Content-Length") or "-1")
        except ValueError:
            n = -1
        if n < 0:
            raise ApiError(411, "length_required")
        limit = int(self.app.cfg["max_body_bytes"])
        if n > limit:
            self.close_connection = True  # don't read the oversized body
            raise ApiError(413, "payload_too_large", "Request body exceeds %d bytes" % limit)
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError(400, "invalid_json")

    @staticmethod
    def _validate(data, schema):
        res = Result()
        try:
            return clean(data, schema, "$", res), res
        except ValidationError as e:
            raise ApiError(400, e.code, str(e), {"path": e.path})

    def _body(self, schema):
        return self._validate(self._read_json(), schema)

    def _auth(self) -> dict:
        h = self.headers.get("Authorization") or ""
        if not h.startswith("Bearer "):
            raise ApiError(401, "auth_required", "Missing bearer token")
        try:
            p = auth.verify(self.app.hmac, h[7:].strip())
        except auth.TokenError as e:
            raise ApiError(401, "token_" + str(e))
        lic = self.app.store.license(p["l"])
        if not lic or lic["status"] != "active" or lic["user_id"] != p["u"]:
            raise ApiError(401, "license_inactive")
        if lic["expires_at"] and lic["expires_at"] < now():
            raise ApiError(401, "license_expired")
        dev = self.app.store.device(p["l"], p["d"])
        if not dev or dev["revoked"]:
            raise ApiError(401, "device_revoked")
        self._subject = "dev:" + p["d"]
        self._check_flag()
        return {"uid": p["u"], "device": p["d"], "license": lic}

    def _check_flag(self):
        ab = self.app.cfg["abuse"]
        if self.app.store.abuse_count(self._subject, ab["window_sec"]) >= ab["flag_threshold"]:
            raise ApiError(403, "flagged_for_abuse", "Too many invalid or oversized requests — try again later")

    def _limit(self, key: str, burst: float, per_sec: float):
        ok, retry = self.app.buckets.take(key, burst, per_sec)
        if not ok:
            raise ApiError(429, "rate_limited", "Slow down a little", {"retry_after": int(retry + 0.999)},
                           {"Retry-After": str(int(retry + 0.999))})

    def _api(self, method: str, path: str):
        self._subject = "ip:" + self.ip()
        self._gate(method, path)
        route = (method, path)
        if route in (("GET", "/v1/health"), ("HEAD", "/v1/health")):
            return self.send_json(200, {
                "ok": True, "status": "ok", "service": SERVICE, "version": VERSION,
                "provider_configured": self.app.provider_configured(), "time": now(),
                "mode": "production" if self.app.production else "local",
                "license_required": not bool(self.app.dev_key),
            })
        if route == ("POST", "/v1/auth/device"):
            return self._auth_device()
        if route == ("GET", "/v1/account"):
            return self._account()
        if route == ("GET", "/v1/usage"):
            return self._usage()
        if route == ("GET", "/v1/memory/profile"):
            return self._get_profile()
        if route == ("PUT", "/v1/memory/profile"):
            return self._put_profile()
        if route == ("POST", "/v1/memory/decision"):
            return self._post_decisions()
        if path.startswith("/v1/ai/"):
            if method != "POST":
                raise ApiError(405, "method_not_allowed")
            return self._ai(path[len("/v1/ai/"):])
        raise ApiError(404, "not_found")

    # ---------------------------------------------------------------- handlers
    def _auth_device(self):
        rl = self.app.cfg["rate_limit"]
        self._check_flag()
        self._limit("auth:" + self.ip(), rl["auth_burst"], rl["auth_per_sec"])
        body, _ = self._body(AUTH_SCHEMA)
        key = body.get("license_key") or self.app.dev_key
        if not key:
            raise ApiError(401, "license_required", "A license key is required")
        lic = self.app.store.license(key)
        if not lic:
            raise ApiError(401, "license_invalid")
        if lic["status"] != "active":
            raise ApiError(401, "license_inactive")
        if lic["expires_at"] and lic["expires_at"] < now():
            raise ApiError(401, "license_expired")
        dev = self.app.store.device(key, body["device_id"])
        if dev and dev["revoked"]:
            raise ApiError(401, "device_revoked")
        if not dev and self.app.store.device_count(key) >= lic["max_devices"]:
            raise ApiError(403, "device_limit_reached", "This license is already active on %d devices" % lic["max_devices"])
        self.app.store.register_device(key, body["device_id"], body.get("device_name"))
        token, exp = auth.issue(self.app.hmac, lic["user_id"], body["device_id"], key, self.app.cfg["token_ttl_sec"])
        user = self.app.store.user(lic["user_id"])
        self.send_json(200, {"ok": True, "token": token, "expires_at": exp, "user": {"name": user["name"]},
                             "plan": lic["plan"], "credits": user["credits"]})

    def _account(self):
        a = self._auth()
        lic, user = a["license"], self.app.store.user(a["uid"])
        ops = self.app.store.license_ops(lic)
        costs = self.app.cfg["costs"]
        self.send_json(200, {
            "ok": True, "user": {"name": user["name"]}, "plan": lic["plan"], "credits": user["credits"],
            "license": {"status": lic["status"], "expires_at": lic["expires_at"], "max_devices": lic["max_devices"],
                        "devices": self.app.store.device_count(lic["key"]),
                        "key_hint": lic["key"][:4] + "…" + lic["key"][-4:]},
            "costs": {k: v for k, v in costs.items() if ops == "*" or k in ops},
            "daily_caps": self.app.cfg["daily_caps"],
            "provider_configured": self.app.provider_configured(),
            "models": {"default": self.app.cfg["provider"]["default_model"]},
        })

    def _usage(self):
        a = self._auth()
        day = now() - (now() % 86400)
        self.send_json(200, {"ok": True, "credits": self.app.store.credits(a["uid"]),
                             "today": self.app.store.usage_totals(a["uid"], day),
                             "recent": self.app.store.recent_usage(a["uid"], 25)})

    def _get_profile(self):
        a = self._auth()
        prof, wf, upd = self.app.store.get_profile(a["uid"])
        self.send_json(200, {"ok": True, "profile": prof, "workflow": wf, "updated_at": upd,
                             "decisions": self.app.store.recent_decisions(a["uid"], 20),
                             "notes": self.app.store.session_notes(a["uid"], None, 20)})

    def _put_profile(self):
        a = self._auth()
        data = self._read_json()
        raw_tags = {}
        if isinstance(data, dict) and isinstance(data.get("profile"), dict):
            for k in ("accepted_tags", "rejected_tags"):  # dynamic-key maps, cleaned separately
                if k in data["profile"]:
                    raw_tags[k] = data["profile"].pop(k)
        body, res = self._validate(data, PROFILE_SCHEMA)
        prof_old, wf_old, _ = self.app.store.get_profile(a["uid"])
        prof = dict(prof_old)
        prof.update(body.get("profile") or {})
        for k, v in raw_tags.items():
            prof[k] = clean_tag_map(v)
        wf = dict(wf_old)
        wf.update(body.get("workflow") or {})
        self.app.store.put_profile(a["uid"], prof, wf)
        self.send_json(200, {"ok": True, "profile": prof, "workflow": wf, "stripped_fields": len(res.stripped)})

    def _post_decisions(self):
        a = self._auth()
        body, res = self._body(DECISION_SCHEMA)
        added = sum(1 for d in body["decisions"] if self.app.store.add_decision(a["uid"], d))
        self.send_json(200, {"ok": True, "received": len(body["decisions"]), "added": added,
                             "stripped_fields": len(res.stripped)})

    def _ai(self, op: str):
        a = self._auth()
        cfg = self.app.cfg
        if op not in orchestrator.ALLOWED_OPS:
            raise ApiError(400, "unknown_operation", "Operation not allowed", {"allowed": list(orchestrator.ALLOWED_OPS)})
        ops = self.app.store.license_ops(a["license"])
        if ops != "*" and op not in ops:
            raise ApiError(403, "operation_not_in_plan")
        rl = cfg["rate_limit"]
        self._limit("user:" + a["uid"], rl["user_burst"], rl["user_per_sec"])
        self._limit("device:" + a["device"], rl["device_burst"], rl["device_per_sec"])
        cap = int(cfg["daily_caps"].get(op, 50))
        if self.app.store.ops_today(a["uid"], op) >= cap:
            raise ApiError(429, "daily_cap_reached", "Daily limit for %s reached" % op, {"cap": cap})
        req, res = self._body(AI_REQUEST_SCHEMA)
        if req.get("utterance") and len(req["utterance"]) > int(cfg["max_utterance_chars"]):
            raise ApiError(400, "field_too_long", "utterance too long", {"path": "$.utterance"})
        try:
            orchestrator.enforce_context_rules(req["context"], cfg)
        except orchestrator.ContextRejected as e:
            raise ApiError(400, e.code, e.msg)
        key = self.app.secrets.provider_key()
        if not key:
            raise ApiError(503, "provider_not_configured", "The AI provider key is not set on the server")
        cost = int(cfg["costs"].get(op, 5))
        credits = self.app.store.credits(a["uid"])
        if credits < cost:
            raise ApiError(402, "insufficient_credits", "Not enough Royal AI Credits",
                           {"credits": credits, "cost": cost})
        spec = orchestrator.SPECIALIST_FOR[op]
        prof, wf, _ = self.app.store.get_profile(a["uid"])
        session_name = req["context"]["session"]["name"]
        memory = {"profile": prof, "workflow": wf,
                  "recent_decisions": [{k: d[k] for k in ("text", "verdict", "category")}
                                       for d in self.app.store.recent_decisions(a["uid"], 20)],
                  "session_notes": [n["note"] for n in self.app.store.session_notes(a["uid"], session_name, 15)]}
        msgs = orchestrator.build_messages(op, req, memory)
        pc = cfg["provider"]
        model = (pc.get("model_for_op") or {}).get(op) or pc["default_model"]
        rid = "req_" + secrets.token_hex(6)
        try:
            out = provider.chat(pc["base_url"], key, model, msgs, float(pc["temperature"]), int(pc["max_tokens"]),
                                float(pc["timeout_sec"]), bool(pc.get("json_mode", True)))
        except provider.ProviderError as e:
            self.app.store.log_usage(user_id=a["uid"], device_id=a["device"], op=op, specialist=spec, status=e.code,
                                     cost=0, model=model, request_id=rid)
            raise ApiError(e.status, e.code, "The AI provider could not answer (%s). No credits were used." % e.code)
        result = orchestrator.validate_output(out["content"], req["context"])
        charged = cost if self.app.store.deduct(a["uid"], cost) else 0
        self.app.store.log_usage(user_id=a["uid"], device_id=a["device"], op=op, specialist=spec, status="ok",
                                 cost=charged, model=out["model"], input_tokens=out["input_tokens"],
                                 output_tokens=out["output_tokens"], latency_ms=out["latency_ms"], request_id=rid)
        self.send_json(200, {
            "ok": True, "request_id": rid, "operation": op, "specialist": spec, "model": out["model"],
            "reply": result["reply"], "spoken": result["spoken"], "ideas": result["ideas"],
            "structured": result["structured"], "rejected_actions": result["rejected_actions"],
            "cost": charged, "credits_remaining": self.app.store.credits(a["uid"]),
            "usage": {"input_tokens": out["input_tokens"], "output_tokens": out["output_tokens"],
                      "latency_ms": out["latency_ms"]},
            "stripped_fields": len(res.stripped),
        })
