/* MY CONSOLE — DEPLOY-2 expert QA suite (Playwright, playwright-core).
 * Usage: node qa-suite.cjs <chromium|firefox|webkit> [baseUrl]
 * Writes results-<browser>.json next to this file + screenshots in ./shots.
 */
const path = require('path');
const fs = require('fs');
const pw = require(process.env.PW_CORE || 'playwright-core');
const BROWSER = process.argv[2] || 'chromium';
const BASE = process.argv[3] || 'http://127.0.0.1:8777/';
const SINGLE = process.env.QA_SINGLE || '/workspace/my-console/dist-single/index.html';
const OUT = process.env.QA_OUT || __dirname;
const SHOTS = path.join(OUT, 'shots');
fs.mkdirSync(SHOTS, { recursive: true });

const results = [];
let page, context, browser;
let consoleErrors = [];

function rec(feature, status, notes = '') {
  results.push({ feature, browser: BROWSER, status, notes: String(notes).replace(/\s+/g, ' ').slice(0, 600) });
  console.log(`[${BROWSER}] ${status.padEnd(7)} ${feature}${notes ? ' — ' + String(notes).slice(0, 220) : ''}`);
}

const BENIGN = [/favicon/i, /Download the React DevTools/i];
async function step(feature, fn, opts = {}) {
  consoleErrors = [];
  let status = 'PASS';
  let notes = '';
  try {
    const r = await fn();
    if (r && typeof r === 'object') {
      status = r.status || 'PASS';
      notes = r.notes || '';
    } else if (typeof r === 'string') notes = r;
  } catch (e) {
    status = 'FAIL';
    notes = (e && e.message ? e.message : String(e)).split('\n')[0];
  }
  await page.waitForTimeout(50).catch(() => {});
  const errs = consoleErrors.filter((t) => !BENIGN.some((b) => b.test(t)) && !(opts.allowErrors || []).some((b) => b.test(t)));
  if (errs.length && status === 'PASS') {
    status = 'FAIL';
    notes += ` | console errors: ${errs.slice(0, 3).join(' || ')}`;
  } else if (errs.length) notes += ` | console errors: ${errs.slice(0, 2).join(' || ')}`;
  rec(feature, status, notes);
  return status;
}

function assert(c, msg) {
  if (!c) throw new Error(msg);
}
const S = (fn, arg) => page.evaluate(fn, arg);
const st = () => S(() => {
  const s = window.__myconsole.store.getState();
  return JSON.parse(JSON.stringify({
    isPlaying: s.isPlaying, isRecording: s.isRecording, isLooping: s.isLooping, playheadBar: s.playheadBar, tempo: s.tempo,
    timebase: s.timebase, metronomeOn: s.metronomeOn, metroCountIn: s.metroCountIn, isCountingIn: s.isCountingIn,
    viewMode: s.viewMode, editMode: s.editMode, editTool: s.editTool, timelineZoom: s.timelineZoom, headroomMode: s.headroomMode,
    statusMessage: s.statusMessage, selectedClipIds: s.selectedClipIds, selectedTrackIds: s.selectedTrackIds,
    trackCount: s.tracks.length, soloMode: s.soloMode, activePanel: s.activePanel, groups: (s.trackGroups || []).length, automationMode: s.automationMode, gridBeats: s.gridBeats,
  }));
});

const gotoRetries = [];
async function launch() {
  const common = { headless: true };
  if (BROWSER === 'chromium') {
    browser = await pw.chromium.launch({
      ...common,
      executablePath: process.env.CHROME || '/usr/bin/google-chrome',
      args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required', '--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'],
    });
  } else if (BROWSER === 'firefox') {
    browser = await pw.firefox.launch({
      ...common,
      firefoxUserPrefs: {
        'media.navigator.streams.fake': true,
        'media.navigator.permission.disabled': true,
        'media.autoplay.default': 0,
        'media.autoplay.block-webaudio': false,
        'media.setsinkid.enabled': true,
      },
    });
  } else {
    browser = await pw.webkit.launch(common);
  }
}

async function newPage(viewport = { width: 1440, height: 900 }, opts = {}) {
  if (context) await context.close().catch(() => {});
  const ctxOpts = { viewport, acceptDownloads: true };
  if (BROWSER === 'chromium') ctxOpts.permissions = ['microphone'];
  context = await browser.newContext(ctxOpts);
  page = await context.newPage();
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR ' + e.message));
  page.on('dialog', (d) => { page.__lastDialog = d.message(); d.accept().catch(() => {}); }); // window.prompt/confirm: accept default
  await page.addInitScript(() => {
    window.__spoken = [];
    const synth = { speaking: false, pending: false, paused: false, getVoices: () => [], addEventListener() {}, removeEventListener() {},
      speak(u) { window.__spoken.push(u.text); setTimeout(() => u.onend && u.onend({}), 20); }, cancel() {}, pause() {}, resume() {} };
    try { Object.defineProperty(window, 'speechSynthesis', { value: synth, configurable: true }); } catch {}
    window.SpeechSynthesisUtterance = function (t) { this.text = t; };
  });
  if (opts.init) await page.addInitScript(opts.init);
  try { await page.goto(opts.url || BASE); }
  catch (e) { // headless Firefox occasionally never fires 'load' on the first navigation; retry once and count it
    gotoRetries.push(String(e.message).split('\n')[0]);
    await page.goto(opts.url || BASE, { timeout: 45000 });
  }
  await page.waitForSelector('.build-banner', { timeout: 20000 });
  await page.waitForFunction(() => !!window.__myconsole, null, { timeout: 10000 });
  await page.waitForTimeout(300);
}

async function menuOpen(name) {
  const items = page.locator('.menu-bar-item');
  const n = await items.count();
  for (let i = 0; i < n; i++) {
    const t = (await items.nth(i).textContent()).trim().toLowerCase();
    if (t === name.toLowerCase()) {
      if (await page.$('.menu-dropdown')) await page.keyboard.press('Escape');
      if (await page.$('.menu-dropdown')) await items.nth(i).click();
      if (!(await page.$('.menu-dropdown'))) await items.nth(i).click();
      await page.waitForSelector('.menu-dropdown', { timeout: 3000 });
      return i;
    }
  }
  throw new Error('menu not found ' + name);
}
async function menu(name, label, sub) {
  await menuOpen(name);
  const item = page.locator('.menu-dropdown:not(.menu-flyout) > li > .menu-item', { has: page.locator(`.menu-item-label:text-is("${label}")`) }).first();
  if (sub) {
    await item.hover();
    await page.waitForSelector('.menu-flyout', { timeout: 3000 });
    await page.locator('.menu-flyout .menu-item', { has: page.locator(`.menu-item-label:text-is("${sub}")`) }).first().click();
  } else await item.click();
  await page.waitForTimeout(250);
}
async function closeDialogs() {
  for (let i = 0; i < 4; i++) {
    if (await page.$('.mc-dialog-x')) await page.click('.mc-dialog-x').catch(() => {});
    else if (await page.$('.mc-dialog-backdrop')) await page.mouse.click(5, 5);
    else if (await page.$('.menu-dropdown')) await page.keyboard.press('Escape');
    else if (await page.$('.pb-overlay')) await page.keyboard.press('Escape');
    else break;
    await page.waitForTimeout(120);
  }
}
async function view(mode) {
  await S((m) => window.__myconsole.store.getState().setViewMode(m), mode);
  await page.waitForTimeout(250);
}

// ─────────────────────────────── tests: load / transport ───────────────────────────────
async function testLoad() {
  await step('App load (served via Royal AI Cloud gateway)', async () => {
    await newPage();
    const b = await page.textContent('.build-banner');
    assert(/DEPLOY-2/.test(b), 'banner ' + b);
    return `banner "${b.trim()}"`;
  });
  await step('App load (single-file OPEN-MY-CONSOLE.html, file://)', async () => {
    if (!fs.existsSync(SINGLE)) return { status: 'FAIL', notes: 'single file missing' };
    const p = await context.newPage();
    const errs = [];
    p.on('pageerror', (e) => errs.push(e.message));
    await p.goto('file://' + SINGLE);
    await p.waitForSelector('.build-banner', { timeout: 20000 });
    const b = await p.textContent('.build-banner');
    await p.waitForFunction(() => !!window.__myconsole, null, { timeout: 10000 });
    const notice = await p.evaluate(() => window.__myconsole.audioIO.getState().notice || '');
    await p.close();
    assert(!errs.length, 'page errors ' + errs.join(';'));
    assert(/file:\/\//.test(notice), 'no file:// notice: ' + notice);
    return `banner "${b.trim()}", file:// input notice shown`;
  });
}

async function testTransport() {
  await newPage();
  await step('Transport: Play / Stop (UI buttons)', async () => {
    await page.click('button:text-is("PLAY")');
    // audio device start (AudioContext.resume) can take ~2 s on some outputs; wait for it, then measure 1.2 s
    await page.waitForFunction(() => window.__myconsole.engine.isRunning() && window.__myconsole.engine.ctx.currentTime > 0.25, null, { timeout: 8000 }).catch(() => {}); /* audio clock must be moving (PulseAudio null sink starts ~1.5 s after resume) */
    await page.waitForTimeout(1200);
    const a = await st();
    assert(a.isPlaying, 'not playing');
    assert(a.playheadBar > 1.1, 'playhead did not advance: ' + a.playheadBar);
    const running = await S(() => window.__myconsole.engine.isRunning());
    assert(running, 'engine not running');
    await page.click('button:text-is("STOP")');
    await page.waitForTimeout(200);
    const b = await st();
    assert(!b.isPlaying, 'still playing');
    return `playhead advanced to bar ${a.playheadBar.toFixed(2)} in 1.2 s at ${a.tempo} BPM; engine ran`;
  });
  await step('Transport: RTZ / FF / RW', async () => {
    await page.click('button:text-is("FF")');
    const f = (await st()).playheadBar;
    await page.click('button:text-is("FF")');
    const f2 = (await st()).playheadBar;
    await page.click('button:text-is("RW")');
    const r = (await st()).playheadBar;
    await page.click('button:text-is("RTZ")');
    const z = (await st()).playheadBar;
    assert(f2 > f && r < f2 && z === 1, `ff ${f}->${f2} rw ${r} rtz ${z}`);
    return `FF ${f}→${f2}, RW →${r}, RTZ →${z}`;
  });
  await step('Transport: Loop toggle', async () => {
    const a = (await st()).isLooping;
    await page.click('button:text-is("LOOP")');
    const b = (await st()).isLooping;
    await page.click('button:text-is("LOOP")');
    assert(a !== b, 'loop did not toggle');
    return `loop ${a}→${b}`;
  });
  await step('Transport: Metronome (CLK) + Count-in (CI)', async () => {
    const a = await st();
    if (!a.metronomeOn) await page.click('button:text-is("CLK")');
    if (!(await st()).metroCountIn) await page.click('button:text-is("CI")');
    const b = await st();
    assert(b.metronomeOn && b.metroCountIn, 'toggles');
    await S(() => window.__myconsole.store.getState().setPlayhead(1));
    await page.click('button:text-is("PLAY")');
    await page.waitForFunction(() => window.__myconsole.store.getState().isCountingIn, null, { timeout: 5000 }).catch(() => {});
    const c = await st();
    assert(c.isCountingIn, 'count-in did not start');
    await page.waitForTimeout(2600);
    const d = await st();
    assert(!d.isCountingIn && d.isPlaying, 'count-in did not finish');
    await page.click('button:text-is("STOP")');
    await page.click('button:text-is("CLK")');
    await page.click('button:text-is("CI")');
    return 'count-in 1 bar at 120 BPM then roll; metronome on';
  });
  await step('Transport: BPM field + timebase', async () => {
    const inp = page.locator('.tempo-box input');
    await inp.fill('97');
    await inp.press('Enter');
    await page.waitForTimeout(100);
    const t = (await st()).tempo;
    const seen = [];
    const want = ['MinutesSeconds', 'Samples', 'Timecode', 'BarsBeats'];
    for (const v of want) {
      await page.selectOption('.timebase-box select', v);
      await page.waitForTimeout(80);
      seen.push((await st()).timebase + ':' + (await page.textContent('.pro-timecode')).trim());
    }
    await inp.fill('120');
    assert(t === 97, 'tempo ' + t);
    assert(seen.every((x, i) => x.startsWith(want[i])), seen.join(','));
    return `tempo 97 set; timebase readouts ${seen.join(' | ')}`;
  });
  await step('Transport: keyboard (Space play/stop, M metronome)', async () => {
    await page.mouse.click(700, 5);
    await page.keyboard.press('Space');
    await page.waitForFunction(() => window.__myconsole.store.getState().isPlaying, null, { timeout: 5000 }).catch(() => {});
    const a = (await st()).isPlaying;
    await page.keyboard.press('Space');
    await page.waitForFunction(() => !window.__myconsole.store.getState().isPlaying, null, { timeout: 5000 }).catch(() => {});
    const b = (await st()).isPlaying;
    await page.keyboard.press('m');
    const c = (await st()).metronomeOn;
    await page.keyboard.press('m');
    assert(a && !b && c, `space ${a}/${b} m ${c}`);
    return 'ok';
  });
}

// ─────────────────────────────── tests: devices / record ───────────────────────────────
async function testDevicesAndRecord() {
  const hasFake = BROWSER !== 'webkit';
  await newPage();
  await step('Setup › Playback Engine dialog (menu, devices, readout)', async () => {
    await menu('Setup', 'Playback Engine…');
    await page.waitForSelector('[data-testid=playback-engine-dialog]');
    const outs = await page.$$eval('[data-testid=pe-output] option', (o) => o.map((x) => x.textContent));
    const sink = await S(() => window.__myconsole.audioIO.getState().sinkSupported);
    const note = !!(await page.$('[data-testid=pe-sink-note]'));
    await page.screenshot({ path: path.join(SHOTS, `${BROWSER}-playback-engine.png`) });
    assert(outs.length >= 1, 'no outputs listed');
    assert(sink || note, 'no sink support and no fallback note');
    return `outputs: ${outs.join(', ')} · setSinkId ${sink ? 'supported' : 'NOT supported → system-default note shown'}`;
  });
  await step('Playback Engine: sample rates 44.1/48/88.2/96 recreate AudioContext', async () => {
    const got = [];
    for (const r of ['44100', '48000', '88200', '96000']) {
      await page.selectOption('[data-testid=pe-samplerate]', r);
      await page.waitForTimeout(700);
      const s = await S(() => ({ sr: window.__myconsole.engine.getSampleRate(), err: window.__myconsole.audioIO.getState().error }));
      got.push(`${r}→${s.sr}${s.err ? ' (' + s.err.slice(0, 60) + ')' : ''}`);
    }
    const ok = got.filter((g) => { const [a, b] = g.split('→'); return parseInt(a) === parseInt(b); }).length;
    await page.selectOption('[data-testid=pe-samplerate]', '0');
    await page.waitForTimeout(500);
    if (ok === 4) return got.join(', ');
    return { status: ok >= 1 ? 'LIMITED' : 'FAIL', notes: `browser honoured ${ok}/4: ${got.join(', ')}` };
  });
  await step('Playback Engine: latency hint interactive/balanced/playback/custom + baseLatency/outputLatency', async () => {
    const got = [];
    for (const m of ['interactive', 'balanced', 'playback', 'custom']) {
      await page.selectOption('[data-testid=pe-latency]', m);
      await page.waitForTimeout(500);
      if (m === 'custom') {
        await page.fill('[data-testid=pe-custom-latency]', '0.05');
        await page.locator('[data-testid=pe-custom-latency]').blur();
        await page.waitForTimeout(600);
      }
      got.push(`${m}: base ${(await page.textContent('[data-testid=pe-base-latency]')).trim()} / out ${(await page.textContent('[data-testid=pe-output-latency]')).trim()}`);
    }
    await page.selectOption('[data-testid=pe-latency]', 'interactive');
    await page.waitForTimeout(400);
    const hasNums = got.some((g) => /\d+\.\d ms/.test(g));
    return hasNums ? got.join(' | ') : { status: 'LIMITED', notes: 'browser does not report latencies: ' + got.join(' | ') };
  });
  await step('Playback Engine: output device selection (setSinkId) persisted by label', async () => {
    const sink = await S(() => window.__myconsole.audioIO.getState().sinkSupported);
    if (!sink) return { status: 'LIMITED', notes: 'AudioContext.setSinkId not available in this browser → system default output; dialog tells the user to pick the interface in macOS/Windows Sound settings' };
    const opts = await page.$$eval('[data-testid=pe-output] option', (o) => o.map((x) => ({ v: x.value, t: x.textContent })));
    const target = opts.find((o) => o.v !== 'default') || opts[0];
    await page.selectOption('[data-testid=pe-output]', target.v);
    await page.waitForTimeout(700);
    const s = await S(() => ({ active: window.__myconsole.audioIO.getState().activeOutputLabel, sinkId: window.__myconsole.engine.getAudioContext()?.sinkId, saved: JSON.parse(localStorage.getItem('royal-audio-io') || '{}').outputLabel }));
    assert(s.active === target.t, 'active ' + s.active);
    assert(typeof s.sinkId === 'string' ? s.sinkId === target.v : true, 'ctx.sinkId ' + s.sinkId);
    assert(s.saved === target.t, 'not persisted by label');
    return `output → "${target.t}", ctx.sinkId matches, persisted by label`;
  });
  await closeDialogs();
  await step('Setup › I/O: enable input (getUserMedia, DSP off), channels, device list', async () => {
    await menu('Setup', 'I/O…');
    await page.waitForSelector('[data-testid=io-dialog]');
    if (!hasFake) {
      await page.click('[data-testid=io-enable]').catch(() => {});
      await page.waitForTimeout(1500);
      const e = await S(() => window.__myconsole.audioIO.getState().error);
      await page.screenshot({ path: path.join(SHOTS, `${BROWSER}-io.png`) });
      return { status: 'LIMITED', notes: 'no fake capture device for headless WebKit; error shown to user: ' + (e || 'none') };
    }
    await page.click('[data-testid=io-enable]');
    await page.waitForSelector('[data-testid=io-disable]', { timeout: 8000 });
    const s = await S(() => {
      const a = window.__myconsole.audioIO.getState();
      return { label: a.activeInputLabel, ch: a.maxInputChannels, inputs: a.inputs.map((d) => d.label) };
    });
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(SHOTS, `${BROWSER}-io.png`) });
    assert(s.label && s.ch >= 1, JSON.stringify(s));
    return `input "${s.label}", ${s.ch} ch detected; inputs: ${s.inputs.join(', ')}`;
  });
  await step('I/O: per-track input selection (mono N / stereo pairs) persisted', async () => {
    const sel = await page.$('[data-testid^=io-track-input-]');
    assert(sel, 'no track input selects');
    const opts = await sel.$$eval('option', (o) => o.map((x) => x.value));
    const id = (await sel.getAttribute('data-testid')).replace('io-track-input-', '');
    const want = opts.find((o) => o.startsWith('stereo')) || opts[opts.length - 1];
    await sel.selectOption(want);
    const saved = await S((id) => JSON.parse(localStorage.getItem('royal-audio-io')).trackInputs[id], id);
    assert(saved === want, 'saved ' + saved);
    return `options ${opts.join(',')}; track ${id} → ${want}`;
  });
  await step('I/O: round-trip test without a loopback reports "no loopback" honestly', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device' };
    await page.click('[data-testid=io-measure]');
    await page.waitForSelector('[data-testid=io-measure-result]', { timeout: 10000 });
    const t = await page.textContent('[data-testid=io-measure-result]');
    assert(/No loopback|Inconsistent/.test(t), t);
    return t;
  });
  await closeDialogs();
  await step('Record: armed track + REC captures REAL audio from input into a clip (latency-compensated)', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device in headless WebKit' };
    const tid = await S(() => {
      const s = window.__myconsole.store.getState();
      const t = s.tracks.find((x) => x.type === 'audio');
      s.toggleArm(t.id);
      s.setPlayhead(3);
      return t.id;
    });
    const clipsBefore = await S((id) => window.__myconsole.store.getState().tracks.find((t) => t.id === id).clips.length, tid);
    await page.click('button:text-is("REC")');
    await page.waitForTimeout(2500);
    await page.click('button:text-is("STOP")');
    await page.waitForTimeout(400);
    const r = await S((id) => {
      const { store, audioIO } = window.__myconsole;
      const t = store.getState().tracks.find((x) => x.id === id);
      const c = t.clips[t.clips.length - 1];
      const take = c && c.audio && audioIO.takes.get(c.audio.takeId);
      let rms = 0;
      if (take) { const d = take.buffer.getChannelData(0); let s = 0; for (let i = 0; i < d.length; i++) s += d[i] * d[i]; rms = Math.sqrt(s / d.length); }
      return { n: t.clips.length, clip: c && { start: c.startBar, len: c.lengthBars }, take: take && { dur: take.buffer.duration, ch: take.channels, peakDb: take.peakDb, rms, off: take.offsetSec }, status: store.getState().statusMessage, comp: audioIO.compensationSec() };
    }, tid);
    assert(r.n === clipsBefore + 1, 'no new clip');
    assert(r.take, 'clip has no recorded audio take: ' + r.status);
    assert(r.take.rms > 0.001, 'silent take rms ' + r.take.rms);
    assert(Math.abs(r.take.off - r.comp.total) < 1e-6, 'offset mismatch');
    const sched = await S((id) => {
      const { audioIO, engine, store } = window.__myconsole;
      store.getState().setPlayhead(3);
      const ctx = engine.ensureContext();
      const g = ctx.createGain();
      const n = audioIO['scheduleTakes'](ctx, id, g);
      n.forEach((x) => { try { x.stop(); } catch {} });
      return n.length;
    }, tid);
    await S((id) => window.__myconsole.store.getState().toggleArm(id), tid);
    assert(sched >= 1, 'take not scheduled for playback');
    return `clip @bar ${r.clip.start} len ${r.clip.len.toFixed(2)} bars · ${r.take.dur.toFixed(2)} s, ${r.take.ch} ch (stereo pair selected), peak ${r.take.peakDb.toFixed(1)} dBFS, rms ${r.take.rms.toFixed(3)} · latency comp ${(r.take.off * 1000).toFixed(1)} ms (${r.comp.source}) · take scheduled into the channel on playback`;
  });
  await step('Record: recorded clip waveform uses real peaks (Edit window)', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device' };
    await view('edit');
    const ok = await S(() => {
      const { audioIO, store } = window.__myconsole;
      const clips = store.getState().tracks.flatMap((t) => t.clips).filter((c) => c.audio);
      const c = clips[clips.length - 1];
      const p = c ? audioIO.peaksForClip(c) : null;
      if (!p || !p.some((v) => v > 0)) return false;
      // independent check: max |x| per bin straight from the take's PCM over the clip's range
      const take = audioIO.takes.get(c.audio.takeId);
      const sr = take.buffer.sampleRate, secPerBar = (60 / store.getState().tempo) * 4;
      const a = Math.floor(c.audio.offsetSec * sr), b = Math.min(take.buffer.length, Math.ceil((c.audio.offsetSec + c.lengthBars * secPerBar) * sr));
      const chans = Array.from({ length: take.buffer.numberOfChannels }, (_, i) => take.buffer.getChannelData(i));
      const exp = new Float32Array(p.length); let mx = 0;
      for (let i = 0; i < p.length; i++) { const s0 = a + Math.floor(((b - a) * i) / p.length), s1 = a + Math.floor(((b - a) * (i + 1)) / p.length); let m = 0; for (const d of chans) for (let k = s0; k < s1; k++) { const v = Math.abs(d[k]); if (v > m) m = v; } exp[i] = m; if (m > mx) mx = m; }
      let diff = 0; for (let i = 0; i < p.length; i++) diff += Math.abs(p[i] - exp[i] / (mx || 1));
      return diff / p.length < 0.08;
    });
    assert(ok, 'no peaks');
    return 'real peaks (computed from recorded PCM, cached) passed to WaveformClip';
  });
}

async function testLoopbackAndHotplug() {
  if (BROWSER === 'webkit') {
    rec('I/O: loopback round-trip measurement (simulated 12 ms loopback)', 'LIMITED', 'no capture device in headless WebKit');
    rec('Hot-plug: devicechange → fallback to default + UI + Session Guardian notice', 'LIMITED', 'no media devices in headless WebKit');
    return;
  }
  // Simulated loopback cable: anything sent to ctx.destination also feeds the "microphone" 12 ms later.
  const init = () => {
    const origConnect = AudioNode.prototype.connect;
    const loops = new WeakMap();
    const loopFor = (ctx) => {
      let l = loops.get(ctx);
      if (!l) {
        const d = ctx.createDelay(1); d.delayTime.value = 0.012;
        const out = ctx.createGain();
        origConnect.call(d, out);
        l = { d, out }; loops.set(ctx, l);
      }
      return l;
    };
    AudioNode.prototype.connect = function (dest, ...rest) {
      const r = origConnect.call(this, dest, ...rest);
      try { if (dest === this.context.destination && !(this instanceof GainNode && this.gain.value === 0)) origConnect.call(this, loopFor(this.context).d); } catch {} // skip muted capture sinks: a real cable can't feed them back (Firefox mutes such cycles)
      return r;
    };
    const origCMSS = AudioContext.prototype.createMediaStreamSource;
    AudioContext.prototype.createMediaStreamSource = function (stream) {
      origCMSS.call(this, stream);
      return loopFor(this).out;
    };
  };
  await newPage({ width: 1440, height: 900 }, { init });
  await step('I/O: loopback round-trip measurement (simulated 12 ms loopback) + manual offset, persisted per device', async () => {
    await menu('Setup', 'I/O…');
    await page.click('[data-testid=io-enable]');
    await page.waitForSelector('[data-testid=io-disable]', { timeout: 8000 });
    await page.click('[data-testid=io-measure]');
    await page.waitForSelector('[data-testid=io-measure-result]', { timeout: 10000 });
    const t = await page.textContent('[data-testid=io-measure-result]');
    const m = /Round-trip ([\d.]+) ms/.exec(t);
    assert(m, t);
    const v = parseFloat(m[1]);
    assert(Math.abs(v - 12) <= 0.5, 'measured ' + v);
    const saved = await S(() => Object.values(JSON.parse(localStorage.getItem('royal-audio-io')).perDevice).map((d) => d.measuredRoundTripMs));
    assert(saved.includes(v), 'not persisted');
    await page.fill('[data-testid=io-manual-offset]', '3.5');
    await page.locator('[data-testid=io-manual-offset]').blur();
    const comp = await S(() => window.__myconsole.audioIO.compensationSec());
    assert(Math.abs(comp.total - (v + 3.5) / 1000) < 1e-6, 'comp ' + comp.total);
    await page.fill('[data-testid=io-manual-offset]', '0');
    await page.locator('[data-testid=io-manual-offset]').blur();
    return `${t.trim()} · manual +3.5 ms → applied ${(comp.total * 1000).toFixed(1)} ms`;
  });
  await closeDialogs();
  await step('Hot-plug: devicechange → chosen output/input vanish → fallback to default, UI + Session Guardian notice', async () => {
    await page.click('button.aieng-topbar-btn');
    await page.waitForSelector('[data-testid=aieng-panel]');
    await page.waitForTimeout(800);
    const sink = await S(() => window.__myconsole.audioIO.getState().sinkSupported);
    const res = await S(async (sink) => {
      const io = window.__myconsole.audioIO;
      const md = navigator.mediaDevices;
      const real = await md.enumerateDevices();
      const outs = real.filter((d) => d.kind === 'audiooutput' && d.deviceId !== 'default');
      if (sink && outs[0]) await io.setOutput(outs[0].deviceId);
      const inp = real.find((d) => d.kind === 'audioinput' && d.deviceId !== 'default');
      if (inp) await io.setInputDevice(inp.deviceId);
      const chosenOut = io.getState().activeOutputLabel;
      const chosenIn = io.getState().activeInputLabel;
      const orig = md.enumerateDevices.bind(md);
      md.enumerateDevices = async () => (await orig()).filter((d) => d.label !== chosenOut && d.label !== chosenIn);
      md.dispatchEvent(new Event('devicechange'));
      await new Promise((r) => setTimeout(r, 1500));
      const after = io.getState();
      md.enumerateDevices = orig;
      md.dispatchEvent(new Event('devicechange'));
      await new Promise((r) => setTimeout(r, 1500));
      const back = io.getState();
      return { chosenOut, chosenIn, afterOut: after.activeOutputLabel, afterIn: after.activeInputLabel, events: after.events.map((e) => e.kind + ':' + e.message), backOut: back.activeOutputLabel, backIn: back.activeInputLabel, backEvents: back.events.slice(0, 3).map((e) => e.kind) };
    }, sink);
    await page.waitForTimeout(500);
    const guardian = await page.$$eval('.aieng-msg-text', (els) => els.map((e) => e.textContent).filter((t) => /Audio device:/.test(t)));
    assert(res.events.some((e) => e.startsWith('fallback')), 'no fallback event ' + JSON.stringify(res));
    if (sink) assert(res.afterOut === 'System default', 'output did not fall back: ' + res.afterOut);
    // Single-device browsers (Firefox fake stream): the default input IS the same fake device, so the label can't
    // change; require the input-fallback event instead.
    assert(res.afterIn !== res.chosenIn || res.events.some((e) => /^fallback:Input ".*" disconnected/.test(e)), 'input did not fall back ' + JSON.stringify(res.events));
    assert(guardian.length >= 1, 'no Session Guardian message');
    return `simulated unplug (patched enumerateDevices + devicechange): out "${res.chosenOut}"→"${res.afterOut}", in "${res.chosenIn}"→"${res.afterIn}"; replug → out "${res.backOut}", in "${res.backIn}" (${res.backEvents.join(',')}); Guardian: "${guardian[0].slice(0, 100)}"`;
  });
}

async function testPermissionDenied() {
  if (BROWSER !== 'chromium') {
    rec('Permissions: mic denied → clear error', 'LIMITED', 'denial is simulated in the Chromium run only');
    return;
  }
  const b2 = await pw.chromium.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox', '--use-fake-device-for-media-stream', '--deny-permission-prompts'] });
  const c2 = await b2.newContext();
  const p2 = await c2.newPage();
  const errs = [];
  p2.on('pageerror', (e) => errs.push(e.message));
  await p2.goto(BASE);
  await p2.waitForSelector('.build-banner');
  await p2.waitForFunction(() => !!window.__myconsole);
  const atLoad = await p2.evaluate(() => window.__myconsole.audioIO.getState().inputOpen);
  const e = await p2.evaluate(async () => { await window.__myconsole.audioIO.enableInput(); return window.__myconsole.audioIO.getState().error; });
  await b2.close();
  const ok = /permission denied|allow Microphone/i.test(e || '') && !atLoad;
  rec('Permissions: mic denied → clear error; mic not requested until input is enabled', ok && !errs.length ? 'PASS' : 'FAIL', `input open at load: ${atLoad}; error: "${e}"`);
}

// ─────────────────────────────── tests: edit / midi ───────────────────────────────
async function testEdit() {
  await newPage();
  await view('edit');
  await step('Edit tools: Smart/Selector/Grabber/Trim/Scrub/Pencil buttons', async () => {
    const got = [];
    for (const [t, id] of [['Selector', 'selector'], ['Grabber', 'grabber'], ['Trim', 'trim'], ['Scrub', 'scrub'], ['Pencil', 'pencil']]) {
      const b = page.locator(`button[title^="${t}"]`).first();
      if (!(await b.count())) { got.push(`${t}:missing`); continue; }
      await b.click();
      const cur = (await st()).editTool;
      got.push(`${t}:${cur}${cur === id ? '' : '(!)'}`);
    }
    await page.locator('button[title^="Smart Tool (F6)"]').first().click();
    const sm = (await st()).editTool;
    got.push(`Smart:${sm}`);
    assert(!got.some((g) => /missing|\(!\)/.test(g)) && sm === 'smart', got.join(','));
    return got.join(', ');
  });
  await step('Edit modes: Shuffle / Slip / Spot / Grid (Options menu)', async () => {
    const got = [];
    for (const m of ['Shuffle', 'Slip', 'Spot', 'Grid']) {
      await menu('Options', `${m} Mode`);
      got.push((await st()).editMode);
      await closeDialogs();
    }
    assert(got.join() === 'Shuffle,Slip,Spot,Grid', got.join());
    return got.join(' → ');
  });
  const pick = () => S(() => {
    const s = window.__myconsole.store.getState();
    const t = s.tracks.find((x) => x.type === 'audio' && x.clips.length);
    const c = t.clips[0];
    s.selectClip(c.id, false);
    return { tid: t.id, cid: c.id, start: c.startBar, len: c.lengthBars, n: t.clips.length };
  });
  const clipsOf = (tid) => S((tid) => window.__myconsole.store.getState().tracks.find((t) => t.id === tid).clips.map((c) => ({ id: c.id, s: c.startBar, l: c.lengthBars, e: !!c.elasticEnabled })), tid);
  await step('Edit: split at playhead (B)', async () => {
    const p = await pick();
    await S((b) => window.__myconsole.store.getState().setPlayhead(b), p.start + p.len / 2);
    await page.locator('button[title^="Split at playhead"]').click();
    const c = await clipsOf(p.tid);
    assert(c.length === p.n + 1, `clips ${p.n}→${c.length}`);
    return `clips ${p.n}→${c.length}`;
  });
  await step('Edit: cut clip / selection', async () => {
    const p = await pick();
    await page.locator('button[title^="Cut selection"]').click();
    const c = await clipsOf(p.tid);
    assert(c.length === p.n - 1 || !c.some((x) => x.id === p.cid), 'clip not cut');
    return `clips ${p.n}→${c.length}`;
  });
  await step('Edit: trim to selection / playhead', async () => {
    const p = await pick();
    await S((b) => window.__myconsole.store.getState().setPlayhead(b), p.start + p.len * 0.75);
    await page.locator('button[title^="Trim clip to selection"]').click();
    const c = (await clipsOf(p.tid)).find((x) => x.id === p.cid) || {};
    assert(c.l && Math.abs(c.l - p.len) > 1e-6, `len ${p.len}→${c.l}`);
    return `len ${p.len.toFixed(2)}→${c.l.toFixed(2)}`;
  });
  await step('Edit: elastic on/off (E)', async () => {
    const p = await pick();
    await page.locator('button[title^="Elastic On/Off"]').click();
    const c = (await clipsOf(p.tid)).find((x) => x.id === p.cid);
    assert(c.e, 'elastic not enabled');
    await page.locator('button[title^="Elastic On/Off"]').click();
    return 'elastic toggled on clip';
  });
  await step('Edit: nudge selected clip forward/back', async () => {
    const p = await pick();
    await page.locator('button[title^="Nudge selected clips / playhead forward"]').click();
    const c1 = (await clipsOf(p.tid)).find((x) => x.id === p.cid);
    await page.locator('button[title^="Nudge selected clips / playhead back"]').click();
    const c2 = (await clipsOf(p.tid)).find((x) => x.id === p.cid);
    assert(c1.s > p.start && Math.abs(c2.s - p.start) < 1e-6, `start ${p.start}→${c1.s}→${c2.s}`);
    return `start ${p.start}→${c1.s}→${c2.s}`;
  });
  await step('Edit: grid size select', async () => {
    const sel = page.locator('select[title="Grid size"]');
    const opts = await sel.locator('option').evaluateAll((o) => o.map((x) => x.value));
    await sel.selectOption(opts[opts.length - 1]);
    const g = (await st()).gridBeats;
    await sel.selectOption(opts[0]);
    const g0 = (await st()).gridBeats;
    assert(g !== g0, 'grid unchanged');
    return `options ${opts.join(',')}; grid → ${g} → ${g0}`;
  });
  await step('Edit: slip free move vs grid snap; spot action', async () => {
    const p = await pick();
    await S(() => window.__myconsole.store.getState().setEditMode('Slip'));
    await S(({ tid, cid, s }) => window.__myconsole.store.getState().moveClip(cid, s + 1.37), { tid: p.tid, cid: p.cid, s: p.start });
    const slip = (await clipsOf(p.tid)).find((x) => x.id === p.cid).s;
    await S(() => window.__myconsole.store.getState().setEditMode('Grid'));
    await S(({ tid, cid, s }) => window.__myconsole.store.getState().moveClip(cid, s + 1.37), { tid: p.tid, cid: p.cid, s: p.start });
    const grid = (await clipsOf(p.tid)).find((x) => x.id === p.cid).s;
    const hasSpot = await S(() => typeof window.__myconsole.store.getState().spotSelectedClip === 'function');
    assert(Math.abs(slip - (p.start + 1.37)) < 0.02, 'slip ' + slip);
    return `slip move → ${slip.toFixed(2)}, grid move → ${grid.toFixed(2)}; spot action present ${hasSpot}`;
  });
  await step('Edit: zoom in/out + track height +/-', async () => {
    const z0 = (await st()).timelineZoom;
    await menu('View', 'Zoom In');
    const z1 = (await st()).timelineZoom;
    await menu('View', 'Zoom Out');
    const lbl0 = (await page.locator('.track-height-controls').textContent()).replace(/\s+/g, ' ');
    await page.locator('button[title="Larger track lanes"]').click();
    const lbl1 = (await page.locator('.track-height-controls').textContent()).replace(/\s+/g, ' ');
    await page.locator('button[title="Smaller track lanes"]').click();
    assert(z1 > z0, `zoom ${z0}→${z1}`);
    assert(lbl0 !== lbl1, 'track height unchanged');
    return `zoom ${z0}→${z1}; track height "${lbl0.trim()}" → "${lbl1.trim()}"`;
  });
  await step('Edit: track colors + groups (dialog, linked faders)', async () => {
    const r = await S(() => {
      const s = window.__myconsole.store.getState();
      const [a, b] = s.tracks.filter((t) => t.type === 'audio');
      s.setTrackColor(a.id, '#3366cc');
      s.selectTrack(a.id, false); s.selectTrack(b.id, true);
      return { a: a.id, b: b.id };
    });
    await menu('Track', 'Group Selected…');
    await page.waitForSelector('.mc-dialog input');
    await page.fill('.mc-dialog input', 'QA Group');
    await page.locator('.mc-dialog .mc-btn.primary').click();
    await page.waitForTimeout(200);
    const g = await S(({ a, b }) => {
      const s = window.__myconsole.store.getState();
      const grp = s.trackGroups.find((x) => x.name === 'QA Group');
      if (grp && !grp.linked) s.setGroupLinked(grp.id, true);
      const s1 = window.__myconsole.store.getState();
      const va = s1.tracks.find((t) => t.id === a).volume, vb = s1.tracks.find((t) => t.id === b).volume;
      s1.setVolume(a, va - 0.1);
      const s2 = window.__myconsole.store.getState();
      return { grp: !!grp, members: grp?.trackIds.length, color: s2.tracks.find((t) => t.id === a).color, v: [vb, s2.tracks.find((t) => t.id === b).volume] };
    }, r);
    assert(g.grp && g.members === 2, 'group not created');
    assert(String(g.color).toLowerCase() === '#3366cc', 'color ' + g.color);
    assert(Math.abs(g.v[1] - (g.v[0] - 0.1)) < 1e-6, 'linked fader did not follow ' + g.v);
    return `group of ${g.members}, linked fader followed, color set`;
  });
  await step('Piano roll / MIDI: click grid adds note, click note removes it', async () => {
    const tid = await S(() => {
      const s = window.__myconsole.store.getState();
      const t = s.tracks.find((x) => x.trackType === 'MIDI' || x.trackType === 'Instrument' || /midi|keys|synth/i.test(x.name)) || s.tracks[0];
      s.selectTrack(t.id, false);
      s.setEditBottomTab('midi');
      return t.id;
    });
    const opener = page.locator('button[title="Open MIDI / Clip / Score panel"]');
    if (await opener.count()) await opener.click();
    await page.waitForSelector('.pro-midi-grid', { timeout: 5000 });
    const before = await S((id) => (window.__myconsole.store.getState().midiNotes[id] || []).length, tid);
    const box = await page.locator('.pro-midi-grid').boundingBox();
    await page.mouse.click(box.x + 200, box.y + 30);
    const mid = await S((id) => (window.__myconsole.store.getState().midiNotes[id] || []).length, tid);
    await page.locator('.pro-midi-note').last().click();
    const after = await S((id) => (window.__myconsole.store.getState().midiNotes[id] || []).length, tid);
    assert(mid === before + 1 && after === before, `${before}→${mid}→${after}`);
    return `notes ${before}→${mid}→${after}`;
  });
}

// ─────────────────────────────── tests: mix / automation ───────────────────────────────
async function testMix() {
  await newPage();
  await view('mix');
  await page.waitForSelector('.pro-channel-strip');
  const play = async () => { if (!(await st()).isPlaying) await page.click('button:text-is("PLAY")'); await page.waitForFunction(() => window.__myconsole.engine.isRunning() && window.__myconsole.engine.ctx.currentTime > 0.25, null, { timeout: 8000 }).catch(() => {}); /* audio clock must be moving (PulseAudio null sink starts ~1.5 s after resume) */ await page.waitForTimeout(400); };
  const stop = async () => { if ((await st()).isPlaying) await page.click('button:text-is("STOP")'); };
  await step('Mix: fader drag → dB readout → engine gain = 10^(dB/20) (true dB)', async () => {
    const strip = page.locator('.pro-channel-strip').first();
    const tid = await strip.getAttribute('data-track-id');
    await play();
    const track = strip.locator('.pro-fader-track');
    await track.scrollIntoViewIfNeeded();
    const bb = await track.boundingBox();
    await page.mouse.move(bb.x + bb.width / 2, bb.y + bb.height * 0.3);
    await page.mouse.down();
    await page.mouse.move(bb.x + bb.width / 2, bb.y + bb.height * 0.45, { steps: 3 });
    await page.mouse.up();
    await page.waitForTimeout(400);
    const r = await S((id) => {
      const { store, engine } = window.__myconsole;
      const t = store.getState().tracks.find((x) => x.id === id);
      const ch = engine['channels'].get(id);
      const kind = engine['kindGain'](ch.kind, ch.isAux);
      return { db: t.volumeDb, gain: ch.fader.gain.value, kind, ghost: document.querySelector(`.pro-channel-strip[data-track-id="${id}"] .pro-strip-vol-ghost`).textContent };
    }, tid);
    const expect = Math.pow(10, r.db / 20) * r.kind;
    const errDb = 20 * Math.log10(r.gain / expect);
    assert(Math.abs(errDb) < 0.05, `gain ${r.gain} expected ${expect} (${errDb.toFixed(3)} dB)`);
    assert(Math.abs(parseFloat(r.ghost) - r.db) < 0.051, 'readout ' + r.ghost + ' vs ' + r.db);
    return `drag → ${r.db.toFixed(2)} dB (readout "${r.ghost}"), engine fader gain ${r.gain.toFixed(5)} = 10^(dB/20) × source trim ${r.kind} (error ${errDb.toFixed(3)} dB)`;
  });
  await step('Mix: fader dB accuracy measured on the signal (0 / −6 / −12 / −20 dB)', async () => {
    await play();
    const r = await S(async () => {
      const { store, engine } = window.__myconsole;
      const s = store.getState();
      const t = s.tracks.find((x) => x.type === 'audio');
      const meas = async () => {
        await new Promise((r) => setTimeout(r, 300));
        let acc = 0, n = 0;
        for (let i = 0; i < 40; i++) { const m = engine.readChannelLevelsRaw().get(t.id); acc += m.rms * m.rms; n++; await new Promise((r) => setTimeout(r, 25)); }
        return Math.sqrt(acc / n);
      };
      const out = [];
      for (const db of [0, -6, -12, -20]) { store.getState().setVolumeDb(t.id, db); out.push({ db, rms: await meas(), gain: engine['channels'].get(t.id).fader.gain.value }); }
      return out;
    });
    const ref = r[0];
    const rows = r.map((x) => ({ set: x.db, gainDb: 20 * Math.log10(x.gain / ref.gain), sigDb: 20 * Math.log10(x.rms / ref.rms) }));
    const maxGainErr = Math.max(...rows.map((x) => Math.abs(x.gainDb - x.set)));
    const maxSigErr = Math.max(...rows.map((x) => Math.abs(x.sigDb - x.set)));
    await stop();
    assert(maxGainErr < 0.01, 'gain error ' + maxGainErr);
    assert(maxSigErr < 1.0, 'signal error ' + maxSigErr + ' ' + JSON.stringify(rows));
    return rows.map((x) => `${x.set} dB → gain ${x.gainDb.toFixed(2)} / signal ${x.sigDb.toFixed(2)} dB`).join('; ') + ` (max signal error ${maxSigErr.toFixed(2)} dB; preview sources are noise-based)`;
  });
  await step('Mix: pan knob drag + engine StereoPanner', async () => {
    await play();
    const strip = page.locator('.pro-channel-strip').first();
    const tid = await strip.getAttribute('data-track-id');
    const knob = strip.locator('.pro-pan-row > *').first();
    await knob.scrollIntoViewIfNeeded();
    const bb = await knob.boundingBox();
    await page.mouse.move(bb.x + bb.width / 2, bb.y + bb.height / 2);
    await page.mouse.down();
    await page.mouse.move(bb.x + bb.width / 2 + 30, bb.y - 40, { steps: 6 });
    await page.mouse.up();
    await page.waitForTimeout(200);
    const r = await S((id) => ({ pan: window.__myconsole.store.getState().tracks.find((t) => t.id === id).pan, eng: window.__myconsole.engine['channels'].get(id).pan.pan.value }), tid);
    await stop();
    assert(r.pan !== 0, 'pan unchanged');
    assert(Math.abs(r.eng - Math.max(-1, Math.min(1, r.pan))) < 0.02, 'engine pan ' + r.eng);
    return `pan ${r.pan.toFixed(2)} (engine ${r.eng.toFixed(2)})`;
  });
  await step('Mix: mute / solo buttons + engine gates', async () => {
    await play();
    const strips = page.locator('.pro-channel-strip');
    const a = await strips.nth(0).getAttribute('data-track-id');
    const b = await strips.nth(1).getAttribute('data-track-id');
    await strips.nth(0).locator('.pro-led-btn.mute').click();
    await page.waitForTimeout(150);
    const m = await S((id) => window.__myconsole.engine['channels'].get(id).muteGate.gain.value, a);
    await strips.nth(0).locator('.pro-led-btn.mute').click();
    await strips.nth(0).locator('.pro-led-btn.solo').click();
    await page.waitForTimeout(150);
    const s = await S(({ a, b }) => [window.__myconsole.engine['channels'].get(a).muteGate.gain.value, window.__myconsole.engine['channels'].get(b).muteGate.gain.value], { a, b });
    await strips.nth(0).locator('.pro-led-btn.solo').click();
    await stop();
    assert(m < 0.001, 'mute gate ' + m);
    assert(s[0] > 0.999 && s[1] < 0.001, 'solo gates ' + s);
    return `mute gate ${m.toExponential(1)} (≤ −60 dB); solo → soloed ${s[0].toFixed(3)} / others ${s[1].toExponential(1)}`;
  });
  await step('Mix: sends → bus / new aux (level + engine send gain)', async () => {
    await play();
    const r = await S(() => {
      const { store } = window.__myconsole;
      const s = store.getState();
      const t = s.tracks.find((x) => x.type === 'audio');
      s.setSendBus(t.id, 'A', 'bus:reverb');
      s.setSendLevel(t.id, 'A', -6);
      const t2 = store.getState().tracks.find((x) => x.id === t.id);
      return { id: t.id, send: t2.sends.find((x) => x.slot === 'A') };
    });
    await page.waitForTimeout(300);
    const gains = await S((id) => [...(window.__myconsole.engine['channels'].get(id)?.sendGains?.entries() || [])].map(([k, g]) => [k, g.gain.value]), r.id);
    const aux = await S(() => { const s = window.__myconsole.store.getState(); const n = s.tracks.length; s.createAndSendToNewAux(s.tracks.find((x) => x.type === 'audio').id, 'B'); return window.__myconsole.store.getState().tracks.length - n; });
    await stop();
    assert(r.send.busId === 'bus:reverb' && r.send.levelDb === -6, JSON.stringify(r.send));
    const g = gains.find(([k]) => k === 'A');
    assert(g && Math.abs(g[1] - Math.pow(10, -6 / 20)) < 0.01, 'engine send gain ' + JSON.stringify(gains));
    assert(aux >= 1, 'no aux created');
    return `send A → bus:reverb at −6 dB (engine ${g[1].toFixed(3)}); send B → new aux (+${aux} track)`;
  });
  await step('Mix: inserts — add plugin, bypass on/off by clicking the slot, engine follows', async () => {
    await play();
    const strip = page.locator('.pro-channel-strip').first();
    const tid = await strip.getAttribute('data-track-id');
    await S((id) => { const s = window.__myconsole.store.getState(); s.setInsert(id, 'E', { id: 'qa-eq', name: 'QA EQ', type: 'eq', bypassed: false }); }, tid);
    await page.waitForTimeout(300);
    const slot = strip.locator('.pro-insert-slot', { hasText: 'QA EQ' }).first();
    await slot.scrollIntoViewIfNeeded();
    await slot.click();
    await page.waitForTimeout(200);
    const r = await S((id) => {
      const t = window.__myconsole.store.getState().tracks.find((x) => x.id === id);
      const ins = t.inserts.find((i) => i.slot === 'E');
      const ch = window.__myconsole.engine['channels'].get(id);
      return { bypassed: ins.plugin.bypassed, blocks: ch.inserts.length, cls: document.querySelector(`.pro-channel-strip[data-track-id="${id}"] .pro-insert-slot.bypass`) != null };
    }, tid);
    await slot.click();
    await page.waitForTimeout(100);
    const r2 = await S((id) => window.__myconsole.store.getState().tracks.find((x) => x.id === id).inserts.find((i) => i.slot === 'E').plugin.bypassed, tid);
    await stop();
    assert(r.bypassed && r.cls && !r2, JSON.stringify(r) + ' ' + r2);
    return `insert E added (engine insert blocks ${r.blocks}); click → bypass (UI + state), click → active`;
  });
  await step('Mix: meters respond while playing', async () => {
    await play();
    await page.waitForTimeout(1000);
    const m = await S(() => window.__myconsole.store.getState().tracks.filter((t) => (t.meterL || 0) > 0.001).length);
    const eng = await S(() => [...window.__myconsole.engine.getMeterLevels().values()].filter((v) => v.l > 0.001).length);
    await stop();
    assert(m > 0 && eng > 0, `meters ${m} ${eng}`);
    return `${m} strip meters moving, ${eng} engine analysers > −60 dBFS`;
  });
  await step('Mix: horizontal / vertical scroll of the mix window', async () => {
    const r = await S(() => {
      const all = [...document.querySelectorAll('.pro-mix-window *, .pro-mix *, [class*=mix] *')];
      const h = all.find((e) => /(auto|scroll)/.test(getComputedStyle(e).overflowX) && e.scrollWidth > e.clientWidth + 4);
      if (!h) return { h: false };
      h.scrollLeft = 300;
      const v = all.find((e) => /(auto|scroll)/.test(getComputedStyle(e).overflowY) && e.scrollHeight > e.clientHeight + 4);
      let vs = null;
      if (v) { v.scrollTop = 100; vs = v.scrollTop; }
      return { h: true, left: h.scrollLeft, cls: String(h.className).slice(0, 40), vs, vcls: v && String(v.className).slice(0, 40) };
    });
    assert(r.h && r.left > 0, 'no horizontal scroll ' + JSON.stringify(r));
    return `horizontal .${r.cls} → ${r.left}px; vertical ${r.vs == null ? 'not needed (strips fit the height)' : `.${r.vcls} → ${r.vs}px`}`;
  });
  await step('Automation: write fader moves while playing, read back replays them', async () => {
    const tid = await S(() => window.__myconsole.store.getState().tracks.find((t) => t.type === 'audio').id);
    await S((id) => { const s = window.__myconsole.store.getState(); s.setAutomationMode('write'); s.setPlayhead(1); s.setVolumeDb(id, 0); }, tid);
    await play();
    for (const db of [-3, -9, -15, -21]) {
      await page.waitForTimeout(350);
      await S(({ id, db }) => window.__myconsole.store.getState().setVolume(id, (db + 60) / 66), { id: tid, db });
    }
    await stop();
    const pts = await S((id) => (window.__myconsole.store.getState().volumeAutomation[id] || []).length, tid);
    await S((id) => { const s = window.__myconsole.store.getState(); s.setAutomationMode('read'); s.setVolumeDb(id, 0); s.setPlayhead(1); }, tid);
    await play();
    const seen = new Set();
    for (let i = 0; i < 10; i++) { await page.waitForTimeout(160); seen.add(await S((id) => window.__myconsole.store.getState().tracks.find((t) => t.id === id).volumeDb.toFixed(1), tid)); }
    await stop();
    await S(() => window.__myconsole.store.getState().setAutomationMode('off'));
    assert(pts >= 3, 'points ' + pts);
    assert(seen.size >= 2, 'read did not move fader: ' + [...seen]);
    return `${pts} points written; read replayed ${[...seen].join(', ')} dB`;
  });
}

// ─────────────────────────────── tests: session / bounce / console ───────────────────────────────
async function testSessionAndBounce() {
  await newPage();
  await step('Bounce: File › Bounce Mix produces a valid, non-silent WAV', async () => {
    const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 30000 }), (async () => {
      await menu('File', 'Bounce Mix…');
      await page.waitForSelector('.mc-dialog');
      const num = page.locator('.mc-dialog input[type=number]');
      if (await num.count()) await num.fill('2');
      await page.locator('.mc-dialog .mc-btn.primary').click();
    })()]);
    const f = path.join(OUT, `qa-${BROWSER}-bounce.wav`);
    await dl.saveAs(f);
    const b = fs.readFileSync(f);
    const riff = b.toString('ascii', 0, 4), wave = b.toString('ascii', 8, 12);
    const ch = b.readUInt16LE(22), sr = b.readUInt32LE(24), bits = b.readUInt16LE(34);
    let off = 12, dataOff = -1, dataLen = 0;
    while (off < b.length - 8) { const id = b.toString('ascii', off, off + 4); const len = b.readUInt32LE(off + 4); if (id === 'data') { dataOff = off + 8; dataLen = len; break; } off += 8 + len; }
    let sq = 0, pk = 0, n = 0;
    for (let i = dataOff; i < dataOff + dataLen - 1; i += 2) { const v = b.readInt16LE(i) / 32768; sq += v * v; pk = Math.max(pk, Math.abs(v)); n++; }
    const rmsDb = 20 * Math.log10(Math.sqrt(sq / n) || 1e-9);
    assert(riff === 'RIFF' && wave === 'WAVE' && dataOff > 0, 'header');
    assert(dataLen === b.length - dataOff, 'data length mismatch');
    assert(rmsDb > -60, 'silent bounce ' + rmsDb);
    return `${dl.suggestedFilename()} · ${ch} ch · ${sr} Hz · ${bits}-bit · ${(n / ch / sr).toFixed(2)} s · RMS ${rmsDb.toFixed(1)} dBFS · peak ${(20 * Math.log10(pk)).toFixed(1)} dBFS`;
  });
  await step('Headroom modes Standard/Studio/Mastering (transport select → engine)', async () => {
    const got = [];
    const opts = await page.$$eval('.headroom-box select option', (o) => o.map((x) => x.value));
    for (const v of opts) {
      await page.selectOption('.headroom-box select', v);
      got.push(`${v}:${await S(() => window.__myconsole.engine.getHeadroomDb())}`);
    }
    await page.selectOption('.headroom-box select', 'standard');
    assert(got.length >= 3 && new Set(got.map((g) => g.split(':')[1])).size === got.length, got.join());
    return got.join(', ') + ' dB';
  });
  await step('Console tab: hardware desk renders a strip per track', async () => {
    await view('console');
    await page.waitForTimeout(300);
    const n = await page.locator('.hw-strip-row > *').count();
    const t = await S(() => window.__myconsole.store.getState().tracks.length);
    assert(n > 0, 'no strips');
    return `${n} strips for ${t} tracks`;
  });
}

// ─────────────────────────────── DEPLOY-2: persistence / packages ───────────────────────────────
const crypto = require('crypto');
function makeWav(sr, secs, freq, amp) {
  const n = Math.round(sr * secs);
  const b = Buffer.alloc(44 + n * 2);
  b.write('RIFF', 0); b.writeUInt32LE(36 + n * 2, 4); b.write('WAVE', 8); b.write('fmt ', 12);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22); b.writeUInt32LE(sr, 24);
  b.writeUInt32LE(sr * 2, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write('data', 36); b.writeUInt32LE(n * 2, 40);
  const f = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const v = Math.round(Math.sin((2 * Math.PI * freq * i) / sr) * amp * 32767);
    b.writeInt16LE(v, 44 + i * 2);
    f[i] = (v | 0) / 32768; // -0 → +0 like a real int16 read
  }
  return { buf: b, hash: crypto.createHash('sha256').update(Buffer.from(f.buffer)).digest('hex') };
}
function readZipNode(buf) { // central directory → { name: Buffer } (stored entries)
  let eocd = buf.length - 22;
  while (eocd >= 0 && buf.readUInt32LE(eocd) !== 0x06054b50) eocd--;
  if (eocd < 0) throw new Error('not a zip');
  const n = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const out = {};
  for (let i = 0; i < n; i++) {
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl);
    const lnl = buf.readUInt16LE(lo + 26), lel = buf.readUInt16LE(lo + 28);
    const data = buf.subarray(lo + 30 + lnl + lel, lo + 30 + lnl + lel + csize);
    out[name] = method === 0 ? data : require('zlib').inflateRawSync(data);
    p += 46 + nl + el + cl;
  }
  return out;
}
const waitTake = (takeId, ms = 8000) => page.waitForFunction((id) => {
  const t = window.__myconsole.audioIO.takes.get(id);
  return t && t.persist !== 'pending';
}, takeId, { timeout: ms });
const idbKeys = () => S(() => new Promise((res) => {
  const r = indexedDB.open('royal-console-audio');
  r.onupgradeneeded = () => r.transaction.abort(); // never create the app's DB from the test
  r.onsuccess = () => {
    const db = r.result;
    if (!db.objectStoreNames.contains('takes')) { db.close(); return res([]); }
    const q = db.transaction('takes', 'readonly').objectStore('takes').getAllKeys();
    q.onsuccess = () => { db.close(); res(q.result.map(String)); };
    q.onerror = () => { db.close(); res([]); };
  };
  r.onerror = () => res([]);
  r.onblocked = () => res([]);
}));
async function importWav(file) {
  const [fc] = await Promise.all([page.waitForEvent('filechooser', { timeout: 8000 }), menu('File', 'Import', 'Audio…')]);
  await fc.setFiles(file);
  await page.waitForFunction(() => /Import/i.test(window.__myconsole.store.getState().statusMessage || ''), null, { timeout: 8000 }).catch(() => {});
  await page.waitForTimeout(600);
  return S(() => {
    const s = window.__myconsole.store.getState();
    const clips = s.tracks.flatMap((t) => t.clips.map((c) => ({ ...c, trackId: t.id }))).filter((c) => c.audio);
    return { clip: clips[clips.length - 1] || null, status: s.statusMessage };
  });
}
async function guardianTexts(re) {
  if (!(await page.$('[data-testid=aieng-panel]'))) await page.click('button.aieng-topbar-btn').catch(() => {});
  await page.waitForTimeout(400);
  return page.$$eval('.aieng-msg-text', (els, src) => els.map((e) => e.textContent).filter((t) => new RegExp(src).test(t)), re.source);
}
async function testPersistence() {
  const hasFake = BROWSER !== 'webkit';
  await newPage();
  let A = null; // { clipId, takeId, hash, trackId }
  let I = null;
  const wav = makeWav(48000, 1.0, 440, 0.5);
  const wavFile = path.join(OUT, `qa-${BROWSER}-import.wav`);
  fs.writeFileSync(wavFile, wav.buf);
  await step('Persist: recorded take stored in IndexedDB (sessionId/takeId, PCM + sample rate/channels + peaks)', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device in headless WebKit (persistence is covered below with an imported WAV)' };
    const tid = await S(() => { const s = window.__myconsole.store.getState(); const t = s.tracks.find((x) => x.type === 'audio'); s.toggleArm(t.id); s.setPlayhead(3); return t.id; });
    await page.waitForTimeout(600);
    await page.click('button:text-is("REC")');
    await page.waitForTimeout(2500);
    await page.click('button:text-is("STOP")');
    await page.waitForTimeout(500);
    const c = await S((id) => { const t = window.__myconsole.store.getState().tracks.find((x) => x.id === id); const c = t.clips[t.clips.length - 1]; return c && c.audio ? { clipId: c.id, takeId: c.audio.takeId } : null; }, tid);
    assert(c, 'recorded clip has no audio ref');
    await waitTake(c.takeId);
    const r = await S(async (id) => { const { audioIO } = window.__myconsole; const t = audioIO.takes.get(id); return { persist: t.persist, hash: await audioIO.takeHash(id), sr: t.buffer.sampleRate, ch: t.buffer.numberOfChannels, dur: t.buffer.duration, sid: audioIO.sessionId() }; }, c.takeId);
    await S((id) => window.__myconsole.store.getState().toggleArm(id), tid);
    const keys = await idbKeys();
    assert(r.persist === 'saved', 'persist ' + r.persist);
    assert(keys.includes(`${r.sid}/${c.takeId}`), 'IDB key missing: ' + keys.join(','));
    A = { ...c, hash: r.hash, trackId: tid };
    return `take ${c.takeId} · ${r.dur.toFixed(2)} s · ${r.sr} Hz · ${r.ch} ch · IDB key ${r.sid}/${c.takeId} · sha256 ${r.hash.slice(0, 12)}…`;
  });
  await step('Import › Audio… decodes a WAV exactly, places a clip and persists it (sample-exact hash)', async () => {
    const r = await importWav(wavFile);
    assert(r.clip, 'no imported clip: ' + r.status);
    await waitTake(r.clip.audio.takeId);
    const h = await S((id) => window.__myconsole.audioIO.takeHash(id), r.clip.audio.takeId);
    assert(h === wav.hash, `hash ${h} ≠ expected ${wav.hash}`);
    I = { clipId: r.clip.id, takeId: r.clip.audio.takeId, hash: h, trackId: r.clip.trackId };
    return `${r.status} · decoded PCM sha256 matches the source file's samples (${h.slice(0, 12)}…)`;
  });
  await step('Edit: split an audio clip → right half plays from the matching offset in the take; Undo restores', async () => {
    assert(I, 'no imported take');
    const r = await S((w) => {
      const { store } = window.__myconsole;
      const s = store.getState();
      const c = s.tracks.flatMap((t) => t.clips).find((x) => x.id === w.clipId);
      const mid = c.startBar + c.lengthBars / 2;
      s.clearWaveformSelection(); s.selectClip(c.id); s.setPlayhead(mid);
      store.getState().splitAtPlayheadOrSelection();
      const t = store.getState().tracks.find((x) => x.id === w.trackId);
      const parts = t.clips.filter((x) => x.audio && x.audio.takeId === w.takeId);
      const secPerBar = (60 / store.getState().tempo) * 4;
      return { n: parts.length, offs: parts.map((p) => p.audio.offsetSec), expect: (mid - c.startBar) * secPerBar };
    }, I);
    await menu('Edit', 'Undo');
    const after = await S((w) => window.__myconsole.store.getState().tracks.find((x) => x.id === w.trackId).clips.filter((x) => x.audio && x.audio.takeId === w.takeId).map((x) => x.id), I);
    assert(r.n === 2, 'split pieces ' + r.n);
    assert(Math.abs(Math.max(...r.offs) - r.expect) < 0.002 && Math.min(...r.offs) === 0, `offsets ${r.offs} vs ${r.expect}`);
    assert(after.length === 1 && after[0] === I.clipId, 'undo did not restore the original clip');
    return `offsets ${r.offs.map((o) => o.toFixed(3)).join(' / ')} s (expected ${r.expect.toFixed(3)}) · Edit › Undo → original clip back`;
  });
  await step('Persist: reload → autosaved session restores clips, same audio hash, real peaks, plays', async () => {
    const want = [A, I].filter(Boolean);
    assert(want.length, 'nothing to check');
    await page.waitForTimeout(2600); // autosave interval
    await page.reload();
    await page.waitForFunction(() => !!window.__myconsole, null, { timeout: 15000 });
    await page.waitForFunction((ids) => ids.every((id) => window.__myconsole.audioIO.takes.has(id)), want.map((w) => w.takeId), { timeout: 10000 });
    const got = [];
    for (const w of want) {
      const r = await S(async (w) => {
        const { store, audioIO, engine } = window.__myconsole;
        const t = store.getState().tracks.find((x) => x.id === w.trackId);
        const c = t && t.clips.find((x) => x.id === w.clipId);
        if (!c) return { missing: true };
        const p = audioIO.peaksForClip(c);
        store.getState().setPlayhead(c.startBar);
        const ctx = engine.ensureContext();
        const n = audioIO['scheduleTakes'](ctx, w.trackId, ctx.createGain());
        n.forEach((x) => { try { x.stop(); } catch {} });
        return { hash: await audioIO.takeHash(w.takeId), peaks: !!p && p.some((v) => v > 0), sched: n.length };
      }, w);
      assert(!r.missing, `clip ${w.clipId} gone after reload`);
      assert(r.hash === w.hash, `hash changed for ${w.takeId}`);
      assert(r.peaks, 'no real peaks');
      assert(r.sched >= 1, 'not scheduled');
      got.push(`${w === A ? 'recorded' : 'imported'} ${w.takeId}: hash equal, peaks, scheduled`);
    }
    const status = await S(() => window.__myconsole.store.getState().statusMessage);
    return got.join(' · ') + ` · "${status}"`;
  });
  let pkg = null;
  await step('Package: Save Session As → .mycsession zip (session.json + Audio Files/*.wav, sha-256 per file)', async () => {
    const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 15000 }), (async () => {
      await menu('File', 'Save Session As…');
      await page.waitForSelector('.mc-dialog input');
      await page.fill('.mc-dialog input', 'QA Package');
      await page.locator('.mc-dialog .mc-btn.primary').click();
    })()]);
    pkg = path.join(OUT, `qa-${BROWSER}.mycsession`);
    await dl.saveAs(pkg);
    const z = readZipNode(fs.readFileSync(pkg));
    const j = JSON.parse(z['session.json'].toString('utf8'));
    const wavs = Object.keys(z).filter((n) => /^Audio Files\/.+\.wav$/.test(n));
    const ids = [A, I].filter(Boolean).map((x) => x.takeId);
    assert(/\.mycsession$/.test(dl.suggestedFilename()), 'name ' + dl.suggestedFilename());
    assert(ids.every((id) => j.audioFiles && j.audioFiles[id] && z[j.audioFiles[id].file]), 'audio missing in package');
    for (const id of ids) { const w = z[j.audioFiles[id].file]; assert(w.toString('ascii', 0, 4) === 'RIFF' && w.toString('ascii', 8, 12) === 'WAVE', 'bad wav'); }
    return `${dl.suggestedFilename()} · ${(fs.statSync(pkg).size / 1024).toFixed(0)} KB · session.json + ${wavs.length} WAV (${wavs.map((w) => w.slice(12)).join(', ')})`;
  });
  await step('Package: File › Open in a FRESH browser profile restores audio into IndexedDB (same hashes)', async () => {
    assert(pkg, 'no package');
    await newPage(); // new BrowserContext = empty IndexedDB/localStorage
    const before = await idbKeys();
    const [fc] = await Promise.all([page.waitForEvent('filechooser', { timeout: 8000 }), menu('File', 'Open Session…')]);
    await fc.setFiles(pkg);
    const want = [A, I].filter(Boolean);
    await page.waitForFunction((ids) => ids.every((id) => window.__myconsole.audioIO.takes.has(id)), want.map((w) => w.takeId), { timeout: 15000 });
    await page.waitForTimeout(500);
    const got = await S(async (want) => {
      const { audioIO, store } = window.__myconsole;
      const out = [];
      for (const w of want) out.push({ hash: await audioIO.takeHash(w.takeId), clip: store.getState().tracks.some((t) => t.clips.some((c) => c.id === w.clipId)) });
      return { out, status: store.getState().statusMessage, sid: audioIO.sessionId() };
    }, want);
    const after = await idbKeys();
    want.forEach((w, i) => { assert(got.out[i].hash === w.hash, 'hash mismatch ' + w.takeId); assert(got.out[i].clip, 'clip missing ' + w.clipId); assert(after.includes(`${got.sid}/${w.takeId}`), 'not in IDB ' + w.takeId); });
    return `IDB keys ${before.length} → ${after.length} · ${want.length} take(s) hash-identical · "${got.status}"`;
  });
  await step('Session: legacy .mycsession.json (Save Session ⌘S) still opens (roundtrip)', async () => {
    await S(() => window.__myconsole.store.getState().setTempo(133));
    const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 8000 }), menu('File', 'Save Session')]);
    const saved = path.join(OUT, `qa-${BROWSER}.mycsession.json`);
    await dl.saveAs(saved);
    const j = JSON.parse(fs.readFileSync(saved, 'utf8'));
    assert(j.format === 'mycsession' && j.tracks.length > 0, 'bad file');
    const before = await S(() => window.__myconsole.store.getState().tracks.length);
    await S(() => { const s = window.__myconsole.store.getState(); s.setTempo(90); s.addAudioTrack(); });
    const [fc] = await Promise.all([page.waitForEvent('filechooser', { timeout: 8000 }), menu('File', 'Open Session…')]);
    await fc.setFiles(saved);
    await page.waitForTimeout(900);
    const after = await S(() => ({ n: window.__myconsole.store.getState().tracks.length, tempo: window.__myconsole.store.getState().tempo, status: window.__myconsole.store.getState().statusMessage }));
    assert(after.tempo === 133, 'tempo ' + after.tempo);
    assert(after.n === before, `tracks ${before} vs ${after.n}`);
    return `${dl.suggestedFilename()} · tempo 90→133 restored, tracks ${after.n} · "${after.status}"`;
  });
  await step('Undo of a clip delete keeps its audio; Clean Up removes only orphaned audio', async () => {
    assert(I, 'no imported take');
    const has = await S((id) => window.__myconsole.store.getState().tracks.some((t) => t.clips.some((c) => c.id === id)), I.clipId);
    assert(has, 'imported clip not in session');
    const sid = await S(() => window.__myconsole.audioIO.sessionId());
    await S((id) => { const s = window.__myconsole.store.getState(); s.clearWaveformSelection(); s.selectClip(id); s.cutSelectionOrClip(); }, I.clipId);
    const gone = await S((id) => !window.__myconsole.store.getState().tracks.some((t) => t.clips.some((c) => c.id === id)), I.clipId);
    assert(gone, 'delete did not remove clip');
    assert((await idbKeys()).includes(`${sid}/${I.takeId}`), 'delete removed audio from IDB');
    await menu('Edit', 'Undo');
    const back = await S(async (w) => {
      const { store, audioIO } = window.__myconsole;
      const c = store.getState().tracks.flatMap((t) => t.clips).find((c) => c.id === w.clipId);
      return { back: !!c, hash: c ? await audioIO.takeHash(c.audio.takeId) : null, status: store.getState().statusMessage };
    }, I);
    assert(back.back && back.hash === I.hash, 'undo did not restore clip+audio ' + JSON.stringify(back));
    await S((id) => { const s = window.__myconsole.store.getState(); s.selectClip(id); s.cutSelectionOrClip(); }, I.clipId);
    await menu('File', 'Clean Up Unused Audio…');
    await page.waitForFunction(() => /Clean Up/.test(window.__myconsole.store.getState().statusMessage || ''), null, { timeout: 8000 });
    const status = await S(() => window.__myconsole.store.getState().statusMessage);
    const keys = await idbKeys();
    assert(!keys.includes(`${sid}/${I.takeId}`), 'orphan not removed');
    if (A) assert(keys.includes(`${sid}/${A.takeId}`), 'referenced take was removed');
    return `delete → audio still in IDB · Edit › Undo → clip back, hash identical ("${back.status}") · delete + Clean Up → "${status}"${A ? ' · referenced recorded take kept' : ''}`;
  });
  await step('Storage: quota error on save → take marked unsaved + clear warning + Session Guardian', async () => {
    await S(() => {
      window.__origPut = IDBObjectStore.prototype.put;
      IDBObjectStore.prototype.put = function () { throw new DOMException('simulated: quota exceeded', 'QuotaExceededError'); };
    });
    let r;
    try { r = await importWav(wavFile); } finally { await S(() => { IDBObjectStore.prototype.put = window.__origPut; }); }
    assert(r.clip, 'import failed entirely: ' + r.status);
    const t = await S((id) => { const { audioIO } = window.__myconsole; const t = audioIO.takes.get(id); return { persist: t.persist, err: audioIO.getState().storage.lastError, unsaved: audioIO.unsavedTakes().length }; }, r.clip.audio.takeId);
    assert(t.persist === 'failed' && /storage is full/i.test(t.err || ''), JSON.stringify(t));
    const g = await guardianTexts(/^Storage:.*full/);
    assert(g.length >= 1, 'no Guardian storage message');
    return `QuotaExceededError (simulated by stubbing IDBObjectStore.put) → take persist=failed, unsaved takes ${t.unsaved}; warning: "${t.err.slice(0, 90)}…"; Guardian: "${g[0].slice(0, 70)}…"`;
  });
  await step('Storage: low free space (navigator.storage.estimate) → Session Guardian warning', async () => {
    const ok = await S(async () => {
      if (!navigator.storage || !navigator.storage.estimate) return false;
      const orig = navigator.storage.estimate.bind(navigator.storage);
      navigator.storage.estimate = async () => ({ usage: 950 * 1048576, quota: 1000 * 1048576 });
      try { await window.__myconsole.audioIO.checkStorage(); } finally { navigator.storage.estimate = orig; }
      return true;
    });
    if (!ok) return { status: 'LIMITED', notes: 'navigator.storage.estimate not available' };
    const g = await guardianTexts(/^Storage:.*low/);
    assert(g.length >= 1, 'no low-storage Guardian message');
    const persist = await S(() => typeof (navigator.storage && navigator.storage.persist));
    return `Guardian: "${g[0].slice(0, 110)}" · navigator.storage.persist is ${persist === 'function' ? 'requested on first save' : 'unavailable'}`;
  });
  await step('Session Guardian: recorded take not yet exported → notice', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device in headless WebKit' };
    // the recording happened in the first page (before the fresh profile); check its I/O event log there is not possible now → re-record briefly
    const tid = await S(() => { const s = window.__myconsole.store.getState(); const t = s.tracks.find((x) => x.type === 'audio'); s.toggleArm(t.id); s.setPlayhead(9); return t.id; });
    await page.waitForTimeout(500);
    await page.click('button:text-is("REC")');
    await page.waitForTimeout(1200);
    await page.click('button:text-is("STOP")');
    await page.waitForTimeout(1200);
    await S((id) => window.__myconsole.store.getState().toggleArm(id), tid);
    const g = await guardianTexts(/^Takes:/);
    assert(g.length >= 1, 'no Takes notice');
    return `Guardian: "${g[0].slice(0, 120)}"`;
  });
}
// ─────────────────────────────── DEPLOY-2: input monitoring ───────────────────────────────
const meterMax = (tid, ms = 1800) => S(async ({ tid, ms }) => {
  const { store } = window.__myconsole;
  let tr = 0, ms_ = 0;
  const t0 = performance.now();
  while (performance.now() - t0 < ms) {
    const s = store.getState();
    const t = s.tracks.find((x) => x.id === tid);
    const m = s.tracks.find((x) => x.type === 'master' || x.trackType === 'MasterFader');
    tr = Math.max(tr, t.meterL || 0, t.meterR || 0);
    ms_ = Math.max(ms_, (m && (m.meterL || 0)) || 0, (m && (m.meterR || 0)) || 0);
    await new Promise((r) => setTimeout(r, 40));
  }
  return { track: tr, master: ms_ };
}, { tid, ms });
const monState = () => S(() => { const { audioIO, engine } = window.__myconsole; const a = audioIO.getState(); return { monitored: a.monitoredTracks, risk: a.monitorFeedbackRisk, monOnly: engine.isMonitorOnly(), inputOpen: a.inputOpen }; });
async function recordTake(tid, ms) {
  await S((id) => window.__myconsole.store.getState().setPlayhead(5), tid);
  await page.click('button:text-is("REC")');
  await page.waitForTimeout(500);
  const during = await monState();
  await page.waitForTimeout(ms);
  await page.click('button:text-is("STOP")');
  await page.waitForTimeout(600);
  const r = await S((id) => {
    const { store, audioIO } = window.__myconsole;
    const t = store.getState().tracks.find((x) => x.id === id);
    const c = t.clips[t.clips.length - 1];
    const take = c && c.audio && audioIO.takes.get(c.audio.takeId);
    if (!take) return null;
    let pk = 0, sq = 0, n = 0;
    for (let ch = 0; ch < take.buffer.numberOfChannels; ch++) { const d = take.buffer.getChannelData(ch); for (let i = 0; i < d.length; i++) { const v = Math.abs(d[i]); if (v > pk) pk = v; sq += v * v; n++; } }
    return { peakDb: 20 * Math.log10(pk || 1e-9), rms: Math.sqrt(sq / n), dur: take.buffer.duration };
  }, tid);
  return { ...r, during };
}
async function testMonitoring() {
  const hasFake = BROWSER !== 'webkit';
  await newPage();
  const tid = await S(() => window.__myconsole.store.getState().tracks.find((x) => x.type === 'audio').id);
  await step('Monitor: TrackInput (I) button → live input through the channel strip to master meters (transport stopped)', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device in headless WebKit' };
    await view('split');
    await page.click(`[data-testid=input-mon-${tid}]`);
    await page.waitForFunction((id) => window.__myconsole.audioIO.getState().monitoredTracks.includes(id), tid, { timeout: 8000 });
    await page.waitForTimeout(500);
    const cls = await page.getAttribute(`[data-testid=input-mon-${tid}]`, 'class');
    const ms = await monState();
    const m = await meterMax(tid, 2500);
    const lit = await S((id) => { const e = document.querySelector(`[data-testid=input-mon-${id}]`); const e2 = document.querySelector(`[data-testid=edit-input-mon-${id}]`); return [e, e2].map((x) => x ? getComputedStyle(x).backgroundImage : 'none'); }, tid);
    assert(/\bon\b/.test(cls), 'I button not lit');
    assert(lit.every((b) => /radial-gradient\(.*141, 255, 168/.test(b)), 'I button not visibly green: ' + lit.join(' | '));
    assert(ms.monOnly && ms.inputOpen, JSON.stringify(ms));
    assert(m.track > 0.001 && m.master > 0.001, 'meters silent ' + JSON.stringify(m));
    await page.screenshot({ path: path.join(SHOTS, `${BROWSER}-input-monitor.png`) });
    if (BROWSER === 'chromium') await page.screenshot({ path: '/workspace/deploy2-monitor.png' });
    return `I lit green in mixer + edit track header · monitored ${ms.monitored.join(',')} · monitor-only graph running · track meter peak ${m.track.toFixed(3)}, master ${m.master.toFixed(3)} with transport stopped`;
  });
  await step('Monitor: input follows the channel strip (mute → input gone from master, fader −20 dB → quieter, unmute → back)', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device' };
    await S((id) => window.__myconsole.store.getState().toggleMute(id), tid);
    await page.waitForTimeout(1500); // meter release
    const muted = await meterMax(tid, 2000);
    await S((id) => window.__myconsole.store.getState().toggleMute(id), tid);
    await page.waitForTimeout(600);
    const on = await meterMax(tid, 2000);
    const vol0 = await S((id) => { const s = window.__myconsole.store.getState(); const t = s.tracks.find((x) => x.id === id); const v = t.volumeDb; s.setVolumeDb(id, (v ?? 0) - 20); return v ?? 0; }, tid);
    await page.waitForTimeout(1500);
    const down = await meterMax(tid, 2000);
    await S(({ id, v }) => window.__myconsole.store.getState().setVolumeDb(id, v), { id: tid, v: vol0 });
    assert(muted.track < 1e-4, 'muted track meter still shows input ' + muted.track);
    assert(muted.master < on.master * 0.05, `master still hears muted input: ${muted.master} vs ${on.master}`);
    assert(on.master > 0.001, 'no signal after unmute');
    assert(down.master < on.master * 0.7, `fader -20 dB did not lower master: ${down.master} vs ${on.master}`);
    return `muted: track ${muted.track.toExponential(1)}, master ${muted.master.toFixed(3)} (= other channels' emulated plugin noise floor) · unmuted ${on.master.toFixed(3)} · fader −20 dB → master ${down.master.toFixed(3)} (meter scale is display-scaled; kick feeds the compressed Drum Bus)`;
  });
  await step('Monitor: Auto Input (armed: input when stopped, track on playback) / Input Only (input always) — Options menu', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device' };
    await S((id) => { const s = window.__myconsole.store.getState(); if (s.inputMonitorIds.includes(id)) s.toggleInputMonitor(id); s.toggleArm(id); }, tid);
    await page.waitForTimeout(700);
    const armedStopped = (await monState()).monitored.includes(tid);
    const inMeter = (await meterMax(tid, 1500)).track;
    await S(() => window.__myconsole.store.getState().play());
    await page.waitForTimeout(900);
    const autoPlaying = (await monState()).monitored.includes(tid);
    await S(() => window.__myconsole.store.getState().stop());
    await menu('Options', 'Input Only Monitoring');
    const mode = await S(() => window.__myconsole.store.getState().monitorMode);
    await S(() => window.__myconsole.store.getState().play());
    await page.waitForTimeout(900);
    const ioPlaying = (await monState()).monitored.includes(tid);
    await S(() => window.__myconsole.store.getState().stop());
    await menu('Options', 'Auto Input Monitoring');
    await page.waitForTimeout(400);
    const back = await S(() => window.__myconsole.store.getState().monitorMode);
    assert(armedStopped, 'armed+stopped not monitored');
    assert(inMeter > 0.001, 'armed track meter shows no input');
    assert(!autoPlaying, 'auto mode still monitoring during playback');
    assert(mode === 'input-only' && ioPlaying, 'input-only not monitoring during playback');
    assert(back === 'auto', 'mode not restored');
    return `auto: armed+stopped → input (track meter ${inMeter.toFixed(3)}), playing → track playback; input-only: playing → input; menu toggles mode`;
  });
  await step('Monitor: no double record — take level with monitoring ON ≈ monitoring OFF (monitored output never re-captured)', async () => {
    if (!hasFake) return { status: 'LIMITED', notes: 'no capture device' };
    const a = await recordTake(tid, 2200); // armed → auto input monitoring during record
    const orig = await S(() => { const a = window.__myconsole.audioIO.getState(); return { i: a.activeInputLabel, o: a.activeOutputLabel }; });
    await S(() => { const io = window.__myconsole.audioIO; io['set']({ activeInputLabel: 'MacBook Pro Microphone', activeOutputLabel: 'MacBook Pro Speakers' }); io.refreshMonitoring(); });
    await page.waitForTimeout(400);
    const b = await recordTake(tid, 2200); // feedback-risk labels → monitoring suppressed
    await S((o) => { const io = window.__myconsole.audioIO; io['set']({ activeInputLabel: o.i, activeOutputLabel: o.o }); io.refreshMonitoring(); }, orig);
    assert(a && b, 'take missing');
    assert(a.during.monitored.includes(tid) && !b.during.monitored.includes(tid), `monitor states ${JSON.stringify(a.during.monitored)} / ${JSON.stringify(b.during.monitored)}`);
    const dPk = a.peakDb - b.peakDb;
    const ratio = a.rms / Math.max(1e-9, b.rms);
    assert(Math.abs(dPk) < 1.5, 'peak differs by ' + dPk.toFixed(2) + ' dB');
    assert(ratio > 0.7 && ratio < 1.4, 'rms ratio ' + ratio.toFixed(2) + ' (doubling would be ≈2)');
    return `monitoring ON: peak ${a.peakDb.toFixed(2)} dBFS rms ${a.rms.toFixed(4)} · OFF: peak ${b.peakDb.toFixed(2)} dBFS rms ${b.rms.toFixed(4)} · Δpeak ${dPk.toFixed(2)} dB · RMS ratio ${ratio.toFixed(2)} (a re-captured monitor signal would add ≈ +6 dB / ratio ≈ 2)`;
  });
  await step('Feedback safety: built-in mic + built-in speakers → auto monitoring off, warning + Session Guardian; override checkbox', async () => {
    const orig = await S(() => { const a = window.__myconsole.audioIO.getState(); return { i: a.activeInputLabel, o: a.activeOutputLabel }; });
    const cases = await S(() => {
      const io = window.__myconsole.audioIO;
      const out = [];
      for (const [i, o] of [['MacBook Pro Microphone', 'MacBook Pro Speakers'], ['MacBook Pro Microphone', 'External Headphones'], ['Scarlett 2i2 USB', 'MacBook Pro Speakers'], ['Microphone Array (Realtek(R) Audio)', 'Speakers (Realtek(R) Audio)']]) {
        io['set']({ activeInputLabel: i, activeOutputLabel: o });
        out.push(`${i} → ${o}: ${io.feedbackRisk() ? 'RISK' : 'ok'}`);
      }
      io['set']({ activeInputLabel: 'MacBook Pro Microphone', activeOutputLabel: 'MacBook Pro Speakers' });
      io.refreshMonitoring();
      return out;
    });
    await page.waitForTimeout(600);
    const ms = await monState();
    const armed = await S((id) => window.__myconsole.store.getState().tracks.find((t) => t.id === id).armed, tid);
    let g = [], dlg = '', override = null;
    if (hasFake) {
      g = await guardianTexts(/^Monitoring:/);
      await closeDialogs();
      await menu('Setup', 'I/O…');
      await page.waitForSelector('[data-testid=io-feedback-risk]', { timeout: 4000 });
      dlg = (await page.textContent('[data-testid=io-feedback-risk]')).trim();
      await page.check('[data-testid=io-allow-speaker-monitor]');
      await page.waitForTimeout(700);
      override = (await monState()).monitored.includes(tid);
      await page.uncheck('[data-testid=io-allow-speaker-monitor]');
      await closeDialogs();
    }
    await S((o) => { const io = window.__myconsole.audioIO; io['set']({ activeInputLabel: o.i, activeOutputLabel: o.o }); io.refreshMonitoring(); }, orig);
    assert(cases[0].endsWith('RISK') && cases[1].endsWith('ok') && cases[2].endsWith('ok') && cases[3].endsWith('RISK'), cases.join('; '));
    if (!hasFake) return { status: 'LIMITED', notes: 'label rule verified (' + cases.join('; ') + '); live suppression needs a capture device' };
    assert(armed && ms.risk && !ms.monitored.includes(tid), 'armed track still auto-monitored under risk ' + JSON.stringify(ms));
    assert(g.length >= 1, 'no Guardian monitoring warning');
    assert(override === true, 'override did not enable monitoring');
    return `${cases.join('; ')} · armed track NOT monitored under risk · I/O: "${dlg.slice(0, 80)}" · override → monitored · Guardian: "${g[0].slice(0, 90)}"`;
  });
  await step('Playback Engine: monitoring latency (input + base + output) reported', async () => {
    await closeDialogs();
    await S(() => window.__myconsole.engine.ensureContext());
    await menu('Setup', 'Playback Engine…');
    await page.waitForSelector('[data-testid=pe-monitor-latency]');
    await page.waitForTimeout(500);
    const t = (await page.textContent('[data-testid=pe-monitor-latency]')).trim();
    const st2 = (await page.textContent('[data-testid=pe-storage]').catch(() => '')).trim();
    await closeDialogs();
    if (!/\d+(\.\d+)? ms/.test(t)) return { status: 'LIMITED', notes: `browser reports no latency figures: "${t}" · storage: "${st2}"` };
    return `"${t}" · storage row: "${st2}"`;
  });
  await S((id) => { const s = window.__myconsole.store.getState(); const t = s.tracks.find((x) => x.id === id); if (t.armed) s.toggleArm(id); }, tid).catch(() => {});
}

// ─────────────────────────────── tests: AI engineer / cloud ───────────────────────────────
async function testAI() {
  await newPage();
  await page.click('button.aieng-topbar-btn');
  await page.waitForSelector('[data-testid=aieng-panel]');
  await page.waitForTimeout(600);
  const lastMsgs = (n = 1) => page.$$eval('.aieng-msg-text', (els, n) => els.slice(-n).map((e) => e.textContent), n);
  const say = async (q, wait = 900) => { await page.click('.aieng-tab[data-tab=chat]'); await page.fill('.aieng-input', q); await page.press('.aieng-input', 'Enter'); await page.waitForTimeout(wait); return (await lastMsgs(1))[0] || ''; };
  await step('AI Engineer: greeting + scan report', async () => {
    const g = (await page.$$eval('.aieng-msg-text', (e) => e.map((x) => x.textContent)))[0] || '';
    const r = await say('scan', 1200);
    const report = await page.$('[data-testid=aieng-scan-report]');
    assert(/Welcome/.test(g), 'no greeting');
    assert(report || /health|finding|issue|clean/i.test(r), 'no scan report');
    return 'greeting + scan report rendered';
  });
  await step('AI Engineer: measure (real analyser, ~4 s)', async () => {
    const r = await say('measure', 7000);
    assert(/LUFS|dBFS|peak|loud/i.test(r), r.slice(0, 120));
    return r.slice(0, 160);
  });
  await step('AI Engineer: fix session + snapshot restore', async () => {
    await page.click('.aieng-tab[data-tab=fix]');
    await page.waitForTimeout(300);
    const run = page.locator('text=Run Fix Session');
    if (await run.count()) await run.first().click();
    await page.waitForTimeout(1500);
    const approve = page.locator('.aieng-pane button:has-text("Approve")');
    if (await approve.count()) { await approve.first().click(); await page.waitForTimeout(3000); }
    await page.click('.aieng-tab[data-tab=snapshots]');
    await page.waitForTimeout(300);
    const snaps = await page.locator('.aieng-snap').count();
    const restore = page.locator('.aieng-snap button:has-text("Restore")').first();
    let restored = false;
    if (await restore.count()) { await restore.click(); await page.waitForTimeout(500); restored = true; }
    assert(snaps >= 1, 'no snapshots after fix');
    return `${snaps} snapshot(s); restore ${restored ? 'clicked' : 'n/a'}`;
  });
  await step('AI Engineer: ideas → audition A/B → keep / reject', async () => {
    await page.click('.aieng-tab[data-tab=ideas]');
    await page.waitForSelector('[data-testid=aieng-ideas] .aieng-idea', { timeout: 8000 });
    const n = await page.locator('.aieng-idea').count();
    await page.locator('.aieng-idea button:has-text("Audition")').first().click();
    await page.waitForSelector('.aieng-audition');
    await page.click('.aieng-ab button:has-text("A")');
    await page.click('.aieng-ab button:has-text("B")');
    await page.click('.aieng-audition button:has-text("Keep")');
    await page.waitForTimeout(400);
    await page.locator('.aieng-idea button:has-text("Audition")').first().click();
    await page.waitForSelector('.aieng-audition');
    await page.click('.aieng-audition button:has-text("Reject")');
    await page.waitForTimeout(300);
    return `${n} ideas; audition A/B, keep and reject worked`;
  });
  await step('AI Engineer: surprise / challenge / mastering check (AI menu)', async () => {
    const before = await page.locator('.aieng-msg-text').count();
    for (const it of ['Surprise Me', 'Challenge My Mix', 'Mastering Check']) { await menu('AI', it); await page.waitForTimeout(it === 'Mastering Check' ? 6000 : 900); await closeDialogs(); }
    await page.click('.aieng-tab[data-tab=chat]');
    await page.waitForTimeout(200);
    const after = await page.locator('.aieng-msg-text').count();
    assert(after > before, 'no new messages');
    return `${after - before} new messages`;
  });
  await step('AI Engineer: chat intents + producer profile', async () => {
    const replies = [];
    for (const q of ['what can you do?', 'make the vocals brighter', 'undo', 'how loud is my mix?']) replies.push((await say(q, 1600)).slice(0, 60));
    await menu('AI', 'Producer Profile');
    await page.waitForTimeout(300);
    const prof = await page.locator('.aieng-pane').first().textContent().catch(() => '');
    assert(replies.every((r) => r && r.length > 5), 'empty replies');
    return `replies: ${replies.join(' | ')} · profile pane ${prof.length} chars`;
  });
  await step('AI Engineer: voice (TTS via speechSynthesis mock)', async () => {
    const sp = page.locator('[data-testid=aieng-speaker]');
    if (await sp.count()) { const on = await sp.getAttribute('aria-pressed'); if (on !== 'true') await sp.click(); }
    await say('scan', 1500);
    const spoken = await S(() => window.__spoken.length);
    const mic = await page.locator('[data-testid=aieng-mic]').count();
    assert(spoken > 0, 'nothing spoken');
    return `${spoken} utterances spoken via mock; mic button ${mic ? 'present' : 'absent'}`;
  });
  await step('Royal AI Cloud: ONLINE with mock provider (gateway reply + credits)', async () => {
    await page.waitForFunction(() => !/CONNECTING/.test(document.querySelector('[data-testid=aieng-cloud-badge]')?.textContent || ''), null, { timeout: 10000 });
    const badge = await page.textContent('[data-testid=aieng-cloud-badge]');
    const cr0 = await page.textContent('.aieng-cloud-credits').catch(() => '');
    const r = await say('what do you think about the groove in the verse?', 3000);
    const cr1 = await page.textContent('.aieng-cloud-credits').catch(() => '');
    assert(/ONLINE/i.test(badge), 'badge ' + badge);
    return `badge "${badge.trim()}", credits ${cr0.trim()} → ${cr1.trim()}, reply "${r.slice(0, 80)}"`;
  });
  await step('Royal AI Cloud: OFFLINE (gateway unreachable) → local engineer keeps working', async () => {
    await page.route('**/v1/**', (r) => r.abort());
    const r = await say('what do you think about the groove in the verse?', 2500);
    const badge = await page.textContent('[data-testid=aieng-cloud-badge]');
    const r2 = await say('scan', 1200);
    await page.unroute('**/v1/**');
    assert(/OFFLINE/i.test(badge), 'badge ' + badge);
    assert(r.length > 10 && !/MOCK CLOUD REPLY/.test(r), 'no local fallback reply: ' + r.slice(0, 80));
    assert(r2.length > 10, 'local scan failed');
    // cold start with the gateway unreachable
    const p2 = await context.newPage();
    await p2.route('**/v1/**', (x) => x.abort());
    await p2.goto(BASE);
    await p2.waitForSelector('button.aieng-topbar-btn');
    await p2.click('button.aieng-topbar-btn');
    await p2.waitForFunction(() => /OFFLINE/.test(document.querySelector('[data-testid=aieng-cloud-badge]')?.textContent || ''), null, { timeout: 10000 });
    const b2 = await p2.textContent('[data-testid=aieng-cloud-badge]');
    await p2.close();
    return `mid-session: badge "${badge.trim()}", local reply "${r.slice(0, 60)}"; cold start: "${b2.trim()}"`;
  }, { allowErrors: [/Failed to load resource/i, /ERR_FAILED/i, /NetworkError/i, /net::/i, /fetch/i] });
}

// ─────────────────────────────── tests: every menu item ───────────────────────────────
async function testMenus() {
  const flagged = [];
  const dead = [];
  await newPage();
  const menus = await page.$$eval('.menu-bar-item', (e) => e.map((x) => x.textContent.trim()));
  let total = 0;
  for (const m of menus) {
    try { await menuOpen(m); } catch (e) { dead.push(`${m} (menu would not open: ${e.message.split('\n')[0].slice(0, 80)})`); await newPage(); continue; }
    const items = await page.$$eval('.menu-dropdown:not(.menu-flyout) > li > .menu-item', (els) =>
      els.map((e) => ({ label: e.querySelector('.menu-item-label').textContent, sub: e.classList.contains('has-submenu'), disabled: e.classList.contains('disabled') })));
    await closeDialogs();
    const leaves = [];
    for (const it of items) {
      if (!it.sub) { leaves.push({ label: it.label, disabled: it.disabled }); continue; }
      await menuOpen(m);
      await page.locator('.menu-dropdown:not(.menu-flyout) > li > .menu-item', { has: page.locator(`.menu-item-label:text-is("${it.label}")`) }).first().hover();
      await page.waitForSelector('.menu-flyout', { timeout: 2000 }).catch(() => {});
      const kids = await page.$$eval('.menu-flyout .menu-item', (els) => els.map((e) => ({ label: e.querySelector('.menu-item-label').textContent, disabled: e.classList.contains('disabled') }))).catch(() => []);
      if (!kids.length) dead.push(`${m} › ${it.label} (empty submenu)`);
      for (const k of kids) leaves.push({ parent: it.label, label: k.label, disabled: k.disabled });
      await closeDialogs();
    }
    for (const lf of leaves) {
      total++;
      const name = `${m} › ${lf.parent ? lf.parent + ' › ' : ''}${lf.label}`;
      if (process.env.QA_VERBOSE) console.log('  menu item:', name);
      if (lf.disabled) { flagged.push(`${name}: disabled`); continue; }
      if (/AI › Open Panel/.test(name) && (await page.$('[data-testid=aieng-panel]'))) await page.click('button.aieng-topbar-btn');
      if (/Track › Duplicate/.test(name)) await S(() => { const s = window.__myconsole.store.getState(); s.selectTrack(s.tracks[0].id, false); });
      const before = await st();
      const beforeDom = await S(() => ({ dlg: !!document.querySelector('.mc-dialog'), ai: !!document.querySelector('[data-testid=aieng-panel]'), html: document.body.innerHTML.length }));
      let chooser = false, download = false;
      const onFc = () => { chooser = true; };
      const onDl = () => { download = true; };
      page.on('filechooser', onFc);
      page.on('download', onDl);
      consoleErrors = [];
      try {
        await menu(m, lf.parent || lf.label, lf.parent ? lf.label : undefined);
      } catch (e) {
        dead.push(`${name} (click failed: ${e.message.split('\n')[0].slice(0, 80)})`);
      }
      await page.waitForTimeout(m === 'AI' ? 1500 : 400); // AI commands may wait on the cloud gateway
      page.off('filechooser', onFc);
      page.off('download', onDl);
      const after = await st();
      const afterDom = await S(() => ({ dlg: !!document.querySelector('.mc-dialog'), dlgText: document.querySelector('.mc-dialog')?.innerText || '', ai: !!document.querySelector('[data-testid=aieng-panel]'), html: document.body.innerHTML.length }));
      const changed = JSON.stringify(before) !== JSON.stringify(after) || afterDom.dlg !== beforeDom.dlg || afterDom.ai !== beforeDom.ai || Math.abs(afterDom.html - beforeDom.html) > 20 || chooser || download;
      const msg = `${after.statusMessage} ${afterDom.dlgText}`;
      const errs = consoleErrors.filter((t) => !BENIGN.some((b) => b.test(t)));
      if (errs.length) dead.push(`${name} (console error: ${errs[0].slice(0, 120)})`);
      if (!changed) dead.push(`${name} (no visible effect)`);
      else if (/not implemented|browser-limited|Landing panel|No hardware peripherals|browser storage only|read-only here/i.test(msg)) flagged.push(`${name}: "${msg.replace(/\s+/g, ' ').trim().slice(0, 80)}"`);
      await closeDialogs();
      if (/New Session|Close Session|Open Session|Quit|Open Recent/.test(name)) await newPage();
    }
  }
  rec(`Menus: all ${total} items clicked across ${menus.length} menus`, dead.length ? 'FAIL' : 'PASS', dead.length ? 'Dead/erroring: ' + dead.join('; ') : 'every item produced a visible effect (dialog, state change, status message, download or file picker) with no console errors');
  rec(`Menus: items that only show a "not implemented / browser-limited" message (${flagged.length})`, flagged.length ? 'LIMITED' : 'PASS', flagged.join('; '));
}

// ─────────────────────────────── tests: responsive ───────────────────────────────
async function testResponsive() {
  for (const [w, h] of [[1280, 800], [1440, 900], [1920, 1080], [2560, 1440]]) {
    await step(`Responsive layout ${w}×${h}`, async () => {
      await newPage({ width: w, height: h });
      const issues = [];
      for (const mode of ['console', 'edit', 'mix']) {
        await view(mode);
        const r = await S(() => {
          const de = document.documentElement;
          const menu = [...document.querySelectorAll('.menu-bar-item')].pop().getBoundingClientRect();
          const btn = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'PLAY');
          const trb = btn ? btn.getBoundingClientRect() : null;
          return { hOverflow: de.scrollWidth - innerWidth, vOverflow: de.scrollHeight - innerHeight, menuRight: menu.right, playBottom: trb ? trb.bottom : null };
        });
        if (r.hOverflow > 1) issues.push(`${mode}: page scrolls horizontally by ${r.hOverflow}px`);
        if (r.vOverflow > 1) issues.push(`${mode}: page scrolls vertically by ${r.vOverflow}px`);
        if (r.menuRight > w) issues.push(`${mode}: menu bar clipped`);
        if (r.playBottom == null || r.playBottom > h + 1) issues.push(`${mode}: transport not visible`);
        await page.screenshot({ path: path.join(SHOTS, `${BROWSER}-${w}x${h}-${mode}.png`) });
      }
      await menu('Setup', 'I/O…');
      const bb = await page.locator('.mc-dialog').boundingBox();
      if (bb.y < 0 || bb.y + bb.height > h + 1 || bb.x + bb.width > w) issues.push('I/O dialog does not fit');
      await closeDialogs();
      if (issues.length) return { status: 'FAIL', notes: issues.join('; ') };
      return 'console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits';
    });
  }
}

(async () => {
  const only = (process.env.QA_ONLY || '').split(',').filter(Boolean);
  const run = async (name, fn) => { if (only.length && !only.includes(name)) return; try { await fn(); } catch (e) { rec(`${name} (suite crashed)`, 'FAIL', e.message.split('\n')[0]); } };
  try {
    await launch();
  } catch (e) {
    rec('Browser launch', 'LIMITED', e.message.split('\n')[0]);
    fs.writeFileSync(path.join(OUT, `results-${BROWSER}.json`), JSON.stringify(results, null, 2));
    process.exit(0);
  }
  await run('load', testLoad);
  await run('transport', testTransport);
  await run('devices', testDevicesAndRecord);
  await run('loopback', testLoopbackAndHotplug);
  await run('permission', testPermissionDenied);
  await run('edit', testEdit);
  await run('mix', testMix);
  await run('session', testSessionAndBounce);
  await run('persist', testPersistence);
  await run('monitor', testMonitoring);
  await run('ai', testAI);
  await run('menus', testMenus);
  await run('responsive', testResponsive);
  await browser.close();
  if (gotoRetries.length) rec('Harness note: page navigation retried', 'INFO', `${gotoRetries.length} navigation(s) needed a retry (${gotoRetries[0]}) — browser/harness flake, app loaded on retry`);
  const file = path.join(OUT, `results-${BROWSER}${only.length ? '-' + only.join('_') : ''}.json`);
  fs.writeFileSync(file, JSON.stringify(results, null, 2));
  const c = (s) => results.filter((r) => r.status === s).length;
  console.log(`\n${BROWSER}: PASS ${c('PASS')} · FAIL ${c('FAIL')} · LIMITED ${c('LIMITED')}`);
})();
