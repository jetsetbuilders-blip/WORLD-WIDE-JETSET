# MY CONSOLE — QA REPORT (ROYAL-CONSOLE-DEPLOY-2, v3.21.0-deploy-2)

Generated 2026-09-26 21:41 ET on the build box (Linux, headless).

**Method.** An automated Playwright suite (`qa/qa-suite.cjs`) drives the real built app, served by the Royal AI Cloud gateway
(`server.py serve`, with a mock OpenAI-compatible provider). It clicks the real UI and checks the store, the audio engine and measured audio.
Console errors are collected on every step; any error fails that step.
- **Chromium:** Google Chrome, `--use-fake-device-for-media-stream --use-fake-ui-for-media-stream`.
- **Firefox:** Playwright Firefox, fake media stream prefs.
- **WebKit:** Playwright WebKit (the Safari engine on Linux). It has no fake capture device.
- Audio output: a PulseAudio null sink (no speakers on the box).

**Status meanings:**
- **PASS:** verified.
- **FAIL:** broken.
- **LIMITED:** can't be done or verified in that browser/headless environment. This is a documented limitation, *not* a pass.
- **INFO:** a harness note.

## Summary

| Browser | PASS | FAIL | LIMITED |
|---|---|---|---|
| chromium | 75 | 0 | 1 |
| firefox | 72 | 0 | 4 |
| webkit | 60 | 0 | 16 |

## Feature matrix

| Feature | Chromium | Firefox | Webkit |
|---|---|---|---|
| App load (served via Royal AI Cloud gateway) | PASS | PASS | PASS |
| App load (single-file OPEN-MY-CONSOLE.html, file://) | PASS | PASS | PASS |
| Transport: Play / Stop (UI buttons) | PASS | PASS | PASS |
| Transport: RTZ / FF / RW | PASS | PASS | PASS |
| Transport: Loop toggle | PASS | PASS | PASS |
| Transport: Metronome (CLK) + Count-in (CI) | PASS | PASS | PASS |
| Transport: BPM field + timebase | PASS | PASS | PASS |
| Transport: keyboard (Space play/stop, M metronome) | PASS | PASS | PASS |
| Setup › Playback Engine dialog (menu, devices, readout) | PASS | PASS | PASS |
| Playback Engine: sample rates 44.1/48/88.2/96 recreate AudioContext | PASS | LIMITED | PASS |
| Playback Engine: latency hint interactive/balanced/playback/custom + baseLatency/outputLatency | PASS | PASS | PASS |
| Playback Engine: output device selection (setSinkId) persisted by label | PASS | LIMITED | LIMITED |
| Setup › I/O: enable input (getUserMedia, DSP off), channels, device list | PASS | PASS | LIMITED |
| I/O: per-track input selection (mono N / stereo pairs) persisted | PASS | PASS | PASS |
| I/O: round-trip test without a loopback reports "no loopback" honestly | PASS | PASS | LIMITED |
| Record: armed track + REC captures REAL audio from input into a clip (latency-compensated) | PASS | PASS | LIMITED |
| Record: recorded clip waveform uses real peaks (Edit window) | PASS | PASS | LIMITED |
| I/O: loopback round-trip measurement (simulated 12 ms loopback) + manual offset, persisted per device | PASS | PASS | — |
| Hot-plug: devicechange → chosen output/input vanish → fallback to default, UI + Session Guardian notice | PASS | PASS | — |
| Permissions: mic denied → clear error; mic not requested until input is enabled | PASS | — | — |
| Edit tools: Smart/Selector/Grabber/Trim/Scrub/Pencil buttons | PASS | PASS | PASS |
| Edit modes: Shuffle / Slip / Spot / Grid (Options menu) | PASS | PASS | PASS |
| Edit: split at playhead (B) | PASS | PASS | PASS |
| Edit: cut clip / selection | PASS | PASS | PASS |
| Edit: trim to selection / playhead | PASS | PASS | PASS |
| Edit: elastic on/off (E) | PASS | PASS | PASS |
| Edit: nudge selected clip forward/back | PASS | PASS | PASS |
| Edit: grid size select | PASS | PASS | PASS |
| Edit: slip free move vs grid snap; spot action | PASS | PASS | PASS |
| Edit: zoom in/out + track height +/- | PASS | PASS | PASS |
| Edit: track colors + groups (dialog, linked faders) | PASS | PASS | PASS |
| Piano roll / MIDI: click grid adds note, click note removes it | PASS | PASS | PASS |
| Mix: fader drag → dB readout → engine gain = 10^(dB/20) (true dB) | PASS | PASS | PASS |
| Mix: fader dB accuracy measured on the signal (0 / −6 / −12 / −20 dB) | PASS | PASS | PASS |
| Mix: pan knob drag + engine StereoPanner | PASS | PASS | PASS |
| Mix: mute / solo buttons + engine gates | PASS | PASS | PASS |
| Mix: sends → bus / new aux (level + engine send gain) | PASS | PASS | PASS |
| Mix: inserts — add plugin, bypass on/off by clicking the slot, engine follows | PASS | PASS | PASS |
| Mix: meters respond while playing | PASS | PASS | PASS |
| Mix: horizontal / vertical scroll of the mix window | PASS | PASS | PASS |
| Automation: write fader moves while playing, read back replays them | PASS | PASS | PASS |
| Bounce: File › Bounce Mix produces a valid, non-silent WAV | PASS | PASS | PASS |
| Headroom modes Standard/Studio/Mastering (transport select → engine) | PASS | PASS | PASS |
| Console tab: hardware desk renders a strip per track | PASS | PASS | PASS |
| Persist: recorded take stored in IndexedDB (sessionId/takeId, PCM + sample rate/channels + peaks) | PASS | PASS | LIMITED |
| Import › Audio… decodes a WAV exactly, places a clip and persists it (sample-exact hash) | PASS | PASS | PASS |
| Edit: split an audio clip → right half plays from the matching offset in the take; Undo restores | PASS | PASS | PASS |
| Persist: reload → autosaved session restores clips, same audio hash, real peaks, plays | PASS | PASS | PASS |
| Package: Save Session As → .mycsession zip (session.json + Audio Files/*.wav, sha-256 per file) | PASS | PASS | PASS |
| Package: File › Open in a FRESH browser profile restores audio into IndexedDB (same hashes) | PASS | PASS | PASS |
| Session: legacy .mycsession.json (Save Session ⌘S) still opens (roundtrip) | PASS | PASS | PASS |
| Undo of a clip delete keeps its audio; Clean Up removes only orphaned audio | PASS | PASS | PASS |
| Storage: quota error on save → take marked unsaved + clear warning + Session Guardian | PASS | PASS | PASS |
| Storage: low free space (navigator.storage.estimate) → Session Guardian warning | PASS | PASS | PASS |
| Session Guardian: recorded take not yet exported → notice | PASS | PASS | LIMITED |
| Monitor: TrackInput (I) button → live input through the channel strip to master meters (transport stopped) | PASS | PASS | LIMITED |
| Monitor: input follows the channel strip (mute → input gone from master, fader −20 dB → quieter, unmute → back) | PASS | PASS | LIMITED |
| Monitor: Auto Input (armed: input when stopped, track on playback) / Input Only (input always) — Options menu | PASS | PASS | LIMITED |
| Monitor: no double record — take level with monitoring ON ≈ monitoring OFF (monitored output never re-captured) | PASS | PASS | LIMITED |
| Feedback safety: built-in mic + built-in speakers → auto monitoring off, warning + Session Guardian; override checkbox | PASS | PASS | LIMITED |
| Playback Engine: monitoring latency (input + base + output) reported | PASS | PASS | PASS |
| AI Engineer: greeting + scan report | PASS | PASS | PASS |
| AI Engineer: measure (real analyser, ~4 s) | PASS | PASS | PASS |
| AI Engineer: fix session + snapshot restore | PASS | PASS | PASS |
| AI Engineer: ideas → audition A/B → keep / reject | PASS | PASS | PASS |
| AI Engineer: surprise / challenge / mastering check (AI menu) | PASS | PASS | PASS |
| AI Engineer: chat intents + producer profile | PASS | PASS | PASS |
| AI Engineer: voice (TTS via speechSynthesis mock) | PASS | PASS | PASS |
| Royal AI Cloud: ONLINE with mock provider (gateway reply + credits) | PASS | PASS | PASS |
| Royal AI Cloud: OFFLINE (gateway unreachable) → local engineer keeps working | PASS | PASS | PASS |
| Menus: all 144 items clicked across 13 menus | PASS | PASS | PASS |
| Menus: items that only show a "not implemented / browser-limited" message (44) | LIMITED | LIMITED | LIMITED |
| Responsive layout 1280×800 | PASS | PASS | PASS |
| Responsive layout 1440×900 | PASS | PASS | PASS |
| Responsive layout 1920×1080 | PASS | PASS | PASS |
| Responsive layout 2560×1440 | PASS | PASS | PASS |
| Permissions: mic denied → clear error | — | LIMITED | LIMITED |
| Harness note: page navigation retried | — | INFO | — |
| I/O: loopback round-trip measurement (simulated 12 ms loopback) | — | — | LIMITED |
| Hot-plug: devicechange → fallback to default + UI + Session Guardian notice | — | — | LIMITED |

## Details per browser (notes = what was actually measured / observed)

### Chromium

| Feature | Status | Notes |
|---|---|---|
| App load (served via Royal AI Cloud gateway) | PASS | banner "BUILD DEPLOY-2" |
| App load (single-file OPEN-MY-CONSOLE.html, file://) | PASS | banner "BUILD DEPLOY-2", file:// input notice shown |
| Transport: Play / Stop (UI buttons) | PASS | playhead advanced to bar 2.74 in 1.2 s at 120 BPM; engine ran |
| Transport: RTZ / FF / RW | PASS | FF 6.758249999999997→10.758249999999997, RW →6.758249999999997, RTZ →1 |
| Transport: Loop toggle | PASS | loop false→true |
| Transport: Metronome (CLK) + Count-in (CI) | PASS | count-in 1 bar at 120 BPM then roll; metronome on |
| Transport: BPM field + timebase | PASS | tempo 97 set; timebase readouts MinutesSeconds:00:00.644 \| Samples:30915 \| Timecode:00:00:00:19 \| BarsBeats:001.2.039 |
| Transport: keyboard (Space play/stop, M metronome) | PASS | ok |
| Setup › Playback Engine dialog (menu, devices, readout) | PASS | outputs: Fake Default Audio Output, Fake Audio Output 1, Fake Audio Output 2 · setSinkId supported |
| Playback Engine: sample rates 44.1/48/88.2/96 recreate AudioContext | PASS | 44100→44100, 48000→48000, 88200→88200, 96000→96000 |
| Playback Engine: latency hint interactive/balanced/playback/custom + baseLatency/outputLatency | PASS | interactive: base 11.6 ms / out 40.0 ms \| balanced: base 10.0 ms / out 40.0 ms \| playback: base 23.2 ms / out 72.0 ms \| custom: base 52.2 ms / out 0.0 ms |
| Playback Engine: output device selection (setSinkId) persisted by label | PASS | output → "Fake Audio Output 1", ctx.sinkId matches, persisted by label |
| Setup › I/O: enable input (getUserMedia, DSP off), channels, device list | PASS | input "Fake Default Audio Input", 2 ch detected; inputs: Fake Default Audio Input, Fake Audio Input 1, Fake Audio Input 2 |
| I/O: per-track input selection (mono N / stereo pairs) persisted | PASS | options mono:0,mono:1,stereo:0; track tr-01 → stereo:0 |
| I/O: round-trip test without a loopback reports "no loopback" honestly | PASS | No loopback signal detected — connect an output to an input (cable) and turn the input gain up. |
| Record: armed track + REC captures REAL audio from input into a clip (latency-compensated) | PASS | clip @bar 3 len 1.27 bars · 2.54 s, 2 ch (stereo pair selected), peak 0.0 dBFS, rms 0.140 · latency comp 56.6 ms (reported input + output latency) · take scheduled into the channel on playback |
| Record: recorded clip waveform uses real peaks (Edit window) | PASS | real peaks (computed from recorded PCM, cached) passed to WaveformClip |
| I/O: loopback round-trip measurement (simulated 12 ms loopback) + manual offset, persisted per device | PASS | Round-trip 12 ms (3 impulses agree within 0.00 ms). Saved for Fake Default Audio Input → System default. · manual +3.5 ms → applied 15.5 ms |
| Hot-plug: devicechange → chosen output/input vanish → fallback to default, UI + Session Guardian notice | PASS | simulated unplug (patched enumerateDevices + devicechange): out "Fake Audio Output 1"→"System default", in "Fake Audio Input 1"→"Fake Default Audio Input"; replug → out "Fake Audio Output 1", in "Fake Audio Input 1" (reconnect,reconnect,fallback); Guardian: "Audio device: Output "Fake Audio Output 1" disconnected — fell back to the system default output." |
| Permissions: mic denied → clear error; mic not requested until input is enabled | PASS | input open at load: false; error: "Microphone permission denied. Click the lock icon in the address bar, allow Microphone for this site, then press Enable input again." |
| Edit tools: Smart/Selector/Grabber/Trim/Scrub/Pencil buttons | PASS | Selector:selector, Grabber:grabber, Trim:trim, Scrub:scrub, Pencil:pencil, Smart:smart |
| Edit modes: Shuffle / Slip / Spot / Grid (Options menu) | PASS | Shuffle → Slip → Spot → Grid |
| Edit: split at playhead (B) | PASS | clips 3→4 |
| Edit: cut clip / selection | PASS | clips 4→3 |
| Edit: trim to selection / playhead | PASS | len 4.00→3.00 |
| Edit: elastic on/off (E) | PASS | elastic toggled on clip |
| Edit: nudge selected clip forward/back | PASS | start 5→5.25→5 |
| Edit: grid size select | PASS | options 0.25,0.5,1,2,4; grid → 4 → 0.25 |
| Edit: slip free move vs grid snap; spot action | PASS | slip move → 6.37, grid move → 6.38; spot action present true |
| Edit: zoom in/out + track height +/- | PASS | zoom 48→60; track height "TracksSmallerLarger72px" → "TracksSmallerLarger80px" |
| Edit: track colors + groups (dialog, linked faders) | PASS | group of 2, linked fader followed, color set |
| Piano roll / MIDI: click grid adds note, click note removes it | PASS | notes 2→3→2 |
| Mix: fader drag → dB readout → engine gain = 10^(dB/20) (true dB) | PASS | drag → -21.50 dB (readout "-21.5"), engine fader gain 0.04628 = 10^(dB/20) × source trim 0.55 (error 0.000 dB) |
| Mix: fader dB accuracy measured on the signal (0 / −6 / −12 / −20 dB) | PASS | 0 dB → gain 0.00 / signal 0.00 dB; -6 dB → gain -6.00 / signal -6.00 dB; -12 dB → gain -12.00 / signal -12.00 dB; -20 dB → gain -20.00 / signal -20.00 dB (max signal error 0.00 dB; preview sources are noise-based) |
| Mix: pan knob drag + engine StereoPanner | PASS | pan 0.66 (engine 0.66) |
| Mix: mute / solo buttons + engine gates | PASS | mute gate 1.7e-4 (≤ −60 dB); solo → soloed 1.000 / others 3.0e-4 |
| Mix: sends → bus / new aux (level + engine send gain) | PASS | send A → bus:reverb at −6 dB (engine 0.501); send B → new aux (+1 track) |
| Mix: inserts — add plugin, bypass on/off by clicking the slot, engine follows | PASS | insert E added (engine insert blocks 3); click → bypass (UI + state), click → active |
| Mix: meters respond while playing | PASS | 18 strip meters moving, 18 engine analysers > −60 dBFS |
| Mix: horizontal / vertical scroll of the mix window | PASS | horizontal .pro-mix-strips → 300px; vertical .pro-mix-strips → 100px |
| Automation: write fader moves while playing, read back replays them | PASS | 4 points written; read replayed -3.0, -9.0, -15.0, -21.0 dB |
| Bounce: File › Bounce Mix produces a valid, non-silent WAV | PASS | MY-CONSOLE-bounce.wav · 2 ch · 48000 Hz · 16-bit · 2.00 s · RMS -8.2 dBFS · peak -1.0 dBFS |
| Headroom modes Standard/Studio/Mastering (transport select → engine) | PASS | standard:12, studio:18, mastering:24, extreme:32 dB |
| Console tab: hardware desk renders a strip per track | PASS | 16 strips for 18 tracks |
| Persist: recorded take stored in IndexedDB (sessionId/takeId, PCM + sample rate/channels + peaks) | PASS | take take-muj4xb20-gx7zaz · 2.49 s · 44100 Hz · 1 ch · IDB key sess-muj4x82d-z4mxym/take-muj4xb20-gx7zaz · sha256 f6d37b803b79… |
| Import › Audio… decodes a WAV exactly, places a clip and persists it (sample-exact hash) | PASS | Import Audio · 1 file decoded and saved (48000 Hz, 1 ch) · decoded PCM sha256 matches the source file's samples (6b3c13fccf22…) |
| Edit: split an audio clip → right half plays from the matching offset in the take; Undo restores | PASS | offsets 0.000 / 0.501 s (expected 0.500) · Edit › Undo → original clip back |
| Persist: reload → autosaved session restores clips, same audio hash, real peaks, plays | PASS | recorded take-muj4xb20-gx7zaz: hash equal, peaks, scheduled · imported take-muj4xbw8-6mj7oy: hash equal, peaks, scheduled · "Restored autosaved session · Untitled Session · 2/2 audio file(s) from browser storage" |
| Package: Save Session As → .mycsession zip (session.json + Audio Files/*.wav, sha-256 per file) | PASS | QA Package.mycsession · 686 KB · session.json + 2 WAV (Rec 9_23_29 PM_take-muj4xb20-gx7zaz.wav, qa-chromium-import_take-muj4xbw8-6mj7oy.wav) |
| Package: File › Open in a FRESH browser profile restores audio into IndexedDB (same hashes) | PASS | IDB keys 0 → 2 · 2 take(s) hash-identical · "Opened package · QA Package · 2 audio file(s) restored (2 verified)" |
| Session: legacy .mycsession.json (Save Session ⌘S) still opens (roundtrip) | PASS | QA Package.mycsession.json · tempo 90→133 restored, tracks 18 · "Opened session · QA Package · 2/2 audio file(s) found in this browser" |
| Undo of a clip delete keeps its audio; Clean Up removes only orphaned audio | PASS | delete → audio still in IDB · Edit › Undo → clip back, hash identical ("Undo Cut / Delete") · delete + Clean Up → "Clean Up · removed 1 unused audio file(s) · kept 1" · referenced recorded take kept |
| Storage: quota error on save → take marked unsaved + clear warning + Session Guardian | PASS | QuotaExceededError (simulated by stubbing IDBObjectStore.put) → take persist=failed, unsaved takes 1; warning: "Browser storage is full — take "qa-chromium-import" is NOT saved to this browser. Export n…"; Guardian: "Storage: Browser storage is full — take "qa-chromium-import" is NOT sa…" |
| Storage: low free space (navigator.storage.estimate) → Session Guardian warning | PASS | Guardian: "Storage: Browser storage is low: 50 MB free of 1000 MB. New takes may fail to save — export (Save Session As…)" · navigator.storage.persist is requested on first save |
| Session Guardian: recorded take not yet exported → notice | PASS | Guardian: "Takes: Take "Rec 9:23:29 PM" is saved in this browser and restores on reload. It is not portable yet — File › Save Sessi" |
| Monitor: TrackInput (I) button → live input through the channel strip to master meters (transport stopped) | PASS | I lit green in mixer + edit track header · monitored tr-01 · monitor-only graph running · track meter peak 0.572, master 0.917 with transport stopped |
| Monitor: input follows the channel strip (mute → input gone from master, fader −20 dB → quieter, unmute → back) | PASS | muted: track 0.0e+0, master 0.022 (= other channels' emulated plugin noise floor) · unmuted 0.917 · fader −20 dB → master 0.376 (meter scale is display-scaled; kick feeds the compressed Drum Bus) |
| Monitor: Auto Input (armed: input when stopped, track on playback) / Input Only (input always) — Options menu | PASS | auto: armed+stopped → input (track meter 0.572), playing → track playback; input-only: playing → input; menu toggles mode |
| Monitor: no double record — take level with monitoring ON ≈ monitoring OFF (monitored output never re-captured) | PASS | monitoring ON: peak 0.00 dBFS rms 0.1462 · OFF: peak 0.00 dBFS rms 0.1433 · Δpeak 0.00 dB · RMS ratio 1.02 (a re-captured monitor signal would add ≈ +6 dB / ratio ≈ 2) |
| Feedback safety: built-in mic + built-in speakers → auto monitoring off, warning + Session Guardian; override checkbox | PASS | MacBook Pro Microphone → MacBook Pro Speakers: RISK; MacBook Pro Microphone → External Headphones: ok; Scarlett 2i2 USB → MacBook Pro Speakers: ok; Microphone Array (Realtek(R) Audio) → Speakers (Realtek(R) Audio): RISK · armed track NOT monitored under risk · I/O: "Feedback risk: built-in microphone with built-in speakers. Auto input monitoring" · override → monitored · Guardian: "Monitoring: Feedback risk: built-in microphone ("MacBook Pro Microphone") with built-in sp" |
| Playback Engine: monitoring latency (input + base + output) reported | PASS | "56.6 ms (input 10.0 ms + base 11.6 ms + output 35.0 ms)" · storage row: "0.0 MB used of 3072 MB · may be evicted (export packages)" |
| AI Engineer: greeting + scan report | PASS | greeting + scan report rendered |
| AI Engineer: measure (real analyser, ~4 s) | PASS | Measured 4.0 s of the master. Scan done. 4 items to review: • Master Headroom: Problem — Output peak 10.4 dBFS (master tap -1.6 + 12 dB monitor make-up), 124270 |
| AI Engineer: fix session + snapshot restore | PASS | 2 snapshot(s); restore clicked |
| AI Engineer: ideas → audition A/B → keep / reject | PASS | 19 ideas; audition A/B, keep and reject worked |
| AI Engineer: surprise / challenge / mastering check (AI menu) | PASS | 16 new messages |
| AI Engineer: chat intents + producer profile | PASS | replies: Here's what I can do: • "scan" — session health + mix report \| MOCK CLOUD REPLY to: make the vocals brighter — Royal AI · \| Restored and verified "Before audition: Pull Vocals Lead rev \| MOCK CLOUD REPLY to: how loud is my mix? — Royal AI · GENER · profile pane 739 chars |
| AI Engineer: voice (TTS via speechSynthesis mock) | PASS | 19 utterances spoken via mock; mic button present |
| Royal AI Cloud: ONLINE with mock provider (gateway reply + credits) | PASS | badge "SUPER INTELLIGENCE ONLINE", credits ◆ 4,998 → ◆ 4,997, reply "MOCK CLOUD REPLY to: what do you think about the groove in the verse? — Royal A" |
| Royal AI Cloud: OFFLINE (gateway unreachable) → local engineer keeps working | PASS | mid-session: badge "OFFLINE SESSION GUARDIAN", local reply "I didn't catch that as a command. Here's what I can do: • "s"; cold start: "OFFLINE SESSION GUARDIAN" |
| Menus: all 144 items clicked across 13 menus | PASS | every item produced a visible effect (dialog, state change, status message, download or file picker) with no console errors |
| Menus: items that only show a "not implemented / browser-limited" message (44) | LIMITED | File › Open Recent › (no recent sessions): disabled; File › Import › Session Data…: "Import Session Data — not implemented yet"; File › Import › Video…: "Import Video — not implemented yet"; Edit › Shift: "Shift — not implemented yet"; Edit › Heal Separation: "Heal Separation — not implemented yet"; Edit › Selection › Change Tempo of Selection…: "Heal Separation — not implemented yet TEMPO BPM CANCEL SET TEMPO ×"; Edit › Fades…: "Fades — not implemented yet"; View › Edit Window: "Fades — not implemented yet"; View › Mix Window: "Fades — not implemented yet"; View › Console: "Fades — not implem |
| Responsive layout 1280×800 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 1440×900 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 1920×1080 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 2560×1440 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |

### Firefox

| Feature | Status | Notes |
|---|---|---|
| App load (served via Royal AI Cloud gateway) | PASS | banner "BUILD DEPLOY-2" |
| App load (single-file OPEN-MY-CONSOLE.html, file://) | PASS | banner "BUILD DEPLOY-2", file:// input notice shown |
| Transport: Play / Stop (UI buttons) | PASS | playhead advanced to bar 2.75 in 1.2 s at 120 BPM; engine ran |
| Transport: RTZ / FF / RW | PASS | FF 6.8002199999999995→10.80022, RW →6.8002199999999995, RTZ →1 |
| Transport: Loop toggle | PASS | loop false→true |
| Transport: Metronome (CLK) + Count-in (CI) | PASS | count-in 1 bar at 120 BPM then roll; metronome on |
| Transport: BPM field + timebase | PASS | tempo 97 set; timebase readouts MinutesSeconds:00:00.727 \| Samples:34873 \| Timecode:00:00:00:21 \| BarsBeats:001.2.167 |
| Transport: keyboard (Space play/stop, M metronome) | PASS | ok |
| Setup › Playback Engine dialog (menu, devices, readout) | PASS | outputs: System default · setSinkId NOT supported → system-default note shown |
| Playback Engine: sample rates 44.1/48/88.2/96 recreate AudioContext | LIMITED | browser honoured 2/4: 44100→44100, 48000→48000, 88200→0, 96000→0 |
| Playback Engine: latency hint interactive/balanced/playback/custom + baseLatency/outputLatency | PASS | interactive: base 0.0 ms / out 0.0 ms \| balanced: base 0.0 ms / out 0.0 ms \| playback: base 0.0 ms / out 0.0 ms \| custom: base 0.0 ms / out 0.0 ms |
| Playback Engine: output device selection (setSinkId) persisted by label | LIMITED | AudioContext.setSinkId not available in this browser → system default output; dialog tells the user to pick the interface in macOS/Windows Sound settings |
| Setup › I/O: enable input (getUserMedia, DSP off), channels, device list | PASS | input "Default Audio Device", 1 ch detected; inputs: Default Audio Device |
| I/O: per-track input selection (mono N / stereo pairs) persisted | PASS | options mono:0; track tr-01 → mono:0 |
| I/O: round-trip test without a loopback reports "no loopback" honestly | PASS | No loopback signal detected — connect an output to an input (cable) and turn the input gain up. |
| Record: armed track + REC captures REAL audio from input into a clip (latency-compensated) | PASS | clip @bar 3 len 1.26 bars · 2.53 s, 1 ch (stereo pair selected), peak -20.0 dBFS, rms 0.071 · latency comp 48.2 ms (reported input + output latency) · take scheduled into the channel on playback |
| Record: recorded clip waveform uses real peaks (Edit window) | PASS | real peaks (computed from recorded PCM, cached) passed to WaveformClip |
| I/O: loopback round-trip measurement (simulated 12 ms loopback) + manual offset, persisted per device | PASS | Round-trip 12 ms (3 impulses agree within 0.00 ms). Saved for Default Audio Device → System default. · manual +3.5 ms → applied 15.5 ms |
| Hot-plug: devicechange → chosen output/input vanish → fallback to default, UI + Session Guardian notice | PASS | simulated unplug (patched enumerateDevices + devicechange): out "System default"→"System default", in "Default Audio Device"→"Default Audio Device"; replug → out "System default", in "Default Audio Device" (fallback); Guardian: "Audio device: Input "Default Audio Device" disconnected — falling back to the system default input." |
| Permissions: mic denied → clear error | LIMITED | denial is simulated in the Chromium run only |
| Edit tools: Smart/Selector/Grabber/Trim/Scrub/Pencil buttons | PASS | Selector:selector, Grabber:grabber, Trim:trim, Scrub:scrub, Pencil:pencil, Smart:smart |
| Edit modes: Shuffle / Slip / Spot / Grid (Options menu) | PASS | Shuffle → Slip → Spot → Grid |
| Edit: split at playhead (B) | PASS | clips 3→4 |
| Edit: cut clip / selection | PASS | clips 4→3 |
| Edit: trim to selection / playhead | PASS | len 4.00→3.00 |
| Edit: elastic on/off (E) | PASS | elastic toggled on clip |
| Edit: nudge selected clip forward/back | PASS | start 5→5.25→5 |
| Edit: grid size select | PASS | options 0.25,0.5,1,2,4; grid → 4 → 0.25 |
| Edit: slip free move vs grid snap; spot action | PASS | slip move → 6.37, grid move → 6.38; spot action present true |
| Edit: zoom in/out + track height +/- | PASS | zoom 48→60; track height "TracksSmallerLarger72px" → "TracksSmallerLarger80px" |
| Edit: track colors + groups (dialog, linked faders) | PASS | group of 2, linked fader followed, color set |
| Piano roll / MIDI: click grid adds note, click note removes it | PASS | notes 2→3→2 |
| Mix: fader drag → dB readout → engine gain = 10^(dB/20) (true dB) | PASS | drag → -21.50 dB (readout "-21.5"), engine fader gain 0.04628 = 10^(dB/20) × source trim 0.55 (error 0.000 dB) |
| Mix: fader dB accuracy measured on the signal (0 / −6 / −12 / −20 dB) | PASS | 0 dB → gain 0.00 / signal 0.00 dB; -6 dB → gain -6.00 / signal -6.00 dB; -12 dB → gain -12.00 / signal -12.00 dB; -20 dB → gain -20.00 / signal -20.01 dB (max signal error 0.01 dB; preview sources are noise-based) |
| Mix: pan knob drag + engine StereoPanner | PASS | pan 0.66 (engine 0.66) |
| Mix: mute / solo buttons + engine gates | PASS | mute gate 5.3e-4 (≤ −60 dB); solo → soloed 1.000 / others 5.3e-4 |
| Mix: sends → bus / new aux (level + engine send gain) | PASS | send A → bus:reverb at −6 dB (engine 0.501); send B → new aux (+1 track) |
| Mix: inserts — add plugin, bypass on/off by clicking the slot, engine follows | PASS | insert E added (engine insert blocks 3); click → bypass (UI + state), click → active |
| Mix: meters respond while playing | PASS | 18 strip meters moving, 18 engine analysers > −60 dBFS |
| Mix: horizontal / vertical scroll of the mix window | PASS | horizontal .pro-mix-strips → 300px; vertical .pro-mix-strips → 100px |
| Automation: write fader moves while playing, read back replays them | PASS | 4 points written; read replayed -3.0, -9.0, -15.0, -21.0 dB |
| Bounce: File › Bounce Mix produces a valid, non-silent WAV | PASS | MY-CONSOLE-bounce.wav · 2 ch · 48000 Hz · 16-bit · 2.00 s · RMS -9.6 dBFS · peak -2.6 dBFS |
| Headroom modes Standard/Studio/Mastering (transport select → engine) | PASS | standard:12, studio:18, mastering:24, extreme:32 dB |
| Console tab: hardware desk renders a strip per track | PASS | 16 strips for 18 tracks |
| Persist: recorded take stored in IndexedDB (sessionId/takeId, PCM + sample rate/channels + peaks) | PASS | take take-muj3o4h3-4klpzc · 2.57 s · 44100 Hz · 1 ch · IDB key sess-muj3o1ee-gchs2z/take-muj3o4h3-4klpzc · sha256 dd954c8fff9e… |
| Import › Audio… decodes a WAV exactly, places a clip and persists it (sample-exact hash) | PASS | Import Audio · 1 file decoded and saved (48000 Hz, 1 ch) · decoded PCM sha256 matches the source file's samples (6b3c13fccf22…) |
| Edit: split an audio clip → right half plays from the matching offset in the take; Undo restores | PASS | offsets 0.000 / 0.501 s (expected 0.500) · Edit › Undo → original clip back |
| Persist: reload → autosaved session restores clips, same audio hash, real peaks, plays | PASS | recorded take-muj3o4h3-4klpzc: hash equal, peaks, scheduled · imported take-muj3o5gd-w7aks3: hash equal, peaks, scheduled · "Restored autosaved session · Untitled Session · 2/2 audio file(s) from browser storage" |
| Package: Save Session As → .mycsession zip (session.json + Audio Files/*.wav, sha-256 per file) | PASS | QA Package.mycsession · 699 KB · session.json + 2 WAV (Rec 8_48_21 PM_take-muj3o4h3-4klpzc.wav, qa-firefox-import_take-muj3o5gd-w7aks3.wav) |
| Package: File › Open in a FRESH browser profile restores audio into IndexedDB (same hashes) | PASS | IDB keys 0 → 2 · 2 take(s) hash-identical · "Opened package · QA Package · 2 audio file(s) restored (2 verified)" |
| Session: legacy .mycsession.json (Save Session ⌘S) still opens (roundtrip) | PASS | QA Package.mycsession.json · tempo 90→133 restored, tracks 18 · "Opened session · QA Package · 2/2 audio file(s) found in this browser" |
| Undo of a clip delete keeps its audio; Clean Up removes only orphaned audio | PASS | delete → audio still in IDB · Edit › Undo → clip back, hash identical ("Undo Cut / Delete") · delete + Clean Up → "Clean Up · removed 1 unused audio file(s) · kept 1" · referenced recorded take kept |
| Storage: quota error on save → take marked unsaved + clear warning + Session Guardian | PASS | QuotaExceededError (simulated by stubbing IDBObjectStore.put) → take persist=failed, unsaved takes 1; warning: "Browser storage is full — take "qa-firefox-import" is NOT saved to this browser. Export no…"; Guardian: "Storage: Browser storage is full — take "qa-firefox-import" is NOT sav…" |
| Storage: low free space (navigator.storage.estimate) → Session Guardian warning | PASS | Guardian: "Storage: Browser storage is low: 50 MB free of 1000 MB. New takes may fail to save — export (Save Session As…)" · navigator.storage.persist is requested on first save |
| Session Guardian: recorded take not yet exported → notice | PASS | Guardian: "Takes: Take "Rec 8:48:21 PM" is saved in this browser and restores on reload. It is not portable yet — File › Save Sessi" |
| Monitor: TrackInput (I) button → live input through the channel strip to master meters (transport stopped) | PASS | I lit green in mixer + edit track header · monitored tr-01 · monitor-only graph running · track meter peak 0.246, master 0.707 with transport stopped |
| Monitor: input follows the channel strip (mute → input gone from master, fader −20 dB → quieter, unmute → back) | PASS | muted: track 0.0e+0, master 0.003 (= other channels' emulated plugin noise floor) · unmuted 0.707 · fader −20 dB → master 0.134 (meter scale is display-scaled; kick feeds the compressed Drum Bus) |
| Monitor: Auto Input (armed: input when stopped, track on playback) / Input Only (input always) — Options menu | PASS | auto: armed+stopped → input (track meter 0.246), playing → track playback; input-only: playing → input; menu toggles mode |
| Monitor: no double record — take level with monitoring ON ≈ monitoring OFF (monitored output never re-captured) | PASS | monitoring ON: peak -20.00 dBFS rms 0.0707 · OFF: peak -20.00 dBFS rms 0.0707 · Δpeak 0.00 dB · RMS ratio 1.00 (a re-captured monitor signal would add ≈ +6 dB / ratio ≈ 2) |
| Feedback safety: built-in mic + built-in speakers → auto monitoring off, warning + Session Guardian; override checkbox | PASS | MacBook Pro Microphone → MacBook Pro Speakers: RISK; MacBook Pro Microphone → External Headphones: ok; Scarlett 2i2 USB → MacBook Pro Speakers: ok; Microphone Array (Realtek(R) Audio) → Speakers (Realtek(R) Audio): RISK · armed track NOT monitored under risk · I/O: "Feedback risk: built-in microphone with built-in speakers. Auto input monitoring" · override → monitored · Guardian: "Monitoring: Feedback risk: built-in microphone ("MacBook Pro Microphone") with built-in sp" |
| Playback Engine: monitoring latency (input + base + output) reported | PASS | "31.2 ms (input n/a + base 0.0 ms + output 31.2 ms)" · storage row: "0.2 MB used of 10240 MB · may be evicted (export packages)" |
| AI Engineer: greeting + scan report | PASS | greeting + scan report rendered |
| AI Engineer: measure (real analyser, ~4 s) | PASS | Measured 4.0 s of the master. Scan done. 3 items to review: • Master Headroom: Problem — Output peak 9.3 dBFS (master tap -2.7 + 12 dB monitor make-up), 93056 c |
| AI Engineer: fix session + snapshot restore | PASS | 2 snapshot(s); restore clicked |
| AI Engineer: ideas → audition A/B → keep / reject | PASS | 19 ideas; audition A/B, keep and reject worked |
| AI Engineer: surprise / challenge / mastering check (AI menu) | PASS | 16 new messages |
| AI Engineer: chat intents + producer profile | PASS | replies: Here's what I can do: • "scan" — session health + mix report \| MOCK CLOUD REPLY to: make the vocals brighter — Royal AI · \| Restored and verified "Before audition: Lift Vocals Lead ~2 \| MOCK CLOUD REPLY to: how loud is my mix? — Royal AI · GENER · profile pane 699 chars |
| AI Engineer: voice (TTS via speechSynthesis mock) | PASS | 19 utterances spoken via mock; mic button present |
| Royal AI Cloud: ONLINE with mock provider (gateway reply + credits) | PASS | badge "SUPER INTELLIGENCE ONLINE", credits ◆ 4,998 → ◆ 4,997, reply "MOCK CLOUD REPLY to: what do you think about the groove in the verse? — Royal A" |
| Royal AI Cloud: OFFLINE (gateway unreachable) → local engineer keeps working | PASS | mid-session: badge "OFFLINE SESSION GUARDIAN", local reply "I didn't catch that as a command. Here's what I can do: • "s"; cold start: "OFFLINE SESSION GUARDIAN" |
| Menus: all 144 items clicked across 13 menus | PASS | every item produced a visible effect (dialog, state change, status message, download or file picker) with no console errors |
| Menus: items that only show a "not implemented / browser-limited" message (44) | LIMITED | File › Open Recent › (no recent sessions): disabled; File › Import › Session Data…: "Import Session Data — not implemented yet"; File › Import › Video…: "Import Video — not implemented yet"; Edit › Shift: "Shift — not implemented yet"; Edit › Heal Separation: "Heal Separation — not implemented yet"; Edit › Selection › Change Tempo of Selection…: "Heal Separation — not implemented yet TEMPO BPM CANCEL SET TEMPO ×"; Edit › Fades…: "Fades — not implemented yet"; View › Edit Window: "Fades — not implemented yet"; View › Mix Window: "Fades — not implemented yet"; View › Console: "Fades — not implem |
| Responsive layout 1280×800 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 1440×900 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 1920×1080 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 2560×1440 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Harness note: page navigation retried | INFO | 1 navigation(s) needed a retry (page.goto: Timeout 30000ms exceeded.) — browser/harness flake, app loaded on retry |

### Webkit

| Feature | Status | Notes |
|---|---|---|
| App load (served via Royal AI Cloud gateway) | PASS | banner "BUILD DEPLOY-2" |
| App load (single-file OPEN-MY-CONSOLE.html, file://) | PASS | banner "BUILD DEPLOY-2", file:// input notice shown |
| Transport: Play / Stop (UI buttons) | PASS | playhead advanced to bar 1.77 in 1.2 s at 120 BPM; engine ran |
| Transport: RTZ / FF / RW | PASS | FF 6.366→10.366, RW →6.366, RTZ →1 |
| Transport: Loop toggle | PASS | loop false→true |
| Transport: Metronome (CLK) + Count-in (CI) | PASS | count-in 1 bar at 120 BPM then roll; metronome on |
| Transport: BPM field + timebase | PASS | tempo 97 set; timebase readouts MinutesSeconds:00:01.253 \| Samples:60128 \| Timecode:00:00:01:07 \| BarsBeats:001.3.024 |
| Transport: keyboard (Space play/stop, M metronome) | PASS | ok |
| Setup › Playback Engine dialog (menu, devices, readout) | PASS | outputs: System default · setSinkId NOT supported → system-default note shown |
| Playback Engine: sample rates 44.1/48/88.2/96 recreate AudioContext | PASS | 44100→44100, 48000→48000, 88200→88200, 96000→96000 |
| Playback Engine: latency hint interactive/balanced/playback/custom + baseLatency/outputLatency | PASS | interactive: base 2.9 ms / out 0.0 ms \| balanced: base 2.9 ms / out 0.0 ms \| playback: base 2.9 ms / out 0.0 ms \| custom: base 2.9 ms / out 0.0 ms |
| Playback Engine: output device selection (setSinkId) persisted by label | LIMITED | AudioContext.setSinkId not available in this browser → system default output; dialog tells the user to pick the interface in macOS/Windows Sound settings |
| Setup › I/O: enable input (getUserMedia, DSP off), channels, device list | LIMITED | no fake capture device for headless WebKit; error shown to user: Microphone permission denied. Click the lock icon in the address bar, allow Microphone for this site, then press Enable input again. |
| I/O: per-track input selection (mono N / stereo pairs) persisted | PASS | options mono:0,mono:1,stereo:0; track tr-01 → stereo:0 |
| I/O: round-trip test without a loopback reports "no loopback" honestly | LIMITED | no capture device |
| Record: armed track + REC captures REAL audio from input into a clip (latency-compensated) | LIMITED | no capture device in headless WebKit |
| Record: recorded clip waveform uses real peaks (Edit window) | LIMITED | no capture device |
| I/O: loopback round-trip measurement (simulated 12 ms loopback) | LIMITED | no capture device in headless WebKit |
| Hot-plug: devicechange → fallback to default + UI + Session Guardian notice | LIMITED | no media devices in headless WebKit |
| Permissions: mic denied → clear error | LIMITED | denial is simulated in the Chromium run only |
| Edit tools: Smart/Selector/Grabber/Trim/Scrub/Pencil buttons | PASS | Selector:selector, Grabber:grabber, Trim:trim, Scrub:scrub, Pencil:pencil, Smart:smart |
| Edit modes: Shuffle / Slip / Spot / Grid (Options menu) | PASS | Shuffle → Slip → Spot → Grid |
| Edit: split at playhead (B) | PASS | clips 3→4 |
| Edit: cut clip / selection | PASS | clips 4→3 |
| Edit: trim to selection / playhead | PASS | len 4.00→3.00 |
| Edit: elastic on/off (E) | PASS | elastic toggled on clip |
| Edit: nudge selected clip forward/back | PASS | start 5→5.25→5 |
| Edit: grid size select | PASS | options 0.25,0.5,1,2,4; grid → 4 → 0.25 |
| Edit: slip free move vs grid snap; spot action | PASS | slip move → 6.37, grid move → 6.38; spot action present true |
| Edit: zoom in/out + track height +/- | PASS | zoom 48→60; track height "TracksSmallerLarger72px" → "TracksSmallerLarger80px" |
| Edit: track colors + groups (dialog, linked faders) | PASS | group of 2, linked fader followed, color set |
| Piano roll / MIDI: click grid adds note, click note removes it | PASS | notes 2→3→2 |
| Mix: fader drag → dB readout → engine gain = 10^(dB/20) (true dB) | PASS | drag → -21.50 dB (readout "-21.5"), engine fader gain 0.04628 = 10^(dB/20) × source trim 0.55 (error 0.000 dB) |
| Mix: fader dB accuracy measured on the signal (0 / −6 / −12 / −20 dB) | PASS | 0 dB → gain 0.00 / signal 0.00 dB; -6 dB → gain -6.00 / signal -6.00 dB; -12 dB → gain -12.00 / signal -12.00 dB; -20 dB → gain -20.00 / signal -19.99 dB (max signal error 0.01 dB; preview sources are noise-based) |
| Mix: pan knob drag + engine StereoPanner | PASS | pan 0.66 (engine 0.66) |
| Mix: mute / solo buttons + engine gates | PASS | mute gate 3.0e-4 (≤ −60 dB); solo → soloed 1.000 / others 3.0e-4 |
| Mix: sends → bus / new aux (level + engine send gain) | PASS | send A → bus:reverb at −6 dB (engine 0.501); send B → new aux (+1 track) |
| Mix: inserts — add plugin, bypass on/off by clicking the slot, engine follows | PASS | insert E added (engine insert blocks 3); click → bypass (UI + state), click → active |
| Mix: meters respond while playing | PASS | 18 strip meters moving, 18 engine analysers > −60 dBFS |
| Mix: horizontal / vertical scroll of the mix window | PASS | horizontal .pro-mix-strips → 300px; vertical .pro-mix-strips → 100px |
| Automation: write fader moves while playing, read back replays them | PASS | 4 points written; read replayed -3.0, -15.0, -21.0 dB |
| Bounce: File › Bounce Mix produces a valid, non-silent WAV | PASS | MY-CONSOLE-bounce.wav · 2 ch · 48000 Hz · 16-bit · 2.00 s · RMS -8.2 dBFS · peak -1.1 dBFS |
| Headroom modes Standard/Studio/Mastering (transport select → engine) | PASS | standard:12, studio:18, mastering:24, extreme:32 dB |
| Console tab: hardware desk renders a strip per track | PASS | 16 strips for 18 tracks |
| Persist: recorded take stored in IndexedDB (sessionId/takeId, PCM + sample rate/channels + peaks) | LIMITED | no capture device in headless WebKit (persistence is covered below with an imported WAV) |
| Import › Audio… decodes a WAV exactly, places a clip and persists it (sample-exact hash) | PASS | Import Audio · 1 file decoded and saved (48000 Hz, 1 ch) · decoded PCM sha256 matches the source file's samples (6b3c13fccf22…) |
| Edit: split an audio clip → right half plays from the matching offset in the take; Undo restores | PASS | offsets 0.000 / 0.500 s (expected 0.500) · Edit › Undo → original clip back |
| Persist: reload → autosaved session restores clips, same audio hash, real peaks, plays | PASS | imported take-muj55s0m-0pxwmv: hash equal, peaks, scheduled · "Restored autosaved session · Untitled Session · 1/1 audio file(s) from browser storage" |
| Package: Save Session As → .mycsession zip (session.json + Audio Files/*.wav, sha-256 per file) | PASS | QA Package.mycsession · 255 KB · session.json + 1 WAV (qa-webkit-import_take-muj55s0m-0pxwmv.wav) |
| Package: File › Open in a FRESH browser profile restores audio into IndexedDB (same hashes) | PASS | IDB keys 0 → 1 · 1 take(s) hash-identical · "Opened package · QA Package · 1 audio file(s) restored (1 verified)" |
| Session: legacy .mycsession.json (Save Session ⌘S) still opens (roundtrip) | PASS | QA Package.mycsession.json · tempo 90→133 restored, tracks 18 · "Opened session · QA Package · 1/1 audio file(s) found in this browser" |
| Undo of a clip delete keeps its audio; Clean Up removes only orphaned audio | PASS | delete → audio still in IDB · Edit › Undo → clip back, hash identical ("Undo Cut / Delete") · delete + Clean Up → "Clean Up · removed 1 unused audio file(s) · kept 0" |
| Storage: quota error on save → take marked unsaved + clear warning + Session Guardian | PASS | QuotaExceededError (simulated by stubbing IDBObjectStore.put) → take persist=failed, unsaved takes 1; warning: "Browser storage is full — take "qa-webkit-import" is NOT saved to this browser. Export now…"; Guardian: "Storage: Browser storage is full — take "qa-webkit-import" is NOT save…" |
| Storage: low free space (navigator.storage.estimate) → Session Guardian warning | PASS | Guardian: "Storage: Browser storage is low: 50 MB free of 1000 MB. New takes may fail to save — export (Save Session As…)" · navigator.storage.persist is requested on first save |
| Session Guardian: recorded take not yet exported → notice | LIMITED | no capture device in headless WebKit |
| Monitor: TrackInput (I) button → live input through the channel strip to master meters (transport stopped) | LIMITED | no capture device in headless WebKit |
| Monitor: input follows the channel strip (mute → input gone from master, fader −20 dB → quieter, unmute → back) | LIMITED | no capture device |
| Monitor: Auto Input (armed: input when stopped, track on playback) / Input Only (input always) — Options menu | LIMITED | no capture device |
| Monitor: no double record — take level with monitoring ON ≈ monitoring OFF (monitored output never re-captured) | LIMITED | no capture device |
| Feedback safety: built-in mic + built-in speakers → auto monitoring off, warning + Session Guardian; override checkbox | LIMITED | label rule verified (MacBook Pro Microphone → MacBook Pro Speakers: RISK; MacBook Pro Microphone → External Headphones: ok; Scarlett 2i2 USB → MacBook Pro Speakers: ok; Microphone Array (Realtek(R) Audio) → Speakers (Realtek(R) Audio): RISK); live suppression needs a capture device |
| Playback Engine: monitoring latency (input + base + output) reported | PASS | "2.9 ms (input n/a + base 2.9 ms + output 0.0 ms)" · storage row: "0.0 MB used of 1000 MB · may be evicted (export packages)" |
| AI Engineer: greeting + scan report | PASS | greeting + scan report rendered |
| AI Engineer: measure (real analyser, ~4 s) | PASS | Measured 4.0 s of the master. Scan done. 3 items to review: • Master Headroom: Problem — Output peak 10.8 dBFS (master tap -1.2 + 12 dB monitor make-up), 128140 |
| AI Engineer: fix session + snapshot restore | PASS | 2 snapshot(s); restore clicked |
| AI Engineer: ideas → audition A/B → keep / reject | PASS | 19 ideas; audition A/B, keep and reject worked |
| AI Engineer: surprise / challenge / mastering check (AI menu) | PASS | 16 new messages |
| AI Engineer: chat intents + producer profile | PASS | replies: Here's what I can do: • "scan" — session health + mix report \| MOCK CLOUD REPLY to: make the vocals brighter — Royal AI · \| Restored and verified "Before audition: Pull Vocals Lead rev \| MOCK CLOUD REPLY to: how loud is my mix? — Royal AI · GENER · profile pane 739 chars |
| AI Engineer: voice (TTS via speechSynthesis mock) | PASS | 19 utterances spoken via mock; mic button present |
| Royal AI Cloud: ONLINE with mock provider (gateway reply + credits) | PASS | badge "SUPER INTELLIGENCE ONLINE", credits ◆ 4,998 → ◆ 4,997, reply "MOCK CLOUD REPLY to: what do you think about the groove in the verse? — Royal A" |
| Royal AI Cloud: OFFLINE (gateway unreachable) → local engineer keeps working | PASS | mid-session: badge "OFFLINE SESSION GUARDIAN", local reply "I didn't catch that as a command. Here's what I can do: • "s"; cold start: "OFFLINE SESSION GUARDIAN" |
| Menus: all 144 items clicked across 13 menus | PASS | every item produced a visible effect (dialog, state change, status message, download or file picker) with no console errors |
| Menus: items that only show a "not implemented / browser-limited" message (44) | LIMITED | File › Open Recent › (no recent sessions): disabled; File › Import › Session Data…: "Import Session Data — not implemented yet"; File › Import › Video…: "Import Video — not implemented yet"; Edit › Shift: "Shift — not implemented yet"; Edit › Heal Separation: "Heal Separation — not implemented yet"; Edit › Selection › Change Tempo of Selection…: "Heal Separation — not implemented yet TEMPO BPM CANCEL SET TEMPO ×"; Edit › Fades…: "Fades — not implemented yet"; View › Edit Window: "Fades — not implemented yet"; View › Mix Window: "Fades — not implemented yet"; View › Console: "Fades — not implem |
| Responsive layout 1280×800 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 1440×900 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 1920×1080 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |
| Responsive layout 2560×1440 | PASS | console/edit/mix fit without page overflow; menu + transport visible; I/O dialog fits |

## Menu items flagged (not implemented / browser-limited)

Every one of these shows a clear message when clicked, so none are dead. They are listed so they can be built later.

- File › Open Recent › (no recent sessions): disabled
- File › Import › Session Data…: "Import Session Data — not implemented yet"
- File › Import › Video…: "Import Video — not implemented yet"
- Edit › Shift: "Shift — not implemented yet"
- Edit › Heal Separation: "Heal Separation — not implemented yet"
- Edit › Selection › Change Tempo of Selection…: "Heal Separation — not implemented yet TEMPO BPM CANCEL SET TEMPO ×"
- Edit › Fades…: "Fades — not implemented yet"
- View › Edit Window: "Fades — not implemented yet"
- View › Mix Window: "Fades — not implemented yet"
- View › Console: "Fades — not implem

## DEPLOY-2: what's new and how it was verified

**Recorded audio persistence (IndexedDB)**
- Every recorded or imported take is stored in IndexedDB (`royal-console-audio` › `takes`), keyed by
  `sessionId/takeId`. Each entry holds raw Float32 PCM per channel, the sample rate, channel count and cached
  high-resolution peaks. Clips reference takes (`audio: { takeId, offsetSec }`).
- The session autosaves every 2 s (only when something changed) and restores on reload.
- The waveforms are the take's real peaks, not placeholder shapes.
- Test: record → reload → identical SHA-256 of the PCM, peaks present, take scheduled for playback.

**Portable session package**
- File › Save Session As… and File › Export › Session Package write a `.mycsession` zip containing `session.json`
  (with a per-file SHA-256) and `Audio Files/*.wav` (32-bit float, bit-exact).
- File › Open Session… accepts the package or a legacy `.mycsession.json`.
- Test: package opened in a **fresh browser context** (empty IndexedDB) → audio written to IndexedDB, hashes
  identical, clips present.

**Clip edits never delete audio**
- New Edit › Undo / Redo (⌘Z / ⇧⌘Z) for clip edits: cut/delete, split, trim and nudge.
- Orphaned audio is removed only by File › Clean Up Unused Audio… (with a confirmation).
- Test: delete clip → audio still in IndexedDB → Undo → clip back with the same hash → delete + Clean Up → orphan
  removed, referenced take kept.

**Storage safety**
- `navigator.storage.persist()` is requested without blocking the write.
- A quota error marks the take unsaved and shows a clear warning plus a Session Guardian notice.
- Low free space (above 90% used or under 200 MB free) triggers a Guardian warning.
- If takes are unsaved or still being written, closing the tab asks for confirmation.

**Input monitoring**
- A per-track TrackInput **I** button (now visibly green) in the Mix and Edit windows.
- Options › Auto Input Monitoring / Input Only Monitoring / Low Latency Monitoring.
- The live input goes through the channel's inserts, fader, pan, mute/solo to the master, and runs with the transport
  stopped (a monitor-only engine graph).
- Armed tracks show their input on the track meter.
- Feedback safety: a built-in mic with built-in speakers, detected by device name, keeps auto monitoring off, with a
  warning in Setup › I/O and from the Session Guardian. There is an explicit override checkbox.
- Playback Engine shows the monitoring latency (input + base + output, as the browser reports it) and storage use.
- **No double record:** the recorder taps the raw input before the mixer. The test compares takes recorded with
  monitoring on and off: RMS ratio ≈ 1.0, where a re-captured monitor signal would give about 2.

**Other**
- File › Import › Audio… decodes files for real: WAV sample-exactly (sha-verified), other formats via
  `decodeAudioData`. The audio is persisted and placed on the timeline.
- File › Export › Clips as Files… writes a zip of 24-bit WAVs of the audio clips.

**Menu items that DEPLOY-2 made real** (they were stubs or didn't exist):
- Edit › Undo, Edit › Redo
- File › Import › Audio…
- File › Export › Clips as Files…
- File › Export › Session Package (.mycsession)…
- File › Clean Up Unused Audio…
- File › Save Session As… / Save Copy In… (now portable packages)
- Options › Auto Input Monitoring / Input Only Monitoring / Low Latency Monitoring

**Bugs found while doing DEPLOY-2 and fixed**
1. The TrackInput **I** button's "on" state was invisible (pre-existing): a global `.pro-led-btn` `!important`
   override hid it. It now lights green in both windows, and the test checks the computed style.
2. Firefox: `navigator.storage.persist()` shows a permission prompt, and awaiting it left takes stuck as "pending".
   The request no longer blocks the write.
3. IndexedDB robustness: if the database existed without the `takes` store, writes failed. The app now upgrades
   the database. The QA's own IndexedDB probe triggered this.
4. Edited recorded clips (split / cut / trim-start) now play and draw from the right place in the take. Before,
   they always started at the take start.

## Bugs found by the DEPLOY-1 QA and fixed (still covered by the suite)

Each bug was reproduced first, then fixed and re-verified by the suite.

1. **Engine rebuilt the whole audio graph ~31×/s during playback** (`TrackPreviewEngine.sync`). It compared all
   tracks including the master against the channels, which exclude the master. As a result:
   - faders never settled,
   - sources restarted constantly,
   - meters and gain were unstable.

   Fixed by comparing the non-master count, plus a routing signature so that input, send and pre/post changes
   still rebuild. The engine now does 0 rebuilds/s at steady state.
2. **Faders now map to true dB.** Fader position → dB curve (−60…+6 dB) → gain = 10^(dB/20), applied in the engine
   for tracks (realtime and offline bounce) and the master:
   - The master's hidden ×0.9 trim was removed, so 0 dB = unity.
   - The sends' hidden ×0.85 trim was removed, so a send at −6 dB = 0.501.
   - The AI fixer's fader conversion is now a straight dB change.
   - Measured in the tests: 0 / −6 / −12 / −20 dB within 0.01 dB on the signal.
3. **Menu dropdowns were hidden under the sticky "FLAT HARDWARE DESK" banner.** Fixed with a z-index change.
4. **View › Zoom In / Zoom Out / Horizontal Zoom jumped straight to minimum zoom** (wrong bounds 0.25–8 against the
   real range 16–120). Fixed.
5. **Opening the "▴ MIDI / Clip / Score" panel crashed the Edit window** (React error #310: an early return before
   hooks). Fixed.
6. **Stopping after a recording overwrote the "Recorded …" status.** Fixed.
7. **Track › Duplicate with no selection did nothing silently.** It now says "select one or more tracks first";
   on success it reports "Duplicated N tracks".
8. **Options › Solo Mode (Latch / X-OR / SIP) gave no feedback.** It now shows a status.
9. **Hardening: fader moves made while the audio device is still starting are no longer dropped.** `start()` now
   builds from the latest synced levels instead of the snapshot taken when Play was pressed. This is defensive.
   The Chromium failure that led here turned out to be the box's PulseAudio null sink: the audio clock stays
   frozen for about 1.5 s after `resume()`. The test now waits for the audio clock to move.
10. **Recording/loopback capture lost time when the input went silent/inactive.** Firefox hands the capture
    worklet zero channels, which dropped frames, so the loopback test failed. Silence is now recorded, frames are
    batched (1024) to avoid flooding the main thread, and the capture is flushed before analysis. The loopback
    wait follows the audio clock, not wall time.
11. `open.sh` printed the default data dir even when `ROYAL_DATA_DIR` was set. Fixed.

The earlier DEPLOY-1 work (new I/O plumbing) also routed through these tests:
- Playback Engine: sample-rate recreate, latency hint, setSinkId by label.
- I/O: input enable with DSP off, channel detection, per-track input.
- Latency compensation, loopback measurement, hot-plug fallback/reconnect.

## Limitations (documented, not passes)

- **Real hardware not exercised.**
  - Fake capture devices were used (Chromium/Firefox).
  - The round-trip loopback is simulated with a 12 ms delay in the page.
  - Hot-plug is simulated (patched `enumerateDevices` + a `devicechange` event).
  - The detection logic is real; the cable and the interface are not. Run *Measure round-trip latency* on your
    own interface.
- **No ASIO in any browser.** Browsers use CoreAudio (Mac) / WASAPI shared (Windows). ASIO and pro multichannel
  need the native Apex Host (see AUDIO-INTERFACES.md).
- **Multichannel input depends on the browser.** The fake devices exposed 2 channels in Chrome and 1 in Firefox,
  so more than 2 channels was not testable here.
- **Browser support gaps:**
  - Output-device choice (`setSinkId`) is Chrome/Edge only. Firefox and WebKit play to the system output, and the
    dialog says so.
  - Firefox refused 88.2/96 kHz on the box's output (reported in the dialog).
- **WebKit on Linux has no capture device**, so input/record/loopback/hot-plug are LIMITED there. Safari on a Mac
  with a real interface was not tested.
- **Permission denial** was simulated in Chromium only.
- **Recorded audio takes (DEPLOY-2):**
  - The audio lives in browser storage until you export a `.mycsession` package, and clearing site data deletes
    it. Safari may evict data from sites you haven't used for a while.
  - Elastic Audio stretch is not applied to recorded/imported audio. Changing the tempo after recording moves where
    the audio starts and ends in bars.
  - The built-in synthetic preview source still plays on a recorded track during playback.
  - The quota-full path was tested by simulating `QuotaExceededError` (stubbing `IDBObjectStore.put`), and low
    storage by stubbing `navigator.storage.estimate`. A real full disk was not produced.
- **Input monitoring (DEPLOY-2):**
  - It runs through the browser, so it has the browser's latency; it is not zero-latency hardware monitoring. The
    latency shown is what the browser reports, not an acoustic measurement.
  - Feedback detection is based on device names. It was tested by setting device labels, because no real built-in
    mic/speakers exist on the box.
  - Tests used the fake capture devices (Chromium beeps that clip at 0 dBFS, Firefox tone). WebKit has no capture
    device, so the record and monitoring tests are LIMITED there. Persistence and packages are tested in WebKit
    with an imported WAV.
  - Meter values are display-scaled, so a −20 dB fader move is checked only as "clearly quieter". The kick channel
    feeds the compressed Drum Bus.
  - Muting a monitored track removes its input from the master. The master meter still shows the demo session's
    emulated plugin noise floor from other channels (about 0.02).
- **Voice:**
  - TTS was verified with a `speechSynthesis` mock.
  - Real speech recognition (STT) can't be automated headless, so it was not tested.
  - Firefox has no speech recognition.
- **Demo session master is hot (pre-existing, not a regression).** The shipped demo session peaks around +11 dBFS
  at the output after the +12 dB monitor make-up. The Session Guardian flags it and **FIX SESSION** repairs it.
  It is more audible now, because the graph no longer rebuilds constantly.
- **Launchers:**
  - `open.sh` was run on Linux from the unzipped package: the server started, `/v1/health` returned OK, and the
    DAW was served.
  - `OPEN-WINDOWS.bat` was checked statically (syntax, paren/escape balance, CRLF) but **not run on Windows**.
  - `OPEN.command` was not run on a Mac from this box.
- **Production deploy:** there was no `docker build`, Caddy/TLS or Fly/Render/Railway run on this box. The
  container layout was smoke-tested without Docker.

## Other verification

- `npm run build` and `npm run build:single` pass (TypeScript strict).
- Gateway version string: 3.21.0-deploy-2 (`/v1/health`).
- Royal AI Cloud gateway unit/integration tests: **23/23 pass on Python 3.13 and on Python 3.8**.
- Responsive checks at 1280×800, 1440×900, 1920×1080 and 2560×1440: no page overflow; menu and transport visible;
  I/O dialog fits.

## How to re-run

```
cd royal-ai-cloud && python3 tests/mock_provider.py --port 9911 &
OPENAI_API_KEY=sk-test OPENAI_BASE_URL=http://127.0.0.1:9911/v1 python3 server.py --data-dir /tmp/qa-data serve --port 8777 --web-root ../MY-CONSOLE --no-prompt &
PW_CORE=<path to playwright-core> node ../qa/qa-suite.cjs chromium   # or firefox / webkit
```
