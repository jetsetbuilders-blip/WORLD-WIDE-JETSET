# DEPLOY-CLOUD — put MY CONSOLE + Royal AI Cloud on the internet (one HTTPS domain)

One deployment serves **both** the MY CONSOLE DAW (web app) **and** the Royal AI Cloud gateway
from the same origin, e.g. `https://console.example.com`:

    Browser ──HTTPS──▶ Caddy / nginx / platform TLS ──▶ royal-ai-cloud/server.py (one container)
                                                          ├─ /            MY CONSOLE web app (static)
                                                          └─ /v1/...      Royal AI Gateway ──▶ OpenAI
                                                                           (provider key: server secret only)

Everything is Python 3 standard library (the image is just `python:3.12-slim`). No pip, no node at runtime.

---

## 1. What production mode changes

Turn production mode on with `ROYAL_PRODUCTION=1` (the Dockerfile sets it by default).

| Setting | Local Mac (OPEN.command) | Production |
|---|---|---|
| Licenses | DEV license auto-created (Dav Black, 5,000 credits) | **No auto-license.** Customers enter a license key in ⚙ Settings |
| Allowed Host / Origin | 127.0.0.1 / localhost | Only `ROYAL_PUBLIC_ORIGINS` (+ localhost for admin tunnels). **Startup fails if it's unset** |
| HTTPS | not needed (localhost) | Terminated by Caddy/nginx/platform. HSTS header on every response |
| Client IP for rate limits | socket address | `X-Forwarded-For` from your proxy (`ROYAL_TRUST_PROXY=1`) |
| Provider key | prompt → `~/Library/Application Support/RoyalAICloud/secrets.json` | `OPENAI_API_KEY` from the host's secret store |
| Data | `~/Library/Application Support/RoyalAICloud` | `/data` volume (`ROYAL_DATA_DIR`) |

All other gateway protections are the same in both modes:
- JSON only, with a 256 KB body limit.
- Every request is checked against a strict schema.
- Allowed operations only; raw prompts are never passed through.
- Credits are checked before a call and deducted after it succeeds.
- Per-user and per-device rate limits, daily caps and abuse flags.
- The model's proposed actions are validated before they reach the browser.
- The key never appears in any response or log.

## 2. Environment variables

| Variable | Required | Example / meaning |
|---|---|---|
| `ROYAL_PUBLIC_ORIGINS` | **yes** | `https://console.example.com` (comma-separate several) |
| `OPENAI_API_KEY` | yes, to go online | Keep it in platform secrets or `.env` (chmod 600). Without it the DAW runs as *Offline Session Guardian* |
| `OPENAI_BASE_URL` | no | An OpenAI-compatible endpoint |
| `ROYAL_MODEL` | no | Default model (`gpt-4o-mini`). A per-operation model map goes in `/data/config.json` |
| `ROYAL_PRODUCTION` | set in image | `1` |
| `ROYAL_TRUST_PROXY` | set in image | `1` (only when a proxy is in front, which it always is in these recipes) |
| `ROYAL_DATA_DIR` / `ROYAL_WEB_ROOT` / `ROYAL_HOST` / `ROYAL_PORT` | set in image | `/data`, `/app/web`, `0.0.0.0`, `8765` |

Optional `/data/config.json` (models, costs, caps, rate limits):
```json
{"provider": {"default_model": "gpt-4o-mini", "model_for_op": {"mastering_analysis": "gpt-4o"},
              "max_tokens": 900, "temperature": 0.4},
 "costs": {"quick_question": 1, "mix_analysis": 6},
 "rate_limit": {"user_burst": 20, "user_per_sec": 0.5}}
```

> **Run exactly one instance.** SQLite and the in-memory rate limiter are single-node by design. This is plenty for
> hundreds of producers. Scale up the machine size, not the instance count.

---

## 3. Option A — your own server (VPS) with Docker + Caddy (automatic HTTPS)

Needs: a Linux VPS (1 vCPU / 1 GB is enough), Docker with the compose plugin, and a domain.

1. **DNS:** create an A (and AAAA) record `console.example.com → your server IP`.
2. Upload this whole package folder to the server:
   `scp -r ROYAL-CONSOLE-DEPLOY-2 you@server:~/`
3. Configure it on the server:
   ```bash
   cd ~/ROYAL-CONSOLE-DEPLOY-2/deploy
   cp .env.example .env && chmod 600 .env
   nano .env   # ROYAL_DOMAIN, ROYAL_PUBLIC_ORIGINS=https://<domain>, OPENAI_API_KEY=sk-...
   docker compose up -d --build
   docker compose logs -f royal   # expect: Mode: PRODUCTION ... Provider: configured
   ```
4. Open `https://console.example.com`. The banner should read **BUILD DEPLOY-2**. Caddy fetches the certificate
   on the first request.
5. Create your first customer license (see section 5), enter it in the AI panel's ⚙ Settings, and the badge
   turns to **SUPER INTELLIGENCE ONLINE**.

Firewall: open only 80 and 443. The gateway port (8765) is not published; it's only reachable through Caddy.
If you prefer nginx, see `deploy/nginx.conf.example` (certbot for certificates) and publish the container
as `127.0.0.1:8765:8765`.

## 4. Option B — a platform (HTTPS handled for you)

All three platforms build `deploy/Dockerfile` with the **package root** as the build context. Put this
package in a Git repo first:
```bash
cd ROYAL-CONSOLE-DEPLOY-2 && git init && git add . && git commit -m "MY CONSOLE DEPLOY-2"
```
Check that no `.env`, `*.db` or `secrets.json` gets committed. The package ships none.

### Fly.io
```bash
fly launch --no-deploy --copy-config --dockerfile deploy/Dockerfile   # accept/rename app; uses deploy/fly.toml
fly volumes create royal_data --size 1 --region iad
fly secrets set OPENAI_API_KEY=sk-... ROYAL_PUBLIC_ORIGINS=https://<app>.fly.dev
fly deploy --dockerfile deploy/Dockerfile
fly ssh console -C "python3 /app/server/server.py license create --credits 2000 --user 'First Customer' --days 365"
```
Custom domain: `fly certs add console.example.com`. Then set
`ROYAL_PUBLIC_ORIGINS=https://console.example.com,https://<app>.fly.dev`.

### Render
1. Copy `deploy/render.yaml` to the repo root as `render.yaml`, then **New › Blueprint** and pick the repo.
2. Set `OPENAI_API_KEY` in the dashboard.
3. Set `ROYAL_PUBLIC_ORIGINS` to your `https://<name>.onrender.com` URL (or your custom domain).
4. A persistent disk at `/data` needs a paid instance type. Use the **Shell** tab for the license CLI.

### Railway
1. New Project › Deploy from repo. `deploy/railway.json` points to the Dockerfile. If your Railway
   version reads `railway.json` only from the repo root, copy it there.
2. Add a **Volume** mounted at `/data`.
3. Set the variables `OPENAI_API_KEY` and `ROYAL_PUBLIC_ORIGINS=https://<service>.up.railway.app`.
4. Generate a domain. Use `railway ssh` or the service shell for the license CLI.

Health check path for every platform: `/v1/health`. It answers on any Host header, so platform probes work.

---

## 5. Customers, licenses and credits

Run these inside the container:
- Docker Compose: `docker compose exec royal …`
- Fly: `fly ssh console -C "…"`
- Render/Railway: open the service shell.

```bash
python3 /app/server/server.py license create --credits 2000 --user "Jane Producer" --email jane@example.com \
        --plan PRO --max-devices 3 --days 365            # prints RYL-XXXX-XXXX-XXXX-XXXX → send to the customer
python3 /app/server/server.py license list
python3 /app/server/server.py credits add RYL-XXXX-XXXX-XXXX-XXXX 1000     # top up
python3 /app/server/server.py license reset-devices RYL-XXXX-XXXX-XXXX-XXXX # new computer
python3 /app/server/server.py license revoke RYL-XXXX-XXXX-XXXX-XXXX        # refund / abuse
python3 /app/server/server.py status
```
- `--ops quick_question,mix_analysis` limits a plan to specific operations.
- Each customer opens `https://console.example.com` › AI panel › ⚙ Settings › **Royal AI license key** ›
  Activate. The key is stored in their browser. The provider key never leaves your server.
- Operation costs, daily caps and rate limits are in `/data/config.json`. Usage per request (tokens, model,
  latency) is in the `usage_log` table.
- Payments aren't built in yet. Create licenses after a payment in Stripe, Gumroad, etc. A webhook-to-CLI step is
  the natural next build.

## 6. Backups & restore

- **What to back up:** `/data/royal.db` (licenses, credits, usage, producer memory).
  - `/data/hmac_secret` is optional: if it's lost, users just sign in again automatically.
  - The provider key isn't on disk in production (it comes from env/secrets).
- **Docker Compose:** `deploy/backup.sh` makes an online-safe SQLite backup, copies it out of the volume
  and keeps 14. Run it from cron: `0 3 * * * /home/you/ROYAL-CONSOLE-DEPLOY-2/deploy/backup.sh`.
  Copy `deploy/backups/` off the server too (S3, B2, rsync).
- **Any platform:** `python3 /app/server/server.py backup --out /data/backups/royal-$(date +%F).db`, then download it
  (for example with `fly ssh sftp get /data/backups/…`).
- **Restore:** stop the service, replace `/data/royal.db` with the backup file (remove any `royal.db-wal` and
  `royal.db-shm`), then start it again.

## 7. Updating

Replace `MY-CONSOLE/` (the web app) and `royal-ai-cloud/` with the new build, then:
- Compose: `docker compose up -d --build`
- Fly: `fly deploy`
- Render/Railway: push to Git.

The `/data` volume, and with it all licenses and credits, is kept.

## 8. Security checklist

- [ ] HTTPS only: the proxy redirects HTTP; HSTS is sent by the gateway.
- [ ] `ROYAL_PUBLIC_ORIGINS` is exactly your public URL(s).
- [ ] `OPENAI_API_KEY` is in platform secrets or a chmod 600 `.env`, never in Git, never in the web folder.
- [ ] One instance, `/data` on a persistent volume, backups scheduled.
- [ ] Port 8765 isn't reachable from the internet directly.
- [ ] Set a spend limit and alerts on your OpenAI account.
