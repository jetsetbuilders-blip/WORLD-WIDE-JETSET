# ROYAL CONSOLE — DEPLOY-2 (v3.21.0-deploy-2)

This package holds everything needed to run the **MY CONSOLE** DAW, on your Mac or on the public internet, with
the **Royal AI Cloud** (AI Session Engineer with a server-side OpenAI key).
MY CONSOLE is itself the DAW. It runs in the browser; nothing gets loaded into another DAW.

```
ROYAL-CONSOLE-DEPLOY-2/
├─ README-DEPLOY.md        ← you are here
├─ DEPLOY-CLOUD.md         ← full public-deploy guide (Docker, Caddy/HTTPS, Fly/Render/Railway, licenses, backups)
├─ START-HERE.txt          ← short version (Mac / Windows / Linux)
├─ AUDIO-INTERFACES.md     ← audio interfaces: Playback Engine, I/O, latency compensation, limits (no ASIO in browsers)
├─ QA-REPORT.md            ← full browser QA results (Chromium / Firefox / WebKit), bugs fixed, limitations
├─ OPEN.command            ← Mac: starts the Royal AI Gateway + opens the DAW (http://127.0.0.1:8765)
├─ OPEN-WINDOWS.bat        ← Windows: same (needs Python 3.8+ from python.org)
├─ open.sh                 ← Linux: same (python3)
├─ OPEN-MY-CONSOLE.html    ← single-file DAW, no server (offline mode: no cloud AI, no mic)
├─ MY-CONSOLE/             ← the built web app (static files) — served by the gateway locally and in production
├─ royal-ai-cloud/         ← Royal AI Cloud gateway (Python 3 stdlib only) + tests + README
├─ deploy/                 ← Dockerfile, docker-compose.yml, Caddyfile, nginx example, fly.toml, render.yaml,
│                            railway.json, .env.example, backup.sh
└─ .dockerignore
```

**One deploy = DAW + AI on one HTTPS domain.** The same `server.py` serves the web app at `/` and the AI API at
`/v1/…`. The browser never sees the provider key.

---

## A. Run it on your computer (local)

### Mac

1. Unzip, then double-click **`OPEN.command`**.
   The first time, macOS may block it: right-click › Open › Open.
2. First run only: the Terminal asks for your **OpenAI API key** (hidden input).
   - Paste it and press Enter. It's saved to `~/Library/Application Support/RoyalAICloud/secrets.json` (chmod 600).
   - Or press Enter to skip, and the DAW runs as *Offline Session Guardian*.
   - To change it later: `python3 royal-ai-cloud/server.py set-key`
3. The browser opens `http://127.0.0.1:8765`. The banner should read **BUILD DEPLOY-2**.
   In the AI panel the badge shows **SUPER INTELLIGENCE ONLINE**, with 5,000 local DEV credits for Dav Black.
4. Keep the Terminal window open while you work. Close it to stop.

### Windows
1. Install Python 3.8+ from https://www.python.org/downloads/ (tick **Add python.exe to PATH**). The launcher
   also finds the `py` launcher. If no Python is found it says so, shows the link and opens the offline single-file DAW.
2. Double-click **`OPEN-WINDOWS.bat`** (SmartScreen: More info › Run anyway). Same first-run key prompt as on the Mac.
   Key file: `%APPDATA%\RoyalAICloud\secrets.json` (restricted to your user with icacls, best effort).

### Linux
`./open.sh` (or `bash open.sh`). Needs `python3` ≥ 3.8. Key file: `~/.local/share/RoyalAICloud/secrets.json`
(or `$XDG_DATA_HOME/RoyalAICloud`, chmod 600).

Data directory per OS: macOS `~/Library/Application Support/RoyalAICloud`, Windows `%APPDATA%\RoyalAICloud`,
Linux `~/.local/share/RoyalAICloud`. Override with `--data-dir` or `ROYAL_DATA_DIR`.

### Audio interface
Setup › **Playback Engine…** (output device, sample rate, latency/buffer) and Setup › **I/O…** (input device, channels,
per-track inputs, latency compensation, loopback measurement). Microphone/interface input needs the launcher
(http://127.0.0.1) or HTTPS; it does not work from `OPEN-MY-CONSOLE.html` (file://). Details and honest limits
(CoreAudio/WASAPI only, no ASIO in browsers; Chrome/Edge best) are in **AUDIO-INTERFACES.md**.

Voice input works in Chrome or Safari via the launcher (allow the mic; Safari may need Siri/Dictation enabled).
`OPEN-MY-CONSOLE.html` also works with no server, fully offline, but without cloud AI or the mic.

## B. Put it on the internet (public HTTPS)

Short version. Details, platform recipes and the security checklist are in **DEPLOY-CLOUD.md**.

**Own server (VPS + Docker, automatic HTTPS with Caddy):**
```bash
# DNS: A record console.example.com -> server IP; copy this folder to the server, then:
cd ROYAL-CONSOLE-DEPLOY-2/deploy
cp .env.example .env && chmod 600 .env && nano .env   # ROYAL_DOMAIN, ROYAL_PUBLIC_ORIGINS, OPENAI_API_KEY
docker compose up -d --build
docker compose exec royal python3 /app/server/server.py license create --credits 2000 --user "Jane" --days 365
```
Open `https://console.example.com`, then AI panel › ⚙ Settings › paste the `RYL-…` license key › **Activate**.

**Platforms:** Fly.io (`deploy/fly.toml`), Render (`deploy/render.yaml`), Railway (`deploy/railway.json`).
Each builds `deploy/Dockerfile` from this folder. Mount a volume at `/data` and set the secrets
`OPENAI_API_KEY` and `ROYAL_PUBLIC_ORIGINS`.

**What changes in production mode** (`ROYAL_PRODUCTION=1`, set by the Dockerfile):
- There's no free DEV license; every customer needs a license key.
- Only your public origin is accepted.
- HSTS is on, and rate limits use the proxy's client IP.
- The key comes from the platform's secret store.
- Data lives in the `/data` volume: SQLite licenses, credits, usage and producer memory. Back it up with
  `deploy/backup.sh` or `server.py backup`.
- Run exactly one instance (SQLite).

## C. Limits (honest)

- **Web app:** MY CONSOLE's built-in engine uses its own built-in processors and synthesized preview sources.
  It doesn't load third-party VST3/AU binaries in the browser.
- **Real plugin hosting:** that lives in the separate native **Apex Host** (JUCE desktop app, REAL-HOST-1). It's in
  the MY CONSOLE source tree at `engine/native-host/`, is built on a Mac with its own
  `BUILD-ON-MAC.command`, and is **not** part of this web deployment package.
- **Payments:** none built in. Create licenses and credits with the CLI after a sale.
- **Scaling:** one instance. SQLite and the in-memory rate limits are single-node.
- **Audio I/O:** browsers use CoreAudio (Mac) / WASAPI (Windows) — no ASIO. Output-device choice needs
  Chrome/Edge (setSinkId); Safari/Firefox play to the system output. See AUDIO-INTERFACES.md.
- **Voice:** depends on the browser's speech APIs. Firefox has no speech recognition, so it's text-only there.

## D. Verified before shipping (on the build box)

- Full browser QA of the DAW (Playwright, Chromium/Firefox/WebKit, 4 screen sizes): see **QA-REPORT.md**.
  DEPLOY-2 adds recorded-audio persistence (record → reload → identical audio hash), portable `.mycsession`
  packages opened in a fresh browser profile, input monitoring to the master meters, and a no-double-record check.

- `npm run build` and `npm run build:single` pass.
- The gateway test suite passes on Python 3.13 and 3.8. It covers:
  - auth and licenses, credits, 402/429/413/400;
  - context stripping and model-action validation;
  - production mode (licenses required, Host/Origin allow-list, HSTS, proxy IP), plus config validation and the backup CLI.
- Browser test against a production-mode server with a mock OpenAI endpoint (run for DEPLOY-1; DEPLOY-2 changed
  only the gateway's version string, and the gateway test suite above was re-run):
  - The DAW loads and shows OFFLINE until a license is entered.
  - A wrong key is rejected; a valid key turns it ONLINE.
  - A chat question gets the cloud reply, and credits go 300 → 299.
- Container-layout smoke test (DEPLOY-1): the same env vars and paths as the Dockerfile, run without Docker.
  Static files, health, license auth, an AI call and a backup all work, and the files come out owner-only.
- `open.sh` run on Linux (box) from the unzipped DEPLOY-2 package; `OPEN-WINDOWS.bat` checked statically only (no Windows machine); `OPEN.command` not run on a Mac from this build box.
- Not tested: an actual `docker build`/`docker compose` run, Caddy certificates, and Fly/Render/Railway. There's no
  Docker or public DNS on the build box.
