#!/bin/bash
# Nightly backup for the docker-compose deployment (cron: 0 3 * * * /path/deploy/backup.sh)
# Backs up the SQLite database (licenses, credits, usage, producer memory) with SQLite's
# online backup API, copies it out of the volume and keeps the last 14.
set -euo pipefail
cd "$(dirname "$0")"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT_DIR="${BACKUP_DIR:-$PWD/backups}"
mkdir -p "$OUT_DIR" && chmod 700 "$OUT_DIR"
docker compose exec -T royal python3 /app/server/server.py backup --out "/data/backups/royal-$STAMP.db"
docker compose cp "royal:/data/backups/royal-$STAMP.db" "$OUT_DIR/royal-$STAMP.db"
chmod 600 "$OUT_DIR/royal-$STAMP.db"
ls -1t "$OUT_DIR"/royal-*.db | tail -n +15 | xargs -r rm -f
docker compose exec -T royal sh -c 'ls -1t /data/backups/royal-*.db | tail -n +4 | xargs -r rm -f'
echo "Backup: $OUT_DIR/royal-$STAMP.db"
# Also keep a copy of /data/hmac_secret somewhere safe once (without it, issued tokens just re-auth — not fatal).
