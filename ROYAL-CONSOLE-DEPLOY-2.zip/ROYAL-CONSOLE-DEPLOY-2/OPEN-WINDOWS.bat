@echo off
REM MY CONSOLE - DEPLOY-2 launcher for Windows
REM Starts the Royal AI Gateway (console + secure AI backend) on http://127.0.0.1:8765
setlocal EnableExtensions
cd /d "%~dp0"
title MY CONSOLE - BUILD DEPLOY-2
echo.
echo   MY CONSOLE - BUILD DEPLOY-2
echo   ===============================

set "ROOT="
if exist "%~dp0MY-CONSOLE\index.html" set "ROOT=%~dp0MY-CONSOLE"
if not defined ROOT if exist "%~dp0index.html" set "ROOT=%~dp0."
if not defined ROOT (
  echo   Could not find MY-CONSOLE\index.html. Unzip the whole folder first ^(right-click the zip, Extract All^),
  echo   then double-click OPEN-WINDOWS.bat inside the extracted folder.
  pause
  exit /b 1
)

set "GW="
if exist "%~dp0royal-ai-cloud\server.py" set "GW=%~dp0royal-ai-cloud"

REM --- find Python 3.8+ : the py launcher first, then python / python3 ---
set "PY="
where py >nul 2>nul && py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && python -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul && set "PY=python"
)
if not defined PY (
  where python3 >nul 2>nul && python3 -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul && set "PY=python3"
)
if not defined PY (
  echo.
  echo   Python 3.8 or newer was not found.
  echo   1. Install it from https://www.python.org/downloads/windows/
  echo      ^(tick "Add python.exe to PATH" on the first installer screen^)
  echo   2. Double-click OPEN-WINDOWS.bat again.
  echo.
  echo   Opening the offline single-file console meanwhile ^(no AI cloud, no audio input^).
  start "" "https://www.python.org/downloads/windows/"
  if exist "%~dp0OPEN-MY-CONSOLE.html" start "" "%~dp0OPEN-MY-CONSOLE.html"
  pause
  exit /b 1
)

if not defined GW (
  echo   royal-ai-cloud\ not found - starting a plain local server ^(Offline Session Guardian only^).
  start "" "http://127.0.0.1:8765/index.html"
  cd /d "%ROOT%"
  %PY% -m http.server 8765 --bind 127.0.0.1
  exit /b
)

echo   Python:   %PY%
echo   Gateway:  %GW%
echo   Console:  %ROOT%
echo   Data:     %APPDATA%\RoyalAICloud  ^(provider key, licence, credits^)
echo   Banner should read: BUILD DEPLOY-2
echo   Keep this window open while you work. Close it ^(or Ctrl+C^) to stop.
echo.
REM First run: server.py asks for your OpenAI API key here (hidden input, Enter = skip),
REM stores it in %APPDATA%\RoyalAICloud\secrets.json (only your user account can read it),
REM then opens http://127.0.0.1:8765 in your default browser (Chrome or Edge recommended).
%PY% "%GW%\server.py" serve --web-root "%ROOT%" --open-browser
if errorlevel 1 (
  echo.
  echo   The gateway stopped with an error ^(see above^). If port 8765 is busy, close the other
  echo   MY CONSOLE window, or run:  %PY% "%GW%\server.py" serve --port 8775 --web-root "%ROOT%" --open-browser
  pause
)
endlocal
